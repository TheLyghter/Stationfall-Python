import os
import sys
import shlex
from typing import Optional

# Pydroid / wrappers sometimes run from a different CWD; ensure local imports work.
sys.path.insert(0, os.path.dirname(__file__))

from data_demo import make_demo_state
from ui_cli import CLI, print_state


class LoadGameRequested(Exception):
    def __init__(self, name: Optional[str] = None):
        super().__init__(name or "")
        self.name = name


def _print_welcome() -> None:
    print("\n==============================")
    print("   STATIONFALL — CLI Hot-seat")
    print("==============================\n")
    print("INICIO (setup):")
    print("  load [name]   Carga un save (por defecto ./saves/quicksave.sfsave)")
    print("  players <N>   Define cuantos jugadores van a jugar (1-6)")
    print("               (despues pedira los nombres)")
    print("  order         (debug) Elegir/barajar el orden de turno (se pide tras los nombres)")
    print("  deal          Reparte 2 Identity Cards al azar a cada jugador")
    print("               (cuando todos tengan 2, cada jugador elegira PC/BC en ronda hot-seat)")
    print("  ids           (debug) Lista las Identity Cards disponibles")
    print("  setids <P> <CID1> <CID2>  (debug) Asigna 2 Identity Cards a un jugador")
    print("  assign        (debug) Asignacion interactiva (elige 2 por jugador)")
    print("  showhands     (debug) Muestra las manos de Identity Cards (solo setup)")
    print("  resetids      (debug) Borra manos de Identity Cards (solo setup)")
    print("  help          Muestra estos comandos de inicio")
    print("  quit          Salir")
    print("")
    print("Tip: una vez empiece la partida, usa 'myid' para ver tus cartas (solo tu).")
    print("")


def _pregame_choose_players() -> int:
    """Devuelve el numero de jugadores a partir del comando 'players <N>'."""
    _print_welcome()
    while True:
        raw = input("setup> ").strip()
        if not raw:
            continue
        low = raw.lower()
        if low in ("quit", "exit", "q"):
            raise SystemExit(0)
        if low in ("help", "h", "?"):
            _print_welcome()
            continue

        parts = shlex.split(raw)
        if parts and parts[0].lower() == "load":
            name = parts[1] if len(parts) > 1 else None
            raise LoadGameRequested(name)
        if parts and parts[0].lower() == "players":
            if len(parts) != 2:
                print("Uso: players <N> (1-6)")
                continue
            try:
                n = int(parts[1])
            except ValueError:
                print("N invalido. Uso: players <N> (1-6)")
                continue
            if not (1 <= n <= 6):
                print("N fuera de rango. Uso: players <N> (1-6)")
                continue
            return n

        print("Comando no reconocido. Usa: players <N> | help | quit")


def _pregame_collect_player_names(n_players: int) -> list[str]:
    """Pide por consola el nombre de cada jugador antes de repartir identidades."""
    names: list[str] = []
    print("\nIntroduce el nombre de cada jugador:")
    for i in range(int(n_players)):
        while True:
            nm = input(f"  Jugador {i+1} nombre> ").strip()
            if nm:
                names.append(nm)
                break
            print("  (El nombre no puede estar vacio.)")
    return names


def _pregame_choose_player_order(state) -> None:
    """(Debug) Elegir / barajar el orden de jugadores antes de repartir identidades.

    Se ejecuta justo después de introducir nombres y antes de `deal`/`setids`/`assign`.
    - ENTER / done: mantener el orden actual.
    - order: baraja al azar.
    - order <perm>: fija el orden (ej: order 2 1 3).
    - show: muestra el orden actual.
    """

    import random

    def _show() -> None:
        print("\nOrden de jugadores (turn order):")
        for i, p in enumerate(getattr(state, "players", []) or [], 1):
            print(f"  {i}) {p.display_name()} [{p.pid}]")
        print("")

    def _remap_pid_keyed_dict(d: dict, mapping: dict[str, str]) -> dict:
        out: dict = {}
        for k, v in (d or {}).items():
            nk = mapping.get(k, k)
            out[nk] = v
        return out

    def _apply_players(new_players: list) -> None:
        # Reordena lista
        state.players = list(new_players)

        # Renumera PIDs para que P1..PN refleje el orden actual
        mapping: dict[str, str] = {}
        for i, p in enumerate(state.players, 1):
            old = str(getattr(p, "pid", ""))
            new = f"P{i}"
            mapping[old] = new
            p.pid = new

        # Remapea estructuras claveadas por pid (por robustez; en pregame suelen estar vacías)
        if hasattr(state, "influence"):
            state.influence = _remap_pid_keyed_dict(getattr(state, "influence", {}), mapping)
        if hasattr(state, "stationfall_scores"):
            state.stationfall_scores = _remap_pid_keyed_dict(getattr(state, "stationfall_scores", {}), mapping)
        if hasattr(state, "stationfall_deliveries"):
            state.stationfall_deliveries = _remap_pid_keyed_dict(getattr(state, "stationfall_deliveries", {}), mapping)
        if hasattr(state, "stationfall_winners"):
            state.stationfall_winners = [mapping.get(x, x) for x in (getattr(state, "stationfall_winners", []) or [])]

        # Estado de turno: empieza desde el primero
        setattr(state, "current_player_index", 0)

    # UI
    print("\n=== ORDEN DE JUGADORES (debug) ===")
    print("Escribe ENTER para mantener el orden.")
    print("Comandos:")
    print("  order              Barajar al azar")
    print("  order 2 1 3 ...     Fijar orden (permutación de 1..N)")
    print("  show               Ver orden actual")
    print("  done               Continuar")

    _show()

    n = len(getattr(state, "players", []) or [])
    while True:
        raw = input("order> ").strip()
        if raw == "":
            # Mantener
            return
        low = raw.lower()
        if low in ("done", "ok", "continue", "c"):
            return
        if low in ("show", "list", "ls"):
            _show()
            continue

        parts = shlex.split(raw)
        if not parts:
            continue

        if parts[0].lower() in ("order", "shuffle", "random"):
            if len(parts) == 1:
                new_players = list(state.players)
                random.shuffle(new_players)
                _apply_players(new_players)
                print("✅ Orden barajado.")
                _show()
                continue

            # order <perm>
            try:
                perm = [int(x) for x in parts[1:]]
            except ValueError:
                print("ERROR: usa numeros. Ej: order 2 1 3")
                continue
            if len(perm) != n or set(perm) != set(range(1, n + 1)):
                print(f"ERROR: la permutación debe contener exactamente 1..{n}. Ej: order 2 1 3")
                continue
            new_players = [state.players[i - 1] for i in perm]
            _apply_players(new_players)
            print("✅ Orden fijado.")
            _show()
            continue

        print("Comando no reconocido. Usa: order | order <perm> | show | done")


def _pregame_deal_identity_cards(state) -> None:
    """Setup: repartir o asignar Identity Cards (modo test/debug incluido)."""

    def _catalog() -> dict:
        return getattr(state, "identity_cards", {}) or {}

    def _cid_sort_key(cid: str) -> int:
        s = str(cid).strip().upper()
        if s.startswith("C") and s[1:].isdigit():
            return int(s[1:])
        try:
            return int(s)
        except Exception:
            return 10_000

    def _reset_identity_choices() -> None:
        for p in getattr(state, "players", []) or []:
            p.secret_identity = None
            p.bonus_character = None
            p.bonus_kind = None
            p.bonus_icons = 0
            p.bonus_points_disabled = False
            p.bonus_character_public = False

    def _all_hands_ready() -> bool:
        pls = getattr(state, "players", []) or []
        return bool(pls) and all(len(getattr(p, "identity_hand", []) or []) == 2 for p in pls)

    def _finalize_if_ready() -> bool:
        if _all_hands_ready():
            _reset_identity_choices()
            setattr(state, "identity_dealt", True)
            print("✅ Identity Cards asignadas (2 por jugador).")
            return True
        return False

    def _find_player(token: str):
        tok = str(token or "").strip()
        if not tok:
            return None
        pls = getattr(state, "players", []) or []

        if tok.isdigit():
            idx = int(tok) - 1
            return pls[idx] if 0 <= idx < len(pls) else None

        up = tok.upper()
        if up.startswith("P") and up[1:].isdigit():
            idx = int(up[1:]) - 1
            return pls[idx] if 0 <= idx < len(pls) else None

        # Match por nombre (case-insensitive)
        low = tok.lower()
        for p in pls:
            if str(getattr(p, "name", "") or "").strip().lower() == low:
                return p
        return None

    def _card_label(cid: str) -> str:
        c = str(cid).upper()
        nm = state.characters[c].name if c in getattr(state, "characters", {}) else "?"
        card = _catalog().get(c)
        if card is None:
            return f"{c} ({nm})"
        bk = str(getattr(card, "bonus_kind", "-") or "-").upper()
        bi = int(getattr(card, "bonus_icons", 0) or 0)
        return f"{c} ({nm}) | {bk} x{bi}"

    def _norm(s: str) -> str:
        """Normaliza texto para matching flexible (ignora espacios/guiones/_ y case)."""
        s = (s or "").strip().lower()
        # Deja solo alfanuméricos
        return "".join(ch for ch in s if ch.isalnum())

    def _match_hand_by_name(hand_cids: list[str], user_text: str) -> str | None:
        """Devuelve CID si user_text coincide (por nombre) con UNA carta de la mano."""
        needle = _norm(user_text)
        if not needle:
            return None

        # Matching exacto por nombre normalizado
        exact = []
        for cid in hand_cids:
            nm = state.characters[cid].name if cid in getattr(state, "characters", {}) else ""
            if _norm(nm) == needle:
                exact.append(cid)
        if len(exact) == 1:
            return exact[0]

        # Matching por prefijo único (ej: "stationchief" -> "stationchief")
        pref = []
        for cid in hand_cids:
            nm = state.characters[cid].name if cid in getattr(state, "characters", {}) else ""
            if _norm(nm).startswith(needle):
                pref.append(cid)
        if len(pref) == 1:
            return pref[0]

        return None

    def _norm_name(s: str) -> str:
        """Normaliza strings para permitir seleccionar por nombre en setup.

        Ejemplos:
          - "Array Control" -> "arraycontrol"
          - "array_control" -> "arraycontrol"
          - "Cyborg" -> "cyborg"
        """
        s = (s or "").strip().lower()
        return "".join(ch for ch in s if ch.isalnum())

    def _print_ids() -> None:
        cards = _catalog()
        if not cards:
            print("(No hay Identity Cards en el catalogo.)")
            return
        print("\nIdentity Cards disponibles:")
        for cid in sorted(cards.keys(), key=_cid_sort_key):
            print(f"  - {_card_label(cid)}")
        print("")

    def _print_hands() -> None:
        print("\nHands (debug - solo setup):")
        for i, p in enumerate(getattr(state, "players", []) or [], 1):
            hand = list(getattr(p, "identity_hand", []) or [])
            if not hand:
                print(f"  {i}. {p.pid} ({p.display_name()}): (vacia)")
                continue
            labels = ", ".join([_card_label(c) for c in hand])
            print(f"  {i}. {p.pid} ({p.display_name()}): {labels}")
        print("")

    def _set_player_hand(p, cid1: str, cid2: str) -> bool:
        cards = _catalog()
        def _resolve_identity_ref(ref: str) -> str:
            r = str(ref).strip()
            if not r:
                return ""
            up = r.upper()
            # Permite usar '13' como 'C13'
            if up.isdigit():
                up = f"C{up}"
            # Si ya es un CID valido, listo
            if up in cards:
                return up
            # Si es el nombre del Character, lo resolvemos a su CID
            try:
                cid = state.resolve_character_ref(r, allow_monster=False)
                return str(cid).upper()
            except Exception:
                return up

        c1 = _resolve_identity_ref(cid1)
        c2 = _resolve_identity_ref(cid2)
        if c1 == c2:
            print("ERROR: no puedes asignar la misma Identity Card dos veces al mismo jugador.")
            return False
        if c1 not in cards:
            print(f"ERROR: CID desconocido: {c1}. Usa 'ids' para ver el catalogo.")
            return False
        if c2 not in cards:
            print(f"ERROR: CID desconocido: {c2}. Usa 'ids' para ver el catalogo.")
            return False
        p.identity_hand = [c1, c2]
        print(f"✅ {p.display_name()} recibe: {_card_label(c1)}  +  {_card_label(c2)}")
        return True

    print("\nSetup de identidades:")
    print("  deal                          Reparte 2 Identity Cards al azar a cada jugador")
    print("  ids                           (debug) Lista el catalogo de Identity Cards")
    print("  setids <P> <CID1> <CID2>       (debug) Asigna 2 Identity Cards a un jugador")
    print("  assign                        (debug) Asignacion interactiva (elige 2 por jugador)")
    print("  showhands                     (debug) Muestra manos (solo setup)")
    print("  resetids                      (debug) Borra manos (solo setup)")
    print("  (help / quit tambien funcionan aqui)\n")

    while True:
        raw = input("setup> ").strip()
        if not raw:
            continue
        low = raw.lower()
        if low in ("quit", "exit", "q"):
            raise SystemExit(0)
        if low in ("help", "h", "?"):
            _print_welcome()
            print("\nEn este paso: deal | ids | setids | assign | showhands | resetids | quit\n")
            continue

        if low in ("ids", "listids"):
            _print_ids()
            continue

        if low in ("showhands", "hands"):
            _print_hands()
            continue

        if low in ("resetids", "clearids"):
            for p in getattr(state, "players", []) or []:
                p.identity_hand = []
            _reset_identity_choices()
            setattr(state, "identity_dealt", False)
            print("✅ Manos de Identity Cards borradas.")
            continue

        if low in ("deal", "dealids", "deal_id", "repartir"):
            # Evita redeal accidental
            already = any(getattr(p, "identity_hand", []) for p in getattr(state, "players", []) or [])
            if already:
                print("Ya hay Identity Cards en alguna mano. Usa 'resetids' si quieres re-hacer el setup.")
                continue

            deck = list(_catalog().keys())
            if not deck:
                print("ERROR: no hay catalogo de Identity Cards en el estado.")
                continue

            import random
            random.shuffle(deck)

            for p in state.players:
                p.identity_hand = []
                for _ in range(2):
                    if not deck:
                        break
                    p.identity_hand.append(str(deck.pop(0)).upper())

            _reset_identity_choices()
            setattr(state, "identity_dealt", True)
            print("✅ Identity Cards repartidas (2 por jugador).")
            return

        parts = shlex.split(raw)
        if parts and parts[0].lower() in ("setids", "setid", "sethand", "giveids"):
            if len(parts) != 4:
                print("Uso: setids <P> <CID1> <CID2>  (P puede ser 1, P1, o el nombre exacto)")
                continue
            p = _find_player(parts[1])
            if p is None:
                print("ERROR: jugador no encontrado. Usa 1..N, P1..PN, o el nombre exacto.")
                continue
            if _set_player_hand(p, parts[2], parts[3]):
                if _finalize_if_ready():
                    return
            continue

        if low in ("assign", "asign", "goddeal", "debugdeal"):
            cards = _catalog()
            if not cards:
                print("ERROR: no hay catalogo de Identity Cards en el estado.")
                continue
            print("\nAsignacion interactiva (debug):")
            print("  Escribe 2 CIDs por jugador (ej: C13 C22).")
            print("  Usa 'ids' antes si quieres ver el catalogo completo.\n")
            for i, p in enumerate(getattr(state, "players", []) or [], 1):
                while True:
                    raw2 = input(f"  {i}. {p.display_name()} IDs> ").strip()
                    if not raw2:
                        print("    (No puede estar vacio. Ej: C13 C22)")
                        continue
                    ps = shlex.split(raw2)
                    if len(ps) != 2:
                        print("    Uso: <CID1> <CID2>  (ej: C13 C22)")
                        continue
                    ok = _set_player_hand(p, ps[0], ps[1])
                    if ok:
                        break
            if _finalize_if_ready():
                return
            # Si por alguna razon no esta listo, sigue en el bucle
            continue

        print("Comando no reconocido. En este paso: deal | ids | setids | assign | showhands | resetids | help | quit")


def _pregame_choose_pc_bc(state) -> None:
    """Ronda hot-seat: cada jugador elige su PC (Principal) y su BC (Bonus Character).

    Requiere que cada jugador tenga exactamente 2 Identity Cards en identity_hand.
    """
    cards = getattr(state, "identity_cards", {}) or {}
    if not cards:
        print("ERROR: no hay catalogo de Identity Cards en el estado.")
        return

    pls = getattr(state, "players", []) or []
    if not pls:
        print("ERROR: no hay jugadores.")
        return

    # Validacion: todos con 2 cartas
    for p in pls:
        hand = list(getattr(p, "identity_hand", []) or [])
        if len(hand) != 2:
            raise RuntimeError("Setup incompleto: no todos los jugadores tienen 2 Identity Cards.")

    def _cid_sort_key(cid: str) -> int:
        s = str(cid).strip().upper()
        if s.startswith("C") and s[1:].isdigit():
            return int(s[1:])
        try:
            return int(s)
        except Exception:
            return 10_000

    def _card_label(cid: str) -> str:
        c = str(cid).upper()
        nm = state.characters[c].name if c in getattr(state, "characters", {}) else "?"
        card = cards.get(c)
        if card is None:
            return f"{c} ({nm})"
        bk = str(getattr(card, "bonus_kind", "-") or "-").upper()
        bi = int(getattr(card, "bonus_icons", 0) or 0)
        return f"{c} ({nm}) | {bk} x{bi}"

    def _norm(s: str) -> str:
        """Normaliza texto para matching flexible (ignora espacios/guiones/_ y case)."""
        s = (s or "").strip().lower()
        return "".join(ch for ch in s if ch.isalnum())

    def _match_hand_by_name(hand_cids, user_text: str):
        """Devuelve CID si user_text coincide por nombre con UNA carta de la mano."""
        needle = _norm(user_text)
        if not needle:
            return None

        # Exact match por nombre normalizado
        exact = []
        for cid in hand_cids:
            nm = state.characters[cid].name if cid in getattr(state, "characters", {}) else ""
            if _norm(nm) == needle:
                exact.append(cid)
        if len(exact) == 1:
            return exact[0]

        # Prefix match único (útil para nombres largos)
        pref = []
        for cid in hand_cids:
            nm = state.characters[cid].name if cid in getattr(state, "characters", {}) else ""
            if _norm(nm).startswith(needle):
                pref.append(cid)
        if len(pref) == 1:
            return pref[0]

        return None

    print("\n=== ELECCION DE IDENTIDADES (PC / BC) ===")
    print("Cada jugador elige su Personaje Principal (PC). La otra carta pasa a ser su BC.")
    print("(Hot-seat: que los demas miren a otro lado en cada eleccion)\n")

    for idx, p in enumerate(pls, 1):
        # Limpia elecciones previas por si venimos de un reset
        p.secret_identity = None
        p.bonus_character = None
        p.bonus_kind = None
        p.bonus_icons = 0
        p.bonus_points_disabled = False
        p.bonus_character_public = False

        input(f"\n[{idx}/{len(pls)}] Turno de {p.display_name()}. Que los demas NO miren. Pulsa ENTER para ver tus cartas...")

        h = [str(x).upper() for x in (getattr(p, "identity_hand", []) or [])]
        # Por seguridad
        h = sorted(h, key=_cid_sort_key)

        print("\nTus 2 Identity Cards:")
        print(f"  1) {_card_label(h[0])}")
        print(f"  2) {_card_label(h[1])}")

        while True:
            raw = input("Elige tu PC (1/2, CID o NOMBRE)> ").strip()
            ch = raw.upper()
            if ch in ("1", "2"):
                pc = h[int(ch) - 1]
                bc = h[1 - (int(ch) - 1)]
            elif ch in (h[0], h[1]):
                pc = ch
                bc = h[1] if ch == h[0] else h[0]
            else:
                m = _match_hand_by_name(h, raw)
                if m is None:
                    print("  Entrada invalida. Usa 1, 2, CID (ej: C23) o el nombre (ej: Cyborg).")
                    continue
                pc = m
                bc = h[1] if pc == h[0] else h[0]

            p.secret_identity = pc
            p.bonus_character = bc

            # Copiamos meta de bonus al player (no es estrictamente necesario, pero es util)
            try:
                kind, icons = state.bonus_meta_for(bc) if hasattr(state, "bonus_meta_for") else (None, 0)
            except Exception:
                kind, icons = (None, 0)
            if kind:
                p.bonus_kind = str(kind).upper()
                p.bonus_icons = int(icons)

            # La mano ya no hace falta; las cartas quedan como PC/BC secretas
            p.identity_hand = []

            nm_pc = state.characters[pc].name if pc in state.characters else "?"
            nm_bc = state.characters[bc].name if bc in state.characters else "?"
            print(f"\n✅ Elegido: PC={pc} ({nm_pc}) | BC={bc} ({nm_bc})")
            break

        # "limpia pantalla" para que el siguiente jugador no vea
        print("\n" * 30)

    setattr(state, "identities_chosen", True)
    print("✅ Identidades elegidas. Empieza la partida.\n")


def _run_game_loop(ui: CLI) -> None:
    """Loop principal: turnos, minutos, Stationfall."""
    while True:
        ui.play_one_turn()

        # Stationfall puede dispararse al final del turno (por Resolve / Antimatter / etc.)
        if bool(getattr(ui.state, "stationfall_triggered", False)) and not bool(
            getattr(ui.state, "stationfall_processed", False)
        ):
            ui.run_stationfall()
            print("\n=== FINAL STATE ===")
            print_state(ui.state)
            break

        ui.state.advance_player()

        # End of Minute (cuando vuelve al jugador 0)
        if ui.state.current_player_index == 0:
            msgs = ui.state.advance_minute() if hasattr(ui.state, "advance_minute") else []
            for m in (msgs or []):
                print("\n" + str(m))

            if bool(getattr(ui.state, "stationfall_triggered", False)) and not bool(
                getattr(ui.state, "stationfall_processed", False)
            ):
                ui.run_stationfall()
                print("\n=== FINAL STATE ===")
                print_state(ui.state)
                break


def main() -> None:
    try:
        n_players = _pregame_choose_players()
    except LoadGameRequested as e:
        try:
            from save_load import load_game
            ui_obj = load_game(e.name)
            if not isinstance(ui_obj, CLI):
                raise TypeError("El save no contiene un objeto CLI válido.")
            ui = ui_obj

            n_players = len(getattr(ui.state, "players", []) or [])
            loaded_name = e.name or "quicksave"
            print(f"\n✅ Save cargado: {loaded_name} | jugadores={n_players}")
            print("Run: main.py\n")
            _run_game_loop(ui)
            return
        except Exception as ex:
            print(f"\n❌ No se pudo cargar el save: {ex}")
            return

    player_names = _pregame_collect_player_names(n_players)

    # Construye el estado base (mapa + personajes + catalogo de Identity Cards)
    state = make_demo_state(num_players=n_players, player_names=player_names)

    # Debug: elegir / barajar el orden de turno antes de repartir identidades
    _pregame_choose_player_order(state)

    # Reparto de identidades por comando
    _pregame_deal_identity_cards(state)

    # Ronda hot-seat: elegir PC/BC
    _pregame_choose_pc_bc(state)

    ui = CLI(state)

    print(f"\n✅ Partida creada: {n_players} jugador(es).")
    print("Run: main.py\n")

    _run_game_loop(ui)


if __name__ == "__main__":
    main()
