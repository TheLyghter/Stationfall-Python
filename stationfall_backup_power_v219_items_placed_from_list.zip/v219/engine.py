from __future__ import annotations

import abilities as AB

from actions import (
    Action,
    ActionError,
    SectionAction,
    ConsoleAction,
    Move,
    MoveDrag,
    PickUp,
    Drop,
    Give,
    ThrowItem,
    CopyData,
    DeleteData,
    Attack,
    Rob,
    Sabotage,
    Revive,
    Wait,
)
from models import GameState, MAGNETIC_CONTAINMENT_SECTION, OUT_OF_GAME_SECTION


def _render_player_names(state: GameState, msg: str) -> str:
    """Sustituye P1/P2/... por el nombre del jugador en mensajes.

    Esto mantiene PIDs como IDs internos, pero hace la salida más legible.
    """
    if not msg:
        return msg
    try:
        import re
        out = str(msg)
        for p in getattr(state, 'players', []) or []:
            pid = str(getattr(p, 'pid', '')).strip()
            if not pid:
                continue
            name = p.display_name() if hasattr(p, 'display_name') else str(getattr(p, 'name', '')).strip()
            if not name or name == pid:
                continue
            out = re.sub(rf"\b{re.escape(pid)}\b", name, out)
        return out
    except Exception:
        return str(msg)


def _norm(s: str) -> str:
    import re
    return re.sub(r"[^A-Z0-9]", "", str(s).upper())


def _is_lit(state: GameState, sec: str) -> bool:
    """Por defecto, toda sección está iluminada salvo que aparezca en unlit_sections."""
    return sec not in getattr(state, "unlit_sections", set())


def _apply_observed_suspect(state: GameState, pre_status: dict) -> str:
    """Implements Reference Manual §10.1.2 (Observed by Cameras)."""
    cp = state.current_player()
    if getattr(cp, "legal", "Innocent") != "Innocent":
        return ""

    if not getattr(state, "cameras_on", False):
        return ""

    became_down: list[tuple[str, str]] = []  # (cid, sec)
    for cid, ch in state.characters.items():
        pre = pre_status.get(cid)
        if not pre:
            continue
        pre_down, pre_annih, pre_esc = pre

        if bool(getattr(ch, "annihilated", False)) or bool(getattr(ch, "escaped", False)):
            continue

        if "HUMAN" not in _norm(getattr(ch, "ctype", "")):
            continue

        if pre_down:
            continue

        if str(getattr(ch, "status", "")).upper() != "DOWN":
            continue

        sec = str(getattr(ch, "section", ""))
        if not _is_lit(state, sec):
            continue

        became_down.append((cid, sec))

    if not became_down:
        return ""

    # FUGITIVE (Character ability): nothing done BY or AGAINST a Fugitive converts
    # the current player from Innocent to Suspect.
    # - BY: the active character has FUGITIVE.
    # - AGAINST: at least one newly-DOWN Human has FUGITIVE.
    try:
        actor_cid = getattr(state, "active_character_id", None)
        actor_is_fugitive = bool(actor_cid) and actor_cid in getattr(state, "characters", {}) and state.characters[actor_cid].has_ability(AB.FUGITIVE)
        target_is_fugitive = any(
            (cid in getattr(state, "characters", {})) and state.characters[cid].has_ability(AB.FUGITIVE)
            for cid, _ in became_down
        )
        if actor_is_fugitive or target_is_fugitive:
            uniq_secs = sorted({sec for _, sec in became_down})
            cids = ",".join([cid for cid, _ in became_down])
            secs = ",".join(uniq_secs)
            return f"📷 OBSERVED: {cp.pid} NO pasa a Suspect (FUGITIVE) (Humano(s) {cids} quedaron DOWN en sección(es) iluminada(s) {secs}, Cameras ON)"
    except Exception:
        # If something goes wrong, fall back to the normal rule.
        pass

    # Make Suspect
    cp.legal = "Suspect"

    # Message (keep it compact)
    uniq_secs = sorted({sec for _, sec in became_down})
    cids = ",".join([cid for cid, _ in became_down])
    secs = ",".join(uniq_secs)
    return f"📷 OBSERVED: {cp.pid} pasa a Suspect (Humano(s) {cids} quedaron DOWN en sección(es) iluminada(s) {secs}, Cameras ON)"


def apply_action(state: GameState, action: Action, record_log: bool = True) -> str:
    # GAME OVER:
    # - Si estamos en Stationfall y NO estamos procesándolo (modo normal), no se permiten más acciones.
    # - Durante el procedimiento de Stationfall (UI), se permiten acciones internas como Reveal.
    if bool(getattr(state, 'game_over', False)):
        raise ActionError('GAME OVER: la partida ha terminado; no se permiten más acciones.')
    if bool(getattr(state, 'stationfall_triggered', False)) and (not bool(getattr(state, 'stationfall_mode', False))):
        raise ActionError('GAME OVER: STATIONFALL ya está activado; no se permiten más acciones.')


    # Stranger (Character Dossier): HOMEWORK.
    # Si el UI ha activado Homework en el Reveal, la PROXIMA accion del turno
    # se ejecuta con el Bonus Character (BC) como actor, sin necesidad de activar.
    _hw_actor = getattr(state, 'homework_actor', None)
    if _hw_actor and (not bool(getattr(state, '_homework_in_progress', False))):
        hw = str(_hw_actor).upper()
        # Seguridad: solo para el jugador que lo activo.
        hw_pid = getattr(state, 'homework_pid', None)
        if hw_pid is not None and str(getattr(state.current_player(), 'pid', '')) != str(hw_pid):
            # Si por algun motivo el turno cambio, cancelamos el efecto.
            state.homework_actor = None
            state.homework_pid = None
        else:
            # No permitimos iniciar fases del turno antes de resolver Homework.
            from actions import Activate, PlaceInfluence, RenegotiateTakeBack, Reveal, SchrodingerReveal
            if isinstance(action, (Activate, PlaceInfluence, RenegotiateTakeBack, Reveal, SchrodingerReveal)):
                raise ActionError('HOMEWORK: primero debes hacer 1 accion con tu BC antes de otros pasos del turno.')

            orig_actor = getattr(state, 'active_character_id', None)
            orig_total = int(getattr(state, 'action_points_total', 0) or 0)
            orig_used = int(getattr(state, 'action_points_used', 0) or 0)
            orig_free = bool(getattr(state, 'free_pickdrop_used', False))
            # Evitar interaccion con otros wrappers (Forceful Presence, etc.).
            orig_fp = getattr(state, 'forceful_presence_actor', None)
            try:
                state._homework_in_progress = True
                state.forceful_presence_actor = None
                state.active_character_id = hw
                # Dale 1 AP temporal para que validaciones de "remaining_actions" pasen.
                state.action_points_total = 1
                state.action_points_used = 0
                state.free_pickdrop_used = False
                msg = apply_action(state, action, record_log=False)
                # Consumir el power solo si la accion se aplico con exito.
                state.homework_actor = None
                state.homework_pid = None
                out = str(msg) + f" | HOMEWORK({hw})"
                if record_log:
                    getattr(state, 'turn_log', []).append(_render_player_names(state, out))
                return _render_player_names(state, out)
            finally:
                # Restaurar contexto.
                try:
                    state.active_character_id = orig_actor
                    state.action_points_total = orig_total
                    state.action_points_used = orig_used
                    state.free_pickdrop_used = orig_free
                except Exception:
                    pass
                try:
                    state.forceful_presence_actor = orig_fp
                except Exception:
                    pass
                try:
                    state._homework_in_progress = False
                except Exception:
                    pass

    # Station Chief (Character Dossier): FORCEFUL_PRESENCE.
    # Si el UI ha seleccionado un NPC, la próxima Basic Action se ejecuta con ese NPC
    # como actor y no consume Action Points ni el slot de Free Pick/Drop.
    _fp_actor = getattr(state, 'forceful_presence_actor', None)
    if _fp_actor and (not bool(getattr(state, '_forceful_presence_in_progress', False))):
        fp = str(_fp_actor).upper()
        if fp in getattr(state, 'characters', {}):
            BASIC = (
                Move,
                MoveDrag,
                PickUp,
                Drop,
                Give,
                ThrowItem,
                CopyData,
                DeleteData,
                Attack,
                Rob,
                Sabotage,
                Revive,
                Wait,
            )
            if not isinstance(action, BASIC):
                raise ActionError(
                    'FORCEFUL_PRESENCE: la próxima acción debe ser una Basic Action (step/move, pick, drop, give, throw, copy, delete, attack, rob, sabotage, revive, wait).'
                )

            orig_actor = getattr(state, 'active_character_id', None)
            orig_free = bool(getattr(state, 'free_pickdrop_used', False))
            try:
                state._forceful_presence_in_progress = True
                state._suppress_action_point_spend = True
                # Evita que Pick/Drop consuma el slot normal; la acción ya es gratis.
                state.free_pickdrop_used = True
                state.active_character_id = fp
                # Consumir el power solo si la acción llega a aplicarse con éxito.
                msg = apply_action(state, action, record_log=False)
                state.forceful_presence_actor = None
                out = str(msg) + f" | FORCEFUL_PRESENCE({fp})"
                if record_log:
                    getattr(state, 'turn_log', []).append(_render_player_names(state, out))
                return _render_player_names(state, out)
            finally:
                # Restaurar contexto de la Activation original.
                try:
                    state.active_character_id = orig_actor
                    state.free_pickdrop_used = orig_free
                except Exception:
                    pass
                try:
                    state._suppress_action_point_spend = False
                    state._forceful_presence_in_progress = False
                except Exception:
                    pass
    # STOWAWAY (Character Dossier): si está fuera del mapa, la primera acción como actor
    # debe ser MOVE a una sección DARK (sin restricción de conectividad).
    try:
        actor = getattr(state, 'active_character_id', None)
        if actor and actor in getattr(state, 'characters', {}):
            ch = state.characters[actor]
            name = str(getattr(ch, 'name', '') or '').strip().upper()
            sec = str(getattr(ch, 'section', '') or '').strip().upper()
            if name == 'STOWAWAY' and sec == str(OUT_OF_GAME_SECTION).upper():
                counters = getattr(ch, 'counters', {}) or {}
                if int(counters.get('STOWAWAY_DEPLOYED', 0) or 0) == 0:
                    if not isinstance(action, Move):
                        raise ActionError('STOWAWAY: la primera acción debe ser MOVE a una sección DARK.')
                    to_u = str(getattr(action, 'to_section', '') or '').strip().upper()
                    unlit = {str(x).upper() for x in getattr(state, 'unlit_sections', set())}
                    if to_u not in unlit:
                        raise ActionError('STOWAWAY: la primera acción debe ser MOVE a una sección DARK.')
    except ActionError:
        raise
    except Exception:
        pass

    # Snapshot before the action so we can detect "became DOWN" effects.
    pre_status = {
        cid: (
            str(getattr(ch, "status", "")).upper() == "DOWN",
            bool(getattr(ch, "annihilated", False)),
            bool(getattr(ch, "escaped", False)),
        )
        for cid, ch in state.characters.items()
    }

    # Snapshot de Antimatter: si sale de Magnetic Containment, se arma (RM 7.3.1).
    pre_am = None  # (iid, (loc_type, loc_value), armed)
    try:
        aid = state.antimatter_id() if hasattr(state, 'antimatter_id') else None
        if aid:
            pre_loc = state.item_location(aid) if hasattr(state, 'item_location') else ("NONE", "")
            it = getattr(state, 'items', {}).get(aid)
            pre_am = (aid, pre_loc, bool(getattr(it, 'armed', False)) if it else False)
    except Exception:
        pre_am = None


    # RM 7.2.2 Blackout: Console y Section Actions On Board están deshabilitadas
    # excepto Timed Launch y Airlock.
    if getattr(state, "is_blackout", lambda: False)():
        if isinstance(action, (SectionAction, ConsoleAction)) and (not getattr(action, "blackout_exempt", False)):
            actor = getattr(state, "active_character_id", None)
            sec = None
            if actor and actor in getattr(state, "characters", {}):
                sec = str(getattr(state.characters[actor], "section", "")).upper()
            # Solo aplica la restricción si el actor está en una Section realmente On Board (RM 5.1.6).
            if sec and hasattr(state, "on_board_sections") and sec in state.on_board_sections():
                raise ActionError("BLACKOUT (RM 7.2.2): Console/Se...n Board están deshabilitadas (salvo Timed Launch y Airlock).")

    action.validate(state)

    # RM 11.2 Self Preservation (implementación global):
    # Si una acción del Character (durante activación) haría que el propio actor
    # quedase DOWN o ANNIHILATED de forma inmediata al resolverla, no se puede hacer.
    actor = getattr(state, 'active_character_id', None)
    if actor and getattr(action, 'enforce_self_preservation', True):
        try:
            sim = state.clone() if hasattr(state, 'clone') else None
            if sim is None:
                import copy
                sim = copy.deepcopy(state)
            # Aplicar la acción en el clon para ver el resultado inmediato.
            action.validate(sim)
            action.apply(sim)
            sim_actor = getattr(sim, 'characters', {}).get(actor)
            if sim_actor is not None:
                would_be_down = str(getattr(sim_actor, 'status', 'LIVE')).upper() == 'DOWN'
                would_be_annih = bool(getattr(sim_actor, 'annihilated', False))
                if would_be_down or would_be_annih:
                    raise ActionError('Self Preservation (RM 11.2): no puedes hacer una acción que te deje DOWN o ANNIHILATED inmediatamente.')
        except ActionError:
            # Propagar errores de regla tal cual.
            raise
        except Exception:
            # Si la simulación falla por alguna razón interna, no bloqueamos la acción real.
            # (Evita falsos positivos por bugs de debug/simulación.)
            pass

    msg = action.apply(state)

    # RM 7.3 / 13.5: si la Antimatter pasa a estar FUERA de MAGNETIC_CONTAINMENT por esta acción, se ARMA y coloca timer.
    # Importante: "estar en una sección" incluye estar poseída por un Character ubicado en esa sección.
    try:
        if pre_am is not None:
            aid, (loc_t, loc_v), was_armed = pre_am
            post_loc = state.item_location(aid) if hasattr(state, 'item_location') else ("NONE", "")

            def _effective_section(loc) -> str:
                """Devuelve la 'sección efectiva' del objeto para reglas de Antimatter.
                - Si está en el suelo: esa sección.
                - Si está poseída por un Character: la sección actual de ese Character.
                - En otros casos: string vacío.
                """
                try:
                    lt = str(loc[0] if isinstance(loc, (list, tuple)) and len(loc) > 0 else loc).upper()
                    lv = loc[1] if isinstance(loc, (list, tuple)) and len(loc) > 1 else ""
                    lv_u = str(lv).upper()
                    if lt == 'SEC':
                        return lv_u
                    if lt == 'CHAR':
                        ch = getattr(state, 'characters', {}).get(str(lv), None)
                        if ch is not None:
                            return str(getattr(ch, 'section', '') or '').upper()
                        return ''
                    if lt == 'POD':
                        # Si en algún momento modelamos objetos "dentro del pod" explícitamente, tratamos el pod como sección.
                        return lv_u
                except Exception:
                    return ''
                return ''

            mc = str(MAGNETIC_CONTAINMENT_SECTION).upper()
            pre_eff = _effective_section((loc_t, loc_v))
            post_eff = _effective_section(post_loc)

            if (pre_eff == mc) and (post_eff != mc) and (not was_armed):
                extra = state.arm_antimatter(state.current_player().pid) if hasattr(state, 'arm_antimatter') else ''
                if extra:
                    msg = msg + ' | ' + extra
    except Exception:
        pass

    observed_msg = _apply_observed_suspect(state, pre_status)
    if observed_msg:
        msg = msg + " | " + observed_msg

    # UI-friendly: mostrar nombres de jugador en vez de P1/P2/...
    msg = _render_player_names(state, msg)

    msg = _render_player_names(state, msg)

    if record_log:
        state.turn_log.append(msg)
    return msg
