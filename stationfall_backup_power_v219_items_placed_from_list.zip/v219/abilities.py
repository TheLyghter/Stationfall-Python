"""Central registry for ability names.

Goal:
- Stop scattering raw strings across the codebase.
- Keep save/load compatible (these are still just strings in saved state).
- Avoid duplicating *logic*: the rule logic stays in actions.py/models.py; this module
  only defines canonical names + lightweight metadata.

Note:
- Some tags may be granted later by triggers (e.g. on Reveal), but they are still normal abilities.
"""

from __future__ import annotations

from dataclasses import dataclass
from typing import Dict, Literal, Set

AbilityKind = Literal[
    "ability",        # always-on ability/quirk on the Character card
        "internal_flag",  # internal-only marker used by the engine (should ideally not be printed)
    "placeholder",    # appears in demo data, currently has no rules wired
]


@dataclass(frozen=True)
class AbilityDef:
    code: str          # python constant name (e.g. OFFICER)
    label: str         # stored in Character.abilities as a string (e.g. "OFFICER", "TUNNEL RAT")
    kind: AbilityKind
    notes: str = ""


# --- Canonical ability labels used by the engine --------------------------------

ADRENALINE = "ADRENALINE"
ARMORED = "ARMORED"
BREACH = "BREACH"
FAST_TALK = "FAST TALK"
FUGITIVE = "FUGITIVE"
HACKER = "HACKER"
HELPFUL = "HELPFUL"
INMUNITY = "INMUNITY"  # internal quirk flag (typo kept for save compatibility)
JUGGERNAUT = "JUGGERNAUT"
LOYAL = "LOYAL"
OFFICER = "OFFICER"
PEACEKEEPER = "PEACEKEEPER"
PRIDE = "PRIDE"
TUNNEL_RAT = "TUNNEL RAT"
UNCANNY = "UNCANNY"
WARY = "WARY"
WORMTONGUE = "WORMTONGUE"

# Actions-as-abilities (wired by the engine as ability tags)
JURY_RIG = "JURY RIG"

# Prototypes for Medical
EMERGENCY_RESPONSE_ALPHA = "EMERGENCY_RESPONSE_ALPHA"
EMERGENCY_RESPONSE_BETA = "EMERGENCY_RESPONSE_BETA"

# Reveal-tag abilities (unlocked on PC reveal in this prototype)
BRUTAL = "BRUTAL"
SELF_REPAIR = "SELF_REPAIR"
ZEROBORN = "ZEROBORN"
BLOOD_FROM_A_STONE = "BLOOD_FROM_A_STONE"
TRADECRAFT = "TRADECRAFT"
FORCEFUL_PRESENCE = "FORCEFUL_PRESENCE"

# One-shot / triggered abilities (implemented in the engine as reveal/stationfall powers)
AUTHORIZED_FORCE = "AUTHORIZED_FORCE"
HAYWIRE = "HAYWIRE"
RECORDED_CONFESSIONAL = "RECORDED_CONFESSIONAL"
OVERLOAD = "OVERLOAD"
SECRET_CACHE = "SECRET_CACHE"
HOMEWORK = "HOMEWORK"
ENIGMA = "ENIGMA"
POINT_BREAK = "POINT_BREAK"
TALK_THEM_THROUGH_IT = "TALK_THEM_THROUGH_IT"

# --- Placeholders that currently have no rule logic ------------------------------
# Nota: estos nombres aparecen en el dossier (aunque no estén cableados todavía en reglas).

DISASSEMBLE = "DISASSEMBLE"
PARANOID = "PARANOID"


# ---------------------------------------------------------------------------------

ABILITY_DEFS: Dict[str, AbilityDef] = {
    # Always-on
    ADRENALINE: AbilityDef("ADRENALINE", ADRENALINE, "ability"),
    ARMORED: AbilityDef("ARMORED", ARMORED, "ability", "Cannot be Attacked or Robbed with Bludgeon."),
    BREACH: AbilityDef("BREACH", BREACH, "ability"),
    FAST_TALK: AbilityDef("FAST_TALK", FAST_TALK, "ability"),
    FUGITIVE: AbilityDef("FUGITIVE", FUGITIVE, "ability"),
    HACKER: AbilityDef("HACKER", HACKER, "ability"),
    HELPFUL: AbilityDef("HELPFUL", HELPFUL, "ability"),
    INMUNITY: AbilityDef("INMUNITY", INMUNITY, "internal_flag", "Internal quirk flag (can-win-while-guilty)"),
    JUGGERNAUT: AbilityDef("JUGGERNAUT", JUGGERNAUT, "ability"),
    JURY_RIG: AbilityDef("JURY_RIG", JURY_RIG, "ability"),
    LOYAL: AbilityDef("LOYAL", LOYAL, "ability"),    OFFICER: AbilityDef(
        "OFFICER",
        OFFICER,
        "ability",
        "Puede atravesar corredores con LOCK y, si lo hace, retira el token LOCK (en BLACKOUT esto no aplica).",
    ),
    PEACEKEEPER: AbilityDef("PEACEKEEPER", PEACEKEEPER, "ability", "May only Attack Fugitives, Monsters, or non-Innocent PCs. May not Sabotage."),    PRIDE: AbilityDef(
        "PRIDE",
        PRIDE,
        "ability",
        "No puede ser ROBBED (no le pueden robar).",
    ),
    TUNNEL_RAT: AbilityDef("TUNNEL_RAT", TUNNEL_RAT, "ability"),
    UNCANNY: AbilityDef("UNCANNY", UNCANNY, "ability"),
    WARY: AbilityDef("WARY", WARY, "ability"),
    WORMTONGUE: AbilityDef("WORMTONGUE", WORMTONGUE, "ability"),

    # Medical prototype
    EMERGENCY_RESPONSE_ALPHA: AbilityDef("EMERGENCY_RESPONSE_ALPHA", EMERGENCY_RESPONSE_ALPHA, "ability"),
    EMERGENCY_RESPONSE_BETA: AbilityDef("EMERGENCY_RESPONSE_BETA", EMERGENCY_RESPONSE_BETA, "ability"),

    # Triggered abilities (still stored as normal abilities)
    BRUTAL: AbilityDef("BRUTAL", BRUTAL, "ability"),
    SELF_REPAIR: AbilityDef("SELF_REPAIR", SELF_REPAIR, "ability"),
    ZEROBORN: AbilityDef("ZEROBORN", ZEROBORN, "ability"),
    BLOOD_FROM_A_STONE: AbilityDef("BLOOD_FROM_A_STONE", BLOOD_FROM_A_STONE, "ability"),
    TRADECRAFT: AbilityDef("TRADECRAFT", TRADECRAFT, "ability"),    FORCEFUL_PRESENCE: AbilityDef(
        "FORCEFUL_PRESENCE",
        FORCEFUL_PRESENCE,
        "ability",
        "Al inicio de cada activación, puedes elegir 1 NPC COLOCATED contigo o cualquier NPC con OFFICER: haces 1 Basic Action gratis con ese NPC.",
    ),

    
    # One-shot / triggered abilities (engine uses these as reveal/stationfall powers)
    AUTHORIZED_FORCE: AbilityDef("AUTHORIZED_FORCE", AUTHORIZED_FORCE, "ability"),
    HAYWIRE: AbilityDef("HAYWIRE", HAYWIRE, "ability"),
    RECORDED_CONFESSIONAL: AbilityDef("RECORDED_CONFESSIONAL", RECORDED_CONFESSIONAL, "ability"),
    OVERLOAD: AbilityDef("OVERLOAD", OVERLOAD, "ability"),
    SECRET_CACHE: AbilityDef("SECRET_CACHE", SECRET_CACHE, "ability"),
    HOMEWORK: AbilityDef("HOMEWORK", HOMEWORK, "ability"),
    ENIGMA: AbilityDef("ENIGMA", ENIGMA, "ability"),
    POINT_BREAK: AbilityDef("POINT_BREAK", POINT_BREAK, "ability"),
    TALK_THEM_THROUGH_IT: AbilityDef("TALK_THEM_THROUGH_IT", TALK_THEM_THROUGH_IT, "ability"),

# Placeholders (en dossier)
    DISASSEMBLE: AbilityDef("DISASSEMBLE", DISASSEMBLE, "placeholder"),
    PARANOID: AbilityDef("PARANOID", PARANOID, "placeholder"),
}

KNOWN_ABILITY_LABELS: Set[str] = set(ABILITY_DEFS.keys())

# Habilidades que (si están presentes en el Character) generan un "Activation Power"
# que la UI debe resolver justo después de ACTIVATE.
ACTIVATION_POWER_TAGS: Set[str] = {
    FORCEFUL_PRESENCE,
}
