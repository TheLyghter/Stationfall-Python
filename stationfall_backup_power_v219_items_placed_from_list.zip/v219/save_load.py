"""Save/Load helpers for Stationfall CLI.

This project runs often in unstable environments (e.g., mobile Python), so we
provide a simple persistence layer:

- `save` command (in-game) writes a snapshot of the current CLI + GameState.
- `load` command (at start) restores that snapshot and continues.

We use `pickle` because it preserves the *entire* object graph (including
mid-turn flags, undo stack, etc.).

Security note: never load pickle files you don't trust.
"""

from __future__ import annotations

import os
import pickle
import random
import time
from typing import Any, Optional


MAGIC = "STATIONFALL_SAVE_V1"
DEFAULT_SAVE_NAME = "quicksave.sfsave"


def _base_dir() -> str:
    # Keep saves next to the code so it's easy to find in Pydroid.
    return os.path.dirname(os.path.abspath(__file__))


def _saves_dir() -> str:
    d = os.path.join(_base_dir(), "saves")
    os.makedirs(d, exist_ok=True)
    return d


def _normalize_name(name: Optional[str]) -> str:
    n = (name or "").strip()
    if not n:
        n = DEFAULT_SAVE_NAME
    if not n.lower().endswith(".sfsave"):
        n += ".sfsave"
    return n


def resolve_save_path(name: Optional[str]) -> str:
    n = _normalize_name(name)
    # If user passed a path, respect it; otherwise put in saves dir.
    has_sep = (os.path.sep in n) or (os.path.altsep and os.path.altsep in n)
    if has_sep:
        return os.path.abspath(n)
    return os.path.join(_saves_dir(), n)


def list_saves() -> list[str]:
    d = _saves_dir()
    out: list[str] = []
    try:
        for fn in sorted(os.listdir(d)):
            if fn.lower().endswith(".sfsave"):
                out.append(os.path.join(d, fn))
    except Exception:
        pass
    return out


def save_game(ui_obj: Any, name: Optional[str] = None) -> str:
    """Persist the current game snapshot. Returns the written path."""
    path = resolve_save_path(name)
    tmp = path + ".tmp"

    payload = {
        "magic": MAGIC,
        "saved_at": time.time(),
        "random_state": random.getstate(),
        "ui": ui_obj,
    }

    # Atomic-ish: write temp, then replace.
    with open(tmp, "wb") as f:
        pickle.dump(payload, f, protocol=pickle.HIGHEST_PROTOCOL)
        f.flush()
        try:
            os.fsync(f.fileno())
        except Exception:
            pass
    os.replace(tmp, path)
    return path


def load_game(name: Optional[str] = None) -> Any:
    """Load a previously saved snapshot and return the stored UI object."""
    path = resolve_save_path(name)
    if not os.path.exists(path):
        raise FileNotFoundError(f"No existe el save: {path}")

    with open(path, "rb") as f:
        payload = pickle.load(f)

    if not isinstance(payload, dict) or payload.get("magic") != MAGIC:
        raise ValueError("Archivo de save inválido o de otra versión.")

    rs = payload.get("random_state", None)
    if rs is not None:
        try:
            random.setstate(rs)
        except Exception:
            # If random state doesn't match current Python version, ignore.
            pass

    return payload.get("ui")
