from __future__ import annotations

import abilities as AB

from dataclasses import dataclass
from typing import Dict, Optional, List, ClassVar
import re

from models import GameState, PlayerId, CharacterId, SectionId, ItemId, DataType, Item, OUT_OF_GAME_SECTION, OUTER_SPACE_SECTION


class ActionError(Exception):
    pass


@dataclass
class Action:
    # Engine-level global check can use this to skip self-preservation for debug/setup.
    enforce_self_preservation: ClassVar[bool] = True

    # Blackout global restriction (RM 7.2.2): Console/Section Actions On Board are disabled
    # except Timed Launch and Airlock.
    blackout_exempt: ClassVar[bool] = False

    def validate(self, state: GameState) -> None:
        raise NotImplementedError

    def apply(self, state: GameState) -> str:
        raise NotImplementedError




class SectionAction(Action):
    """Acción de sección (Room/Section Action)."""
    pass


class ConsoleAction(Action):
    """Console Action (RM 11.6 / 14.*)."""
    pass


# ---------------------------
# Helpers (Data/Jammers/Hazards)
# ---------------------------

def _norm_data(s: str) -> str:
    return re.sub(r"[^A-Z0-9]", "", str(s).upper())


def _is_escaped_or_annihilated(ch) -> bool:
    return bool(getattr(ch, "escaped", False)) or bool(getattr(ch, "annihilated", False))


def _section_has_human_down(state: GameState, sec: str) -> bool:
    """True si hay al menos un Human DOWN en la sección dada.

    Tratamos tipos compuestos (p. ej. "Human and Robot") como Human para este check.
    """
    sec = str(sec).upper()
    for c in getattr(state, 'characters', {}).values():
        if getattr(c, 'section', None) != sec:
            continue
        if _is_escaped_or_annihilated(c):
            continue
        if getattr(c, 'status', None) != 'DOWN':
            continue
        if 'HUMAN' in _norm_data(getattr(c, 'ctype', '')):
            return True
    return False


def _is_revealed_pc_non_innocent(state: GameState, cid: CharacterId) -> bool:
    """True si cid es un PC ya revelado y el jugador dueño NO está Innocent."""
    cid = str(cid).upper()
    for p in getattr(state, 'players', []) or []:
        if str(getattr(p, 'revealed_character', '') or '').upper() == cid:
            return str(getattr(p, 'legal', 'Innocent') or 'Innocent') != 'Innocent'
    return False

def _is_stowaway_undeployed(ch) -> bool:
    # Character Dossier: Stowaway starts off-board; first action must be a Step to any DARK section.
    try:
        name = str(getattr(ch, 'name', '') or '').strip().upper()
        cid = str(getattr(ch, 'cid', '') or '').strip().upper()
        sec = str(getattr(ch, 'section', '') or '').strip().upper()
        if name != 'STOWAWAY' and cid != 'C20':
            return False
        if sec != str(OUT_OF_GAME_SECTION).upper():
            return False
        counters = getattr(ch, 'counters', {}) or {}
        return int(counters.get('STOWAWAY_DEPLOYED', 0) or 0) == 0
    except Exception:
        return False



def _char_has_fugitive(state: GameState, cid: CharacterId) -> bool:
    ch = getattr(state, 'characters', {}).get(str(cid).upper())
    return bool(ch and getattr(ch, 'has_ability', lambda _x: False)(AB.FUGITIVE))


def _room_has_transmit(state: GameState, sec: str) -> bool:
    ra = getattr(state, "room_actions", {}).get(sec, [])
    for a in ra:
        if str(a).strip().lower().startswith("transmit:"):
            return True
    return False


def _room_has_cameras(state: GameState, sec: str) -> bool:
    ra = getattr(state, "room_actions", {}).get(sec, [])
    for a in ra:
        if str(a).strip().lower().startswith("cameras:"):
            return True
    return False



def _room_has_section_launch(state: GameState, sec: str) -> bool:
    ra = getattr(state, "room_actions", {}).get(sec, [])
    for a in ra:
        if "SECTION LAUNCH" in str(a).upper():
            return True
    return False


def _room_has_bridge_launch(state: GameState, sec: str) -> bool:
    ra = getattr(state, "room_actions", {}).get(sec, [])
    for a in ra:
        if "BRIDGE LAUNCH" in str(a).upper():
            return True
    return False


def _room_has_abandon_ship(state: GameState, sec: str) -> bool:
    ra = getattr(state, "room_actions", {}).get(sec, [])
    for a in ra:
        if "ABANDON SHIP" in str(a).upper():
            return True
    return False



def _room_has_release_project_x(state: GameState, sec: str) -> bool:
    ra = getattr(state, "room_actions", {}).get(sec, [])
    for a in ra:
        if "RELEASE PROJECT X" in str(a).upper():
            return True
    return False



def _room_has_self_destruct(state: GameState, sec: str) -> bool:
    """Section/Console Action: Self-Destruct (Bridge).

    Validación suave basada en `state.room_actions[sec]` (lo impreso/demo).
    """
    ra = getattr(state, "room_actions", {}).get(sec, [])
    for a in ra:
        if _norm_data(a) == "SELFDESTRUCT":
            return True
        # Permite variantes tipo "Self-Destruct" o con descripción
        if _norm_data(a).startswith("SELFDESTRUCT"):
            return True
    return False

def _room_has_decontaminate(state: GameState, sec: str) -> bool:
    ra = getattr(state, "room_actions", {}).get(sec, [])
    for a in ra:
        if "DECONTAMINATE" in str(a).upper():
            return True
    return False


def _room_has_meditate(state: GameState, sec: str) -> bool:
    ra = getattr(state, "room_actions", {}).get(sec, [])
    for a in ra:
        if "MEDITATE" in str(a).upper():
            return True
    return False


def _room_has_data_mine(state: GameState, sec: str) -> bool:
    ra = getattr(state, "room_actions", {}).get(sec, [])
    for a in ra:
        if _norm_data(a).startswith("DATAMINE"):
            return True
        if "DATA MINE" in str(a).upper():
            return True
    return False

def _room_has_rocket_wings_launch(state: GameState, sec: str) -> bool:
    ra = getattr(state, "room_actions", {}).get(sec, [])
    for a in ra:
        au = str(a).upper()
        if 'ROCKET' in au and 'WINGS' in au and 'LAUNCH' in au:
            return True
        if _norm_data(a).startswith('ROCKETWINGSLAUNCH'):
            return True
    return False







def _room_has_repair_robot(state: GameState, sec: str) -> bool:
    ra = getattr(state, "room_actions", {}).get(sec, [])
    for a in ra:
        # En el tablero aparece como "Repair" (Machine Shop). Permitimos variantes con descripción.
        if _norm_data(a).startswith("REPAIR"):
            return True
    return False



def _room_has_console(state: GameState, sec: str, key: str) -> bool:
    """
    Console actions (RM 11.6 / 14.*): sólo en secciones que, en tablero,
    tienen el icono de consola naranja.
    En el DEMO lo representamos como strings en state.room_actions:
      - "Console: Jammers"
      - "Console: Hazard Suppression"
    """
    want = _norm_data(key)
    ra = getattr(state, "room_actions", {}).get(sec, [])
    for a in ra:
        txt = str(a).strip()
        if not txt.lower().startswith("console:"):
            continue
        after = txt.split(":", 1)[1].strip()
        if _norm_data(after).startswith(want):
            return True
    return False


def _any_section_has_console(state: GameState, key: str) -> bool:
    """True si existe AL MENOS una sección (no dañada) con esa Console Action impresa.

    Se usa para HACKER (Exile): con Jammers OFF puede ejecutar Console Actions
    desde cualquier sitio, pero sólo si la consola existe y no está dañada.
    """
    want = _norm_data(key)
    damaged = set(getattr(state, 'damaged_sections', set()) or set())
    room_actions = getattr(state, 'room_actions', {}) or {}
    for sec, ra in room_actions.items():
        if sec in damaged:
            continue
        for a in (ra or []):
            txt = str(a).strip()
            if not txt.lower().startswith('console:'):
                continue
            after = txt.split(':', 1)[1].strip()
            if _norm_data(after).startswith(want):
                return True
    return False


def _find_printed_manufacture(state: GameState, sec: str, kind_norm: str, spec_norm: str) -> Optional[str]:
    room_actions = getattr(state, "room_actions", {}).get(sec, [])
    for a in room_actions:
        txt = str(a).strip()
        m = re.match(r"(?i)^\s*manufacture\s*:\s*(.*?)\s*\(\s*(data|item)\s*\)\s*$", txt)
        if not m:
            continue
        printed_spec_raw = m.group(1).strip()
        printed_kind = _norm_data(m.group(2))
        printed_spec = _norm_data(printed_spec_raw)
        if printed_kind == kind_norm and printed_spec == spec_norm:
            return printed_spec_raw.upper()
    return None


def _find_nanogel_item(state: GameState, cid: CharacterId) -> Optional[ItemId]:
    ch = state.characters[cid]
    for iid in list(ch.items):
        it = state.items.get(iid)
        if it and it.is_nanogel():
            return iid
    return None

def _is_bomb_item(state: GameState, iid: ItemId) -> bool:
    it = getattr(state, 'items', {}).get(str(iid).upper())
    return bool(it and getattr(it, 'is_bomb', None) and it.is_bomb())


def _integral_bound_to(state: GameState, iid: ItemId) -> Optional[CharacterId]:
    """RM 8.4: Integral Items.

    Devuelve el CharacterId al que este Item es integral, o None si no lo es.
    """
    it = getattr(state, 'items', {}).get(str(iid).upper())
    return getattr(it, 'integral_bound_to', None) if it else None


def _detonate_bomb_place_fire(state: GameState, iid: ItemId, sec: SectionId) -> str:
    """Homebrew: detonate a Bomb token, creating FIRE (and thus damaging the room).

    - Removes the item token from the board.
    - Adds FIRE hazard to the section (GameState.add_hazard will also damage the section).
    - Does NOT call apply_hazard_effects; callers should do it once at the end of the action.
    """
    iid = str(iid).upper()
    sec = str(sec).upper()

    # Remove token from the section (consumed).
    arr = getattr(state, 'section_items', {}).get(sec, [])
    if iid in arr:
        arr.remove(iid)

    try:
        state.add_hazard(sec, 'FIRE')
    except Exception as e:
        raise ActionError(str(e))

    return f"💣 BOOM: {iid} detona en {sec} -> FIRE"



# ---------------------------
# Debug / utility actions
# ---------------------------

@dataclass
class SetCharacterStatus(Action):
    enforce_self_preservation: ClassVar[bool] = False
    """
    Acción de debug para tests:
      - status: "LIVE" / "DOWN"
      - escaped: True/False
      - annihilated: True/False (si True -> section OUT_OF_GAME)
    """
    character: CharacterId
    status: Optional[str] = None
    escaped: Optional[bool] = None
    annihilated: Optional[bool] = None

    def validate(self, state: GameState) -> None:
        if self.character not in state.characters:
            raise ActionError("Ese personaje no existe.")
        if self.status is not None:
            st = str(self.status).upper()
            if st not in ("LIVE", "DOWN"):
                raise ActionError("status debe ser LIVE o DOWN.")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        ch = state.characters[self.character]
        parts: List[str] = [f"DEBUG: STATUS {self.character}"]

        if self.status is not None:
            ch.status = str(self.status).upper()
            parts.append(f"status={ch.status}")
            if ch.status == 'LIVE':
                pass

        if self.escaped is not None:
            ch.escaped = bool(self.escaped)
            parts.append(f"escaped={ch.escaped}")

        if self.annihilated is not None:
            ch.annihilated = bool(self.annihilated)
            parts.append(f"annihilated={ch.annihilated}")
            if ch.annihilated:
                # Usa la regla completa: Character + posesiones
                if hasattr(state, "annihilate_character"):
                    state.annihilate_character(self.character, reason="DEBUG")
                else:
                    ch.section = OUT_OF_GAME_SECTION
                    ch.status = "DOWN"
        return " | ".join(parts)


@dataclass
class SetHazard(Action):
    enforce_self_preservation: ClassVar[bool] = False
    """Debug: añade un Hazard a una sección (FIRE / ASPHYX)."""
    section: SectionId
    kind: str

    def validate(self, state: GameState) -> None:
        if not self.section:
            raise ActionError("Falta sección.")
        if hasattr(state, "is_outer_space") and state.is_outer_space(self.section):
            raise ActionError("Outer Space: su ASPHYX es permanente y no se modifica por debug.")
        if not self.kind:
            raise ActionError("Falta tipo de hazard.")
        k = _norm_data(self.kind)
        if k not in ("FIRE", "ASPHYX"):
            raise ActionError("Hazard desconocido. Usa: FIRE | ASPHYX")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        sec = str(self.section).upper()
        try:
            state.add_hazard(sec, self.kind)
        except ValueError as e:
            raise ActionError(str(e))
        # aplicar efectos inmediatos (6.1 / 6.5.2)
        msgs = state.apply_hazard_effects()
        extra = (" | " + " | ".join(msgs)) if msgs else ""
        return f"DEBUG: HAZARD +{_norm_data(self.kind)} en {sec}{extra}"


@dataclass
class ClearHazard(Action):
    enforce_self_preservation: ClassVar[bool] = False
    """Debug: quita hazards de una sección (o uno concreto)."""
    section: SectionId
    kind: Optional[str] = None

    def validate(self, state: GameState) -> None:
        if not self.section:
            raise ActionError("Falta sección.")
        if hasattr(state, "is_outer_space") and state.is_outer_space(self.section):
            raise ActionError("Outer Space: su ASPHYX no puede ser removido.")
        if hasattr(state, "is_outer_space") and state.is_outer_space(self.section):
            raise ActionError("Outer Space: su ASPHYX es permanente y no se puede borrar.")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        sec = str(self.section).upper()
        if sec not in state.hazards:
            return f"DEBUG: HAZARD nada que borrar en {sec}"
        if self.kind is None:
            state.hazards.pop(sec, None)
            return f"DEBUG: HAZARD cleared en {sec}"
        want = _norm_data(self.kind)
        state.hazards[sec] = {h for h in state.hazards[sec] if _norm_data(h) != want}
        if not state.hazards[sec]:
            state.hazards.pop(sec, None)
        return f"DEBUG: HAZARD -{want} en {sec}"


# ---------------------------
# Console Actions (RM 11.6 / 14.*) - DEMO
# ---------------------------

@dataclass
class HazardSuppression(ConsoleAction):
    """
    RM 14.1 Hazard Suppression (Console Action):
      In one Section, exchange a Fire Hazard for an Asphyxiation Hazard,
      or remove an Asphyxiation Hazard.

    En demo: requiere estar en una sección con "Console: Hazard Suppression"
    y que esa sección no esté Dañada (RM 11.6 + 12.10).
    """
    target_section: SectionId
    use_free_slot: bool = False
    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        ch = state.characters[actor]

        # HACKER (Exile): puede usar su Free Pick Up/Drop para hacer UNA Console Action.
        # Si JAMMERS está OFF, puede hacerlo desde cualquier sección (sin estar sobre la consola).
        ctu = str(getattr(ch, 'ctype', '')).upper()
        is_hr = ('HUMAN' in ctu) or ('ROBOT' in ctu)
        can_hacker_free = ch.has_ability(AB.HACKER) and is_hr and (not getattr(state, 'free_pickdrop_used', False))

        # Auto (HACKER): si queda el slot "Free Pick Up/Drop" disponible,
        # se usa AUTOMATICAMENTE para la Console Action (no hace falta pedir [free]).
        if (not self.use_free_slot) and can_hacker_free:
            self.use_free_slot = True

        if self.use_free_slot:
            if not can_hacker_free:
                raise ActionError('No puedes usar HACKER ahora (slot free ya usado o no aplica).')
        else:
            if state.remaining_actions() <= 0:
                raise ActionError('No te quedan acciones.')

        sec = state.characters[actor].section

        remote_ok = bool(self.use_free_slot) and ch.has_ability(AB.HACKER) and (not getattr(state, 'jammers_on', False))
        if remote_ok:
            # Debe existir al menos una consola operativa impresa en el mapa.
            if not _any_section_has_console(state, 'HAZARD SUPPRESSION'):
                raise ActionError('No existe una Console: Hazard Suppression operativa en el mapa.')
        else:
            if sec in getattr(state, 'damaged_sections', set()):
                raise ActionError('La sección está dañada: no puedes usar su Console Action.')
            if not _room_has_console(state, sec, 'HAZARD SUPPRESSION'):
                raise ActionError('Esta sección no tiene Console: Hazard Suppression (según lo impreso/demo).')

        if not self.target_section:
            raise ActionError('Falta target_section.')
        # Outer Space: su ASPHYX no se puede quitar (RM 5.1.7.2 / 6.4).
        if _norm_data(self.target_section) in ('OUTERSPACE', 'OUTER_SPACE'):
            raise ActionError('Outer Space: su Asphyxiation Hazard no puede ser removido.')

        hs = state.hazards.get(self.target_section, set())
        kinds = {_norm_data(x) for x in hs}
        if 'FIRE' not in kinds and 'ASPHYX' not in kinds:
            raise ActionError('En esa sección no hay FIRE ni ASPHYX que suprimir.')

    def apply(self, state: GameState) -> str:
        self.validate(state)
        tgt = self.target_section

        hs = state.hazards.get(tgt, set())
        kinds = {_norm_data(x) for x in hs}

        def _pay_cost():
            if self.use_free_slot:
                state.free_pickdrop_used = True
                return 'free(HACKER)'
            state.spend_action_point(1)
            return 'action'

        # 14.1: Fire -> Asphyx (exchange)
        if 'FIRE' in kinds:
            hs2 = {x for x in hs if _norm_data(x) != 'FIRE'}
            hs2.add('ASPHYX')
            state.hazards[tgt] = hs2
            cost = _pay_cost()
            msgs = state.apply_hazard_effects()
            extra = (' | ' + ' | '.join(msgs)) if msgs else ''
            return f"Console: HAZARD SUPPRESSION en {tgt}: FIRE -> ASPHYX | coste={cost}{extra}"

        # 14.1: remove Asphyx
        hs2 = {x for x in hs if _norm_data(x) != 'ASPHYX'}
        if hs2:
            state.hazards[tgt] = hs2
        else:
            state.hazards.pop(tgt, None)
        cost = _pay_cost()
        msgs = state.apply_hazard_effects()
        extra = (' | ' + ' | '.join(msgs)) if msgs else ''
        return f"Console: HAZARD SUPPRESSION en {tgt}: ASPHYX removido | coste={cost}{extra}"




# ---------------------------
# Core actions (demo)
# ---------------------------

@dataclass
class Reveal(Action):
    def validate(self, state: GameState) -> None:
        cp = state.current_player()
        if cp.revealed_character is not None:
            raise ActionError("Ya has revelado tu PC.")
        if not cp.secret_identity:
            raise ActionError("En esta demo no tienes PC asignado (secret_identity).")
        if state.active_character_id is not None:
            raise ActionError("No puedes Reveal después de activar.")
        if cp.turn_influence_target is not None:
            raise ActionError("No puedes Reveal después de colocar Influence.")
        if cp.turn_renegotiated:
            raise ActionError("No puedes Reveal después de renegotiate.")

    def apply(self, state: GameState) -> str:
        cp = state.current_player()
        pcid = cp.secret_identity
        assert pcid is not None

        cp.revealed_character = pcid
        if not bool(getattr(state, 'stationfall_mode', False)):
            cp.revealed_prior_to_stationfall = True
        if pcid in state.characters:
            state.characters[pcid].pc_owner = cp.pid
            if not bool(getattr(state, 'stationfall_mode', False)):
                state.characters[pcid].pc_reveal_active = True

        moved_to_supply = 0
        moved_to_betrayal: Dict[PlayerId, int] = {}

        for p in state.players:
            n = state.influence_of(p.pid, pcid)
            if n <= 0:
                continue
            state.set_influence_of(p.pid, pcid, 0)
            if p.pid == cp.pid:
                cp.supply_cubes += n
                moved_to_supply += n
            else:
                p.betrayal_cubes += n
                moved_to_betrayal[p.pid] = moved_to_betrayal.get(p.pid, 0) + n

        # MEDICAL marker (Character Dossier): +1 por cada cube que va a BETRAYAL cuando Medical se revela.
        medical_marker_msg = ''
        try:
            if pcid in state.characters and str(getattr(state.characters[pcid], 'name', '')).strip().upper() == 'MEDICAL':
                n_betr = 0
                for _n in (moved_to_betrayal.values() or []):
                    try:
                        n_betr += int(_n)
                    except Exception:
                        pass
                if n_betr > 0 and hasattr(state, 'inc_character_counter'):
                    mk = state.inc_character_counter(pcid, 'MEDICAL_MARKER', n_betr, cap=11)
                    medical_marker_msg = 'Medical marker -> ' + str(mk)
        except Exception:
            pass


        
        ability_grant_msgs: List[str] = []
        if (not bool(getattr(state, 'stationfall_mode', False))) and hasattr(state, 'apply_pc_reveal_ability_grants'):
            try:
                ability_grant_msgs = list(state.apply_pc_reveal_ability_grants(pcid))
            except Exception:
                ability_grant_msgs = []
# RM 4.5.3.1: Reveal Powers que proporcionan Items pueden forzar un DROP inmediato
        # si el Character ya estaba en su Item Limit. (En el prototipo, esto encola un
        # "free drop" para que el UI pida la elección.)
        grant_msgs: List[str] = []
        if (not bool(getattr(state, 'stationfall_mode', False))) and hasattr(state, 'apply_pc_reveal_item_grants'):
            try:
                grant_msgs = list(state.apply_pc_reveal_item_grants(cp.pid, pcid))
            except Exception:
                grant_msgs = []

        auto_msgs: List[str] = []
        if (not bool(getattr(state, 'stationfall_mode', False))) and hasattr(state, 'apply_pc_reveal_auto_powers'):
            try:
                auto_msgs = list(state.apply_pc_reveal_auto_powers(cp.pid, pcid))
            except Exception:
                auto_msgs = []


        # Reveal Powers (one-shot) que requieren elección inmediata (p.ej. Counselor, Engineer).
        if (not bool(getattr(state, 'stationfall_mode', False))) and hasattr(state, 'enqueue_pc_reveal_powers'):
            try:
                state.enqueue_pc_reveal_powers(cp.pid, pcid)
            except Exception:
                pass
        parts = [f"Paso: REVEAL {pcid} | +{moved_to_supply} a tu supply"]
        if medical_marker_msg:
            parts.append(medical_marker_msg)
        if moved_to_betrayal:
            extras = ", ".join([f"{pid}=+{n}" for pid, n in moved_to_betrayal.items()])
            parts.append(f"others -> Betrayal: {extras}")

        
        if ability_grant_msgs:
            parts.extend(ability_grant_msgs)
        if grant_msgs:
            parts.extend(grant_msgs)
        if auto_msgs:
            parts.extend(auto_msgs)
        return " | ".join(parts)


class SchrodingerReveal(Action):
    """Schrödinger Reveal (RM 3.5.1).

    Cuando un jugador se revela, puede optar por revelar su Bonus Character como PC:
      - El Bonus Character pasa a ser tu PC.
      - Pierdes tu Secret Identity original.
      - No puntúas Bonus Points al final (porque ya no tienes BC separado).

    Este prototipo lo implementa cambiando la identidad del jugador y desactivando
    los Bonus Points con `bonus_points_disabled=True`.
    """

    def validate(self, state: GameState) -> None:
        cp = state.current_player()
        if cp.revealed_character is not None:
            raise ActionError("Ya has revelado tu PC.")
        if not cp.secret_identity:
            raise ActionError("En esta demo no tienes PC asignado (secret_identity).")
        if not getattr(cp, 'bonus_character', None):
            raise ActionError("No tienes Bonus Character asignado (bonus_character).")
        if state.active_character_id is not None:
            raise ActionError("No puedes Reveal después de activar.")
        if cp.turn_influence_target is not None:
            raise ActionError("No puedes Reveal después de colocar Influence.")
        if cp.turn_renegotiated:
            raise ActionError("No puedes Reveal después de renegotiate.")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        cp = state.current_player()

        old_pc = cp.secret_identity
        new_pc = getattr(cp, 'bonus_character', None)
        assert old_pc is not None
        assert new_pc is not None

        # --- Stranger: ENIGMA (Character Dossier)
        # Caso especial: si este Schrödinger Reveal revela a STRANGER como tu nuevo PC:
        #   (1) STRANGER pierde la habilidad UNCANNY.
        #   (2) La antigua Secret Identity NO se descarta: pasa a ser tu nuevo Bonus Character (secreto).
        #       (Por tanto, Bonus Points NO se desactivan.)
        def _nm(x: str) -> str:
            return re.sub(r"[^A-Z0-9]", "", str(x).upper())

        new_is_stranger = False
        try:
            if new_pc in state.characters:
                new_is_stranger = (_nm(getattr(state.characters[new_pc], 'name', '')) == _nm('Stranger'))
        except Exception:
            new_is_stranger = False

        # Activamos ENIGMA sólo si STRANGER la tiene como Reveal Power.
        has_enigma = False
        try:
            if new_pc in state.characters:
                pw = set(getattr(state.characters[new_pc], 'pc_reveal_powers', set()) or set())
                pw_u = {str(p).strip().upper() for p in pw}
                has_enigma = (AB.ENIGMA in pw_u)
        except Exception:
            has_enigma = False

        enigma_active = bool(new_is_stranger and has_enigma)

        # El BC se convierte en PC
        cp.secret_identity = new_pc
        cp.revealed_character = new_pc
        if not bool(getattr(state, 'stationfall_mode', False)):
            cp.revealed_prior_to_stationfall = True
        if new_pc in state.characters:
            state.characters[new_pc].pc_owner = cp.pid
            if not bool(getattr(state, 'stationfall_mode', False)):
                state.characters[new_pc].pc_reveal_active = True

        if enigma_active:
            # (1) Stranger pierde Uncanny al revelarse vía Schrödinger.
            try:
                st = state.characters.get(str(new_pc).upper())
                if st is not None:
                    abil = set(getattr(st, 'abilities', set()) or set())
                    # Aseguramos normalización mínima
                    abil2 = {str(a).strip().upper() for a in abil}
                    if AB.UNCANNY in abil2:
                        # Eliminamos el string original si existe, y también el normalizado
                        for a in list(getattr(st, 'abilities', set()) or set()):
                            if str(a).strip().upper() == 'UNCANNY':
                                try:
                                    st.abilities.discard(a)
                                except Exception:
                                    pass
                        try:
                            st.abilities.discard(AB.UNCANNY)
                        except Exception:
                            pass
            except Exception:
                pass

            # (2) El PC anterior se convierte en tu nuevo BC (secreto).
            cp.bonus_points_disabled = False
            cp.bonus_character = old_pc
            cp.bonus_character_public = False
            # NOTA: bonus_kind/bonus_icons permanecen como estaban en este prototipo.
        else:
            # Pierdes bonus points al final (comportamiento estándar del Schrödinger Reveal)
            cp.bonus_points_disabled = True
            cp.bonus_character = None
            cp.bonus_kind = None
            cp.bonus_icons = 0

        # Beneficios del Reveal: se retira Influence del PC revelado
        moved_to_supply = 0
        moved_to_betrayal: Dict[PlayerId, int] = {}
        for p in state.players:
            n = state.influence_of(p.pid, new_pc)
            if n <= 0:
                continue
            state.set_influence_of(p.pid, new_pc, 0)
            if p.pid == cp.pid:
                cp.supply_cubes += n
                moved_to_supply += n
            else:
                p.betrayal_cubes += n
                moved_to_betrayal[p.pid] = moved_to_betrayal.get(p.pid, 0) + n

        # MEDICAL marker (Character Dossier): +1 por cada cube que va a BETRAYAL cuando Medical se revela.
        medical_marker_msg = ''
        try:
            if new_pc in state.characters and str(getattr(state.characters[new_pc], 'name', '')).strip().upper() == 'MEDICAL':
                n_betr = 0
                for _n in (moved_to_betrayal.values() or []):
                    try:
                        n_betr += int(_n)
                    except Exception:
                        pass
                if n_betr > 0 and hasattr(state, 'inc_character_counter'):
                    mk = state.inc_character_counter(new_pc, 'MEDICAL_MARKER', n_betr, cap=11)
                    medical_marker_msg = 'Medical marker -> ' + str(mk)
        except Exception:
            pass


        
        ability_grant_msgs: List[str] = []
        if (not bool(getattr(state, 'stationfall_mode', False))) and hasattr(state, 'apply_pc_reveal_ability_grants'):
            try:
                ability_grant_msgs = list(state.apply_pc_reveal_ability_grants(new_pc))
            except Exception:
                ability_grant_msgs = []
        grant_msgs: List[str] = []
        if (not bool(getattr(state, 'stationfall_mode', False))) and hasattr(state, 'apply_pc_reveal_item_grants'):
            try:
                grant_msgs = list(state.apply_pc_reveal_item_grants(cp.pid, new_pc))
            except Exception:
                grant_msgs = []

        auto_msgs: List[str] = []
        if (not bool(getattr(state, 'stationfall_mode', False))) and hasattr(state, 'apply_pc_reveal_auto_powers'):
            try:
                auto_msgs = list(state.apply_pc_reveal_auto_powers(cp.pid, new_pc))
            except Exception:
                auto_msgs = []

        parts = [
            f"Paso: SCHRODINGER REVEAL {new_pc} (antes PC={old_pc} → perdido) | +{moved_to_supply} a tu supply",
            "Bonus Points: DESACTIVADOS" if not enigma_active else f"ENIGMA: {old_pc} pasa a ser tu nuevo BC; STRANGER pierde UNCANNY; Bonus Points: ACTIVOS",
        ]
        if medical_marker_msg:
            parts.append(medical_marker_msg)
        if moved_to_betrayal:
            extras = ", ".join([f"{pid}=+{n}" for pid, n in moved_to_betrayal.items()])
            parts.append(f"others -> Betrayal: {extras}")

        # Reveal Powers (one-shot) que requieren elección inmediata (p.ej. Counselor).
        if (not bool(getattr(state, 'stationfall_mode', False))) and hasattr(state, 'enqueue_pc_reveal_powers'):
            try:
                state.enqueue_pc_reveal_powers(cp.pid, new_pc)
            except Exception:
                pass

        if ability_grant_msgs:
            parts.extend(ability_grant_msgs)

        if grant_msgs:
            parts.extend(grant_msgs)
        if auto_msgs:
            parts.extend(auto_msgs)
        return " | ".join(parts)


@dataclass
class TeleportCharacter(Action):
    """Debug: teletransporta un Character a cualquier sección para testear.

    - NO consume acciones.
    - Ignora adyacencia/LOCKS/VENTS.
    - Mantiene flags (LIVE/DOWN, etc.) tal cual; solo cambia `section`.
    - Aplica efectos inmediatos de Hazards tras mover (como MOVE).

    Nota: si el Character está ESCAPED o ANNIHILATED, primero desactiva esos flags
    con `escape <CID> off` / `annihilate <CID> off`.
    """

    character: CharacterId
    to_section: SectionId

    enforce_self_preservation: ClassVar[bool] = False

    def validate(self, state: GameState) -> None:
        if not self.character or self.character not in state.characters:
            raise ActionError("Ese personaje no existe.")
        if not self.to_section:
            raise ActionError("Uso: tp <CID> <SEC>")

        ch = state.characters[self.character]
        if getattr(ch, "escaped", False):
            raise ActionError("Ese Character está ESCAPED. Usa: escape <CID> off")
        if getattr(ch, "annihilated", False):
            raise ActionError("Ese Character está ANNIHILATED. Usa: annihilate <CID> off")

        dest = str(self.to_section).upper()

        # Permitir secciones especiales conocidas
        if dest in (OUTER_SPACE_SECTION, OUT_OF_GAME_SECTION, "MESO"):
            return

        # Debe existir en el grafo o ser un Pod conocido
        if dest not in state.graph and not (getattr(state, "is_pod", None) and state.is_pod(dest)):
            raise ActionError(f"Sección desconocida: {dest}")

        # Si es Pod, debe estar ON_BOARD (para evitar estados raros)
        if getattr(state, "is_pod", None) and state.is_pod(dest):
            pod = state.pods.get(dest)
            if not pod:
                raise ActionError("Pod desconocido.")
            if getattr(pod, "location", None) != "ON_BOARD":
                raise ActionError(f"Ese Pod no está ON_BOARD (estado={pod.location}).")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        cid = str(self.character).upper()
        dest = str(self.to_section).upper()
        ch = state.characters[cid]
        frm = str(getattr(ch, "section", ""))
        ch.section = dest

        msgs = state.apply_hazard_effects() if hasattr(state, "apply_hazard_effects") else []
        extra = (" | " + " | ".join(msgs)) if msgs else ""

        return f"DEBUG: TP {cid} ({frm} -> {dest}){extra}"


@dataclass
class PlaceInfluence(Action):
    target: CharacterId
    amount: int = 1

    def validate(self, state: GameState) -> None:
        cp = state.current_player()
        if state.active_character_id is not None:
            raise ActionError("No puedes colocar Influence después de activar.")
        if cp.turn_renegotiated:
            raise ActionError("No puedes colocar Influence después de renegotiate.")
        if self.amount <= 0:
            raise ActionError("amount debe ser >= 1.")
        if self.target not in state.characters:
            raise ActionError("Ese personaje no existe.")
        if state.is_pc(self.target):
            raise ActionError("No puedes colocar Influence en un PC.")
        ch = state.characters[self.target]
        # Homebrew: Tripa del Tentacled. No se puede interactuar con nada dentro.
        try:
            if hasattr(state, 'is_tentaculous_gut') and state.is_tentaculous_gut(getattr(ch, 'section', '')):
                raise ActionError("No puedes colocar Influence en un personaje dentro de la TRIPA DEL TENTACULOUS.")
        except ActionError:
            raise
        except Exception:
            pass
        if ch.annihilated:
            raise ActionError("No puedes influenciar a un personaje ANNIHILATED.")
        if ch.escaped:
            raise ActionError("No puedes influenciar a un personaje ESCAPED.")
        if not ch.is_live():
            raise ActionError("No puedes influenciar a un personaje que no esté LIVE.")

        # LOYAL (Character Dossier: Astrochimp):
        # To Influence, return ALL cubes on this card (de todos los jugadores) y luego
        # place at least 1 more cube than was previously here.
        cur = state.influence_of(cp.pid, self.target)

        # HELPFUL (Character Dossier: Medical):
        # Ningún jugador puede tener más de 1 cube de Influence en este Character.
        # Nota: si un Character tuviera además LOYAL, el total final sería `amount` (porque se devuelven antes los cubos).
        if ch.has_ability(AB.HELPFUL):
            final_for_me = self.amount if ch.has_ability(AB.LOYAL) else (cur + self.amount)
            if final_for_me > 1:
                raise ActionError("HELPFUL: máximo 1 cubo de Influence por jugador en este Character.")

        if ch.has_ability(AB.LOYAL):
            total_prev = 0
            for p in state.players:
                total_prev += state.influence_of(p.pid, self.target)
            min_needed = total_prev + 1
            if self.amount < min_needed:
                raise ActionError(f"LOYAL: debes colocar al menos {min_needed} (había {total_prev} en total).")
            # Recuperas tus cubos antes de pagar, así que solo necesitas la diferencia desde supply.
            needed_from_supply = self.amount - cur
        else:
            needed_from_supply = self.amount

        if cp.supply_cubes < needed_from_supply:
            raise ActionError("No tienes cubos suficientes en el suministro.")
        if cp.turn_influence_target is not None:
            raise ActionError("Ya colocaste Influence este turno.")

    def apply(self, state: GameState) -> str:
        cp = state.current_player()
        ch = state.characters[self.target]
        cur = state.influence_of(cp.pid, self.target)

        if ch.has_ability(AB.LOYAL):
            # LOYAL: devuelve TODOS los cubos de esta carta a sus dueños y luego coloca `amount`.
            total_prev = 0
            removed_parts = []
            for p in state.players:
                n = state.influence_of(p.pid, self.target)
                if n:
                    total_prev += n
                    p.supply_cubes += n
                    state.set_influence_of(p.pid, self.target, 0)
                    removed_parts.append(f"{p.pid}:{n}")

            cp.supply_cubes -= self.amount
            state.set_influence_of(cp.pid, self.target, self.amount)
            cp.turn_influence_target = self.target

            removed_txt = ", ".join(removed_parts) if removed_parts else "0"
            return (
                f"Paso: INFLUENCE (LOYAL) devuelve {total_prev} ({removed_txt}) y coloca {self.amount} en {self.target} "
                f"| total={self.amount} | suministro={cp.supply_cubes}"
            )

        # Normal
        cp.supply_cubes -= self.amount
        state.set_influence_of(cp.pid, self.target, cur + self.amount)
        cp.turn_influence_target = self.target
        return f"Paso: INFLUENCE +{self.amount} en {self.target} | total={cur + self.amount} | suministro={cp.supply_cubes}"


@dataclass
class RenegotiateTakeBack(Action):
    """RM 15.6 Renegotiate

    15.6.1. En vez de Activar, recoge tu Activation Disc a tu suministro.
    15.6.2. Opcionalmente, también puedes recuperar 1 de tus cubos de Influence
           desde un Character que NO esté ESCAPED ni ANNIHILATED.
    """
    from_character: Optional[CharacterId] = None

    def validate(self, state: GameState) -> None:
        cp = state.current_player()
        if state.active_character_id is not None:
            raise ActionError("No puedes renegotiate después de activar.")
        if cp.turn_renegotiated:
            raise ActionError("Ya renegotiate este turno.")

        # Recuperar 1 cubo (opcional)
        if self.from_character is not None:
            if self.from_character not in state.characters:
                raise ActionError("Ese personaje no existe.")
            ch = state.characters[self.from_character]
            # Homebrew: Tripa del Tentacled. No se puede interactuar con nada dentro.
            try:
                if hasattr(state, 'is_tentaculous_gut') and state.is_tentaculous_gut(getattr(ch, 'section', '')):
                    raise ActionError("No puedes renegotiate con un personaje dentro de la TRIPA DEL TENTACULOUS.")
            except ActionError:
                raise
            except Exception:
                pass
            if ch.annihilated:
                raise ActionError("No puedes renegotiate con un personaje ANNIHILATED.")
            if ch.escaped:
                raise ActionError("No puedes renegotiate con un personaje ESCAPED.")
            cur = state.influence_of(cp.pid, self.from_character)
            if cur < 1:
                raise ActionError("No tienes cubos para devolver desde ese personaje.")

    def apply(self, state: GameState) -> str:
        cp = state.current_player()

        # 15.6.1: recoger disco (si estaba en algún Character)
        prev_disc = cp.activation_disc
        cp.activation_disc = None

        extra = ""
        if self.from_character is not None:
            # 15.6.2: recuperar EXACTAMENTE 1 cubo
            cur = state.influence_of(cp.pid, self.from_character)
            state.set_influence_of(cp.pid, self.from_character, cur - 1)
            cp.supply_cubes += 1
            extra = f" + devuelve 1 cube desde {self.from_character}"

        cp.turn_renegotiated = True

        disc_txt = "recoge su Activation Disc"
        if prev_disc is not None:
            disc_txt += f" (estaba en {prev_disc})"
        return f"Paso: RENEGOTIATE: {disc_txt}{extra} | suministro={cp.supply_cubes}"



@dataclass
class Activate(Action):
    character: CharacterId

    def validate(self, state: GameState) -> None:
        cp = state.current_player()
        if cp.turn_renegotiated:
            raise ActionError("No puedes activar después de renegotiate.")
        if state.active_character_id is not None:
            raise ActionError("Ya has activado un personaje este turno.")
        if self.character not in state.characters:
            raise ActionError("Ese personaje no existe.")
        ch = state.characters[self.character]
        # Homebrew: Tripa del Tentacled. No se puede interactuar con nada dentro.
        try:
            if hasattr(state, 'is_tentaculous_gut') and state.is_tentaculous_gut(getattr(ch, 'section', '')):
                raise ActionError("No puedes activar a un personaje dentro de la TRIPA DEL TENTACULOUS.")
        except ActionError:
            raise
        except Exception:
            pass
        if ch.annihilated:
            raise ActionError("No puedes activar un personaje ANNIHILATED.")
        if ch.escaped:
            raise ActionError("No puedes activar un personaje ESCAPED.")
        if not ch.is_live():
            # SELF_REPAIR (Reveal Power, Cyborg): puedes activar tu PC estando DOWN.
            if not (ch.is_down() and ch.has_ability(AB.SELF_REPAIR) and str(getattr(ch, "pc_owner", "")) == str(cp.pid)):
                raise ActionError("No puedes activar un personaje que no esté LIVE.")
        if not state.is_conspirator(cp.pid, self.character):
            # SELF_REPAIR permite activar tu PC aun estando DOWN aunque no cuente como conspirator.
            if not (ch.is_down() and ch.has_ability(AB.SELF_REPAIR) and str(getattr(ch, "pc_owner", "")) == str(cp.pid)):
                raise ActionError("No puedes activar ese personaje (no eres conspirator).")

    def apply(self, state: GameState) -> str:
        cp = state.current_player()
        cid = self.character
        ch = state.characters[cid]
        # "Exhausted" depende de si el Character tiene algún Activation Disc encima
        # ANTES de colocar/mover el disco del jugador que activa.
        discs_prev = []
        if hasattr(state, "activation_discs_on"):
            discs_prev = state.activation_discs_on(cid)
        else:
            discs_prev = [p.pid for p in state.players if getattr(p, "activation_disc", None) == cid]

        state.active_character_id = cid
        # UNCANNY (Cyborg): solo está Exhausted con 2+ discos en la carta al activar.
        exhausted_threshold = 2 if ch.has_ability(AB.UNCANNY) else 1
        state.action_points_total = 1 if len(discs_prev) >= exhausted_threshold else 2
        state.action_points_used = 0
        state.free_pickdrop_used = False

        cp.activation_disc = cid

        repair_msg = ""
        if str(getattr(ch, 'status', '')).upper() == 'DOWN' and ch.has_ability(AB.SELF_REPAIR) and str(getattr(ch, 'pc_owner', '')) == str(cp.pid):
            # First action: Revive (no requiere Nanogel; consume 1 acción).
            ch.status = 'LIVE'
            state.spend_action_point(1)
            repair_msg = ' | 🔧 SELF-REPAIR: se revive (consume 1 acción)'

        # Mantener el flag "exhausted" sincronizado con la posición de los discos
        # (compatibilidad con versiones antiguas del prototipo).
        if hasattr(state, "refresh_exhausted_flags"):
            state.refresh_exhausted_flags()

        # Activation Powers (p.ej. Station Chief: FORCEFUL_PRESENCE).
        # Si el personaje tiene alguno de estos tags de habilidad (normalmente desbloqueados al revelar),
        # la UI debe pedir una elección justo después de ACTIVATE.
        try:
            for tag in getattr(AB, 'ACTIVATION_POWER_TAGS', set()):
                if ch.has_ability(tag):
                    if not hasattr(state, 'pending_activation_power_queue') or getattr(state, 'pending_activation_power_queue', None) is None:
                        state.pending_activation_power_queue = []
                    state.pending_activation_power_queue.append({
                        'power': tag,
                        'pid': str(cp.pid),
                        'source': str(cid).upper(),
                    })
        except Exception:
            pass

        discs_txt = ",".join(discs_prev) if discs_prev else "-"
        return f"Paso: ACTIVATE {cid} (acciones={state.action_points_total}, discs_previos={discs_txt}){repair_msg}"


@dataclass
class Move(Action):
    to_section: SectionId

    def validate(self, state: GameState) -> None:
        cid = state.require_active()
        ch = state.characters[cid]
        frm = ch.section
        to = self.to_section

        # ADRENALINE (Daredevil): Step hacia una sección con Hazard es siempre FREE.
        adrenaline_free = False
        if ch.has_ability(AB.ADRENALINE) and hasattr(state, "section_has_hazard"):
            try:
                adrenaline_free = bool(state.section_has_hazard(to))
            except Exception:
                adrenaline_free = False

        # EMERGENCY_RESPONSE_BETA (Medical): Step hacia una sección con algún Human DOWN es siempre FREE.
        er_free = False
        if ch.has_ability(AB.EMERGENCY_RESPONSE_BETA):
            try:
                # No tiene sentido en Outer Space.
                if not (hasattr(state, 'is_outer_space') and state.is_outer_space(str(to).upper())):
                    er_free = _section_has_human_down(state, str(to).upper())
            except Exception:
                er_free = False

        # Nota: No aplicamos aquí reglas de "free move" como ZEROBORN.
        # Esta validación sólo prepara un "shadow activation" y delega el coste/validación
        # real de movimientos al subaction (Move/AirlockMove/etc.).

        zeroborn_free = False
        if ch.has_ability(AB.ZEROBORN) and not getattr(state, 'free_pickdrop_used', False):
            try:
                if hasattr(state, 'section_has_gravity') and callable(getattr(state, 'section_has_gravity')):
                    zeroborn_free = (not state.section_has_gravity(to))
                else:
                    zg = {str(x).upper() for x in getattr(state, 'zero_g_sections', set())}
                    zeroborn_free = (str(to).upper() in zg) or (str(to).upper() in getattr(state, 'pods', {}))
            except Exception:
                zeroborn_free = False

        # STOWAWAY: entrada al tablero desde OUT_OF_GAME -> cualquier sección DARK (sin conexión/locks/vents)
        if _is_stowaway_undeployed(ch):
            to_u = str(to).upper()
            unlit = {str(x).upper() for x in getattr(state, 'unlit_sections', set())}
            if to_u not in unlit:
                raise ActionError('STOWAWAY: la primera acción debe ser MOVE a una sección DARK.')
            # Debe ser una sección On Board real (no MESO/OUTER_SPACE/OUT_OF_GAME)
            if hasattr(state, 'on_board_sections') and callable(getattr(state, 'on_board_sections')):
                if to_u not in {str(x).upper() for x in state.on_board_sections()}:
                    raise ActionError('STOWAWAY: destino inválido (debe ser una sección On Board).')
            if state.remaining_actions() <= 0:
                raise ActionError('No te quedan acciones.')
            return

        if state.remaining_actions() <= 0 and not (adrenaline_free or er_free or zeroborn_free):
            raise ActionError("No te quedan acciones.")

        # Normal corridor
        normal_ok = to in state.graph.get(frm, [])

        # Vent (solo TUNNEL RAT)
        vents_from = getattr(state, "vents", {}).get(frm, [])
        vent_ok = (to in vents_from) and state.effective_has_ability(cid, AB.TUNNEL_RAT)

        if not (normal_ok or vent_ok):
            if to in vents_from and not state.effective_has_ability(cid, AB.TUNNEL_RAT):
                raise ActionError("Esa conexión es un VENT: solo TUNNEL RAT puede usarla.")
            raise ActionError(f"No puedes ir de {frm} a {to} en 1 paso.")

        # LOCK (solo en corridors normales, no en vents)
        if normal_ok and getattr(state, "is_locked_corridor", None):
            if state.is_locked_corridor(frm, to):
                if getattr(state, "is_blackout", lambda: False)():
                    if not ch.has_ability(AB.JUGGERNAUT):
                        raise ActionError("Ese corredor está BLOQUEADO (LOCK). En BLACKOUT, solo JUGGERNAUT puede pasar (usa BREACH).")
                else:
                    if not (ch.has_ability(AB.OFFICER) or ch.has_ability(AB.JUGGERNAUT)):
                        raise ActionError("Ese corredor está BLOQUEADO (LOCK). Solo OFFICER o JUGGERNAUT puede pasar.")

        # Pods: límite de ocupantes (RM 5.5.3)
        if getattr(state, "is_pod", None) and state.is_pod(to):
            pod = state.pods.get(str(to).upper())
            if not pod:
                raise ActionError("Pod desconocido.")
            if pod.location != 'ON_BOARD':
                raise ActionError(f"Ese Pod no está ON_BOARD (estado={pod.location}).")
            lim = getattr(pod, 'occupancy_limit', None)
            if lim is not None:
                if not state.pod_can_accept(str(to).upper(), [cid]):
                    cur = state.pod_occupant_count(str(to).upper())
                    raise ActionError(f"Pod lleno: ocupantes={cur}, límite={lim}.")

    def apply(self, state: GameState) -> str:
        cid = state.require_active()
        ch = state.characters[cid]
        frm = ch.section
        to = self.to_section

        adrenaline_free = False
        if ch.has_ability(AB.ADRENALINE) and hasattr(state, "section_has_hazard"):
            try:
                adrenaline_free = bool(state.section_has_hazard(to))
            except Exception:
                adrenaline_free = False

        er_free = False
        if ch.has_ability(AB.EMERGENCY_RESPONSE_BETA):
            try:
                if not (hasattr(state, 'is_outer_space') and state.is_outer_space(str(to).upper())):
                    er_free = _section_has_human_down(state, str(to).upper())
            except Exception:
                er_free = False

        # Nota: No aplicamos aquí reglas de "free move" como ZEROBORN.
        # Esta validación sólo prepara un "shadow activation" y delega el coste/validación
        # real de movimientos al subaction (Move/AirlockMove/etc.).

        zeroborn_free = False
        if ch.has_ability(AB.ZEROBORN) and not getattr(state, 'free_pickdrop_used', False):
            try:
                if hasattr(state, 'section_has_gravity') and callable(getattr(state, 'section_has_gravity')):
                    zeroborn_free = (not state.section_has_gravity(to))
                else:
                    zg = {str(x).upper() for x in getattr(state, 'zero_g_sections', set())}
                    zeroborn_free = (str(to).upper() in zg) or (str(to).upper() in getattr(state, 'pods', {}))
            except Exception:
                zeroborn_free = False

        # STOWAWAY: entrada al tablero (teletransporte) — no hay LOCK/Vent checks aquí (ya validados)
        if _is_stowaway_undeployed(ch):
            ch.section = to
            counters = getattr(ch, 'counters', None)
            if counters is None:
                ch.counters = {}
                counters = ch.counters
            counters['STOWAWAY_DEPLOYED'] = 1
            state.spend_action_point(1)

            entry_msgs: List[str] = []
            if hasattr(state, 'apply_contamination_on_enter'):
                try:
                    entry_msgs.extend(list(state.apply_contamination_on_enter(cid)))
                except Exception:
                    pass
            hz_msgs = state.apply_hazard_effects() if hasattr(state, 'apply_hazard_effects') else []
            msgs = list(entry_msgs) + list(hz_msgs)
            extra = (' | ' + ' | '.join(msgs)) if msgs else ''
            return f"Acción: MOVE {cid} (OUT_OF_GAME -> {to}) | restantes={state.remaining_actions()} | STOWAWAY_ENTRY{extra}"

        # mover
        ch.section = to

        cost_msg = ""
        if adrenaline_free or er_free:
            reason = "ADRENALINE" if adrenaline_free else "EMERGENCY_RESPONSE"
            cost_msg = f" | coste=free({reason})"
        elif zeroborn_free:
            # Consume el slot gratis compartido con Free Pick/Drop
            state.free_pickdrop_used = True
            cost_msg = " | coste=free(ZEROBORN: usa free pick/drop)"
        else:
            state.spend_action_point(1)

        # Si cruzas un LOCK como OFFICER, el token se retira y el corredor queda normal.
        lock_msg = ""
        normal_ok = to in state.graph.get(frm, [])
        if normal_ok and getattr(state, "is_locked_corridor", None) and state.is_locked_corridor(frm, to):
            if (ch.has_ability(AB.JUGGERNAUT) or ((not getattr(state, "is_blackout", lambda: False)()) and ch.has_ability(AB.OFFICER))) and getattr(state, "remove_lock_corridor", None):
                state.remove_lock_corridor(frm, to)
                lock_msg = " | 🔓 LOCK retirado"

        entry_msgs: List[str] = []
        # Contamination (no es Hazard): al entrar en una sección contaminada, puedes ganar el token.
        if hasattr(state, 'apply_contamination_on_enter'):
            try:
                entry_msgs.extend(list(state.apply_contamination_on_enter(cid)))
            except Exception:
                pass

        # Hazards: al entrar, pueden tumbarte
        hz_msgs = state.apply_hazard_effects() if hasattr(state, 'apply_hazard_effects') else []

        msgs = list(entry_msgs) + list(hz_msgs)
        extra = (" | " + " | ".join(msgs)) if msgs else ""
        return f"Acción: MOVE {cid} ({frm} -> {to}) | restantes={state.remaining_actions()}{cost_msg}{lock_msg}{extra}"


@dataclass
class ZeroBornMove(Action):
    """Free Step into a zero-gravity (0G) section (ability: ZEROBORN).

    This uses the same once-per-turn FREE slot as the free PickUp/Drop
    (state.free_pickdrop_used). All normal movement rules apply: corridors,
    vents require TUNNEL RAT, LOCK restrictions, Pod occupancy limits, etc.
    """

    to_section: SectionId

    def validate(self, state: GameState) -> None:
        cid = state.require_active()
        ch = state.characters[cid]

        if not ch.has_ability(AB.ZEROBORN):
            raise ActionError('Solo un Character con ZEROBORN puede hacer este movimiento gratis.')

        # FREE slot (shared with free pick/drop)
        if getattr(state, 'free_pickdrop_used', False):
            raise ActionError('Ya has usado tu acción gratis (Pick/Drop o ZeroBorn Move) este turno.')

        frm = ch.section
        to = self.to_section

        # Destination must be 0G (no gravity)
        if hasattr(state, 'section_has_gravity') and callable(getattr(state, 'section_has_gravity')):
            if state.section_has_gravity(to):
                raise ActionError(f'{to} tiene gravedad. ZeroBorn solo permite entrar en secciones sin gravedad.')
        else:
            zg = {str(x).upper() for x in getattr(state, 'zero_g_sections', set())}
            if str(to).upper() not in zg and str(to).upper() not in getattr(state, 'pods', {}):
                raise ActionError(f'{to} tiene gravedad. ZeroBorn solo permite entrar en secciones sin gravedad.')

        # Normal corridor
        normal_ok = to in state.graph.get(frm, [])

        # Vent (solo TUNNEL RAT)
        vents_from = getattr(state, 'vents', {}).get(frm, [])
        vent_ok = (to in vents_from) and state.effective_has_ability(cid, AB.TUNNEL_RAT)

        if not (normal_ok or vent_ok):
            if to in vents_from and not state.effective_has_ability(cid, AB.TUNNEL_RAT):
                raise ActionError('Esa conexión es un VENT: solo TUNNEL RAT puede usarla.')
            raise ActionError(f'No puedes ir de {frm} a {to} en 1 paso.')

        # LOCK (solo en corridors normales, no en vents)
        if normal_ok and getattr(state, 'is_locked_corridor', None):
            if state.is_locked_corridor(frm, to):
                if getattr(state, 'is_blackout', lambda: False)():
                    if not ch.has_ability(AB.JUGGERNAUT):
                        raise ActionError('Ese corredor está BLOQUEADO (LOCK). En BLACKOUT, solo JUGGERNAUT puede pasar (usa BREACH).')
                else:
                    if not (ch.has_ability(AB.OFFICER) or ch.has_ability(AB.JUGGERNAUT)):
                        raise ActionError('Ese corredor está BLOQUEADO (LOCK). Solo OFFICER o JUGGERNAUT puede pasar.')

        # Pods: límite de ocupantes (RM 5.5.3)
        if getattr(state, 'is_pod', None) and state.is_pod(to):
            pod = state.pods.get(str(to).upper())
            if not pod:
                raise ActionError('Pod desconocido.')
            if pod.location != 'ON_BOARD':
                raise ActionError(f'Ese Pod no está ON_BOARD (estado={pod.location}).')
            lim = getattr(pod, 'occupancy_limit', None)
            if lim is not None:
                if not state.pod_can_accept(str(to).upper(), [cid]):
                    cur = state.pod_occupant_count(str(to).upper())
                    raise ActionError(f'Pod lleno: ocupantes={cur}, límite={lim}.')

    def apply(self, state: GameState) -> str:
        cid = state.require_active()
        ch = state.characters[cid]
        frm = ch.section
        to = self.to_section

        # move (FREE)
        ch.section = to
        state.free_pickdrop_used = True

        # Si cruzas un LOCK como OFFICER, el token se retira y el corredor queda normal.
        lock_msg = ''
        normal_ok = to in state.graph.get(frm, [])
        if normal_ok and getattr(state, 'is_locked_corridor', None) and state.is_locked_corridor(frm, to):
            if (ch.has_ability(AB.JUGGERNAUT) or ((not getattr(state, 'is_blackout', lambda: False)()) and ch.has_ability(AB.OFFICER))) and getattr(state, 'remove_lock_corridor', None):
                state.remove_lock_corridor(frm, to)
                lock_msg = ' | 🔓 LOCK retirado'

        entry_msgs = []
        # Contamination (no es Hazard): al entrar en una sección contaminada, puedes ganar el token.
        if hasattr(state, 'apply_contamination_on_enter'):
            try:
                entry_msgs.extend(list(state.apply_contamination_on_enter(cid)))
            except Exception:
                pass

        # Hazards: al entrar, pueden tumbarte
        hz_msgs = state.apply_hazard_effects() if hasattr(state, 'apply_hazard_effects') else []

        msgs = list(entry_msgs) + list(hz_msgs)
        extra = (' | ' + ' | '.join(msgs)) if msgs else ''
        return f'Acción: ZEROBORN MOVE {cid} ({frm} -> {to}) | coste=free{lock_msg}{extra}'


@dataclass
class ThrowItem(Action):
    """\
    THROW (demo):
    - El personaje activo tira un Item que lleva a una sección adyacente.
    - Solo por corredor normal (graph). No puede ser por VENTS.
    - No puede ser por LOCK (aunque seas OFFICER): si el corredor está bloqueado, no se puede.
    """

    item: ItemId
    to_section: SectionId
    detonate: bool = False  # solo si el item es una Bomb

    def validate(self, state: GameState) -> None:
        cid = state.require_active()
        ch = state.characters[cid]

        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        if not self.item:
            raise ActionError("Uso: throw <IID> <SEC>")
        if not self.to_section:
            raise ActionError("Uso: throw <IID> <SEC>")

        it = state.items.get(self.item)
        if it is None:
            raise ActionError("Ese item no existe.")
        if self.item not in ch.items:
            raise ActionError("No tienes ese item.")

        # RM 8.4: Integral Items no pueden tirarse.
        if _integral_bound_to(state, self.item):
            raise ActionError("Ese item es INTEGRAL y no puede THROWarse.")

        frm = ch.section
        to = self.to_section

        # No VENTS: si es adyacente por vent pero no por corredor normal, lo indicamos.
        if to not in state.graph.get(frm, []):
            if state.is_vent(frm, to):
                raise ActionError("No puedes THROW a través de un VENT.")
            raise ActionError(f"No puedes THROW de {frm} a {to} en 1 paso (no es corredor normal).")

        # No LOCKS
        if state.is_locked_corridor(frm, to):
            raise ActionError("No puedes THROW a través de un corredor LOCKED.")

        # Bomb (homebrew): si detona al caer, genera FIRE (y daña la sección).
        if self.detonate:
            if not _is_bomb_item(state, self.item):
                raise ActionError('Solo puedes detonar una Bomb al THROW.')
            if state.has_hazard_kind(to, 'ASPHYX'):
                raise ActionError('No puedes detonar una Bomb en una sección con ASPHYX (FIRE no puede empezar allí).')

    def apply(self, state: GameState) -> str:
        self.validate(state)

        cid = state.require_active()
        ch = state.characters[cid]
        frm = ch.section
        to = self.to_section

        ch.items.remove(self.item)
        state.section_items.setdefault(to, []).append(self.item)

        state.spend_action_point(1)
        it = state.items.get(self.item)
        name = it.name if it else self.item

        msg = f"Acción: THROW {self.item} ({name}) {cid} ({frm} -> {to}) | restantes={state.remaining_actions()}"

        if self.detonate and _is_bomb_item(state, self.item):
            msg += ' | ' + _detonate_bomb_place_fire(state, self.item, to)

        # Hazards: al añadir FIRE pueden tumbar a humanos sin casco, etc.
        msgs = state.apply_hazard_effects() if hasattr(state, 'apply_hazard_effects') else []
        if msgs:
            msg += ' | ' + ' | '.join(msgs)

        return msg


@dataclass
class MoveDrag(Action):
    """Move + Drag (Reference Manual 12.1.2).

    Durante un Step, puedes arrastrar (Drag) a 1 Character DOWN colocated contigo.
    Restricción por turno de jugador: cada Character puede Drag max 1 vez, y puede ser Dragged max 1 vez.
    """
    to_section: SectionId
    drag_character: CharacterId

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        ch = state.characters[actor]

        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        if not self.drag_character or self.drag_character not in state.characters:
            raise ActionError("El personaje a draggear no existe.")
        if self.drag_character == actor:
            raise ActionError("No puedes draggearte a ti mismo.")

        tgt = state.characters[self.drag_character]
        if getattr(tgt, "annihilated", False):
            raise ActionError("No puedes draggear a un Character ANNIHILATED.")
        if getattr(tgt, "escaped", False):
            raise ActionError("No puedes draggear a un Character ESCAPED.")
        if getattr(tgt, "status", "LIVE") != "DOWN":
            raise ActionError("Solo puedes draggear a un Character DOWN.")
        if not state.colocated(actor, self.drag_character):
            raise ActionError("Para Drag, el objetivo debe estar COLOCATED contigo (misma sección).")

        # 12.1.2: cada Character puede Drag 1 vez / ser Dragged 1 vez por turno de jugador
        if getattr(ch, "has_dragged_this_turn", False):
            raise ActionError("Este Character ya ha draggeado a alguien este turno.")
        if getattr(tgt, "dragged_this_turn", False):
            raise ActionError("Ese Character ya ha sido draggeado este turno.")

        frm = ch.section
        # Adyacencia: corridor normal o vent (solo Tunnel Rat)
        if self.to_section in state.graph.get(frm, []):
            edge_kind = "corridor"
        elif hasattr(state, "is_vent") and state.is_vent(frm, self.to_section):
            if not state.effective_has_ability(actor, AB.TUNNEL_RAT):
                raise ActionError("Esa conexión es una VENT: solo TUNNEL RAT puede usarla.")
            edge_kind = "vent"
        else:
            raise ActionError(f"No puedes ir de {frm} a {self.to_section} en 1 Step.")

        # Locks: bloquean corridors (RM 12.1.3).
        # Locks prevent Steps through Corridors.
        # - En BLACKOUT (RM 7.2.2.3), OFFICER NO permite atravesar LOCKS; JUGGERNAUT SÍ.
        # - En MOVE+DRAG: OFFICER permite atravesar el LOCK incluso si el OFFICER es el DRAGGED
        #   (salvo en BLACKOUT). JUGGERNAUT SOLO cuenta si es el que hace el Step; si es el DRAGGED,
        #   no “abre puertas” nunca (ni en Blackout ni fuera).
        if edge_kind == "corridor" and hasattr(state, "is_locked_corridor") and state.is_locked_corridor(frm, self.to_section):
            blackout = getattr(state, "is_blackout", lambda: False)()
            officer_actor = bool(ch.has_ability(AB.OFFICER))
            jugger_actor = bool(ch.has_ability(AB.JUGGERNAUT))
            officer_tgt = bool(tgt.has_ability(AB.OFFICER))
            if blackout:
                if not jugger_actor:
                    raise ActionError("Ese corredor está LOCKED. En BLACKOUT, solo JUGGERNAUT puede pasar por LOCKS (usa BREACH).")
            else:
                if not (jugger_actor or officer_actor or officer_tgt):
                    raise ActionError("Ese corredor está LOCKED. Solo OFFICER/JUGGERNAUT puede pasar.")

        # Pods: límite de ocupantes (RM 5.5.3)
        to = self.to_section
        if getattr(state, "is_pod", None) and state.is_pod(to):
            pod = state.pods.get(str(to).upper())
            if not pod:
                raise ActionError("Pod desconocido.")
            if pod.location != 'ON_BOARD':
                raise ActionError(f"Ese Pod no está ON_BOARD (estado={pod.location}).")
            lim = getattr(pod, 'occupancy_limit', None)
            if lim is not None:
                if not state.pod_can_accept(str(to).upper(), [actor, self.drag_character]):
                    cur = state.pod_occupant_count(str(to).upper())
                    raise ActionError(f"Pod lleno: ocupantes={cur}, límite={lim}.")

    def apply(self, state: GameState) -> str:
        self.validate(state)

        actor = state.require_active()
        ch = state.characters[actor]
        tgt = state.characters[self.drag_character]

        frm = ch.section

        # Determinar kind para locks
        edge_kind = "corridor" if self.to_section in state.graph.get(frm, []) else "vent"

        ch.section = self.to_section
        tgt.section = self.to_section

        ch.has_dragged_this_turn = True
        tgt.dragged_this_turn = True

        state.spend_action_point(1)

        lock_msg = ""
        if edge_kind == "corridor" and hasattr(state, "is_locked_corridor") and state.is_locked_corridor(frm, self.to_section):
            if hasattr(state, "remove_lock_corridor"):
                blackout = getattr(state, "is_blackout", lambda: False)()
                officer_actor = bool(ch.has_ability(AB.OFFICER))
                officer_tgt = bool(tgt.has_ability(AB.OFFICER))
                jugger_actor = bool(ch.has_ability(AB.JUGGERNAUT))
                # En MOVE+DRAG, OFFICER cuenta aunque sea el DRAGGED (salvo en BLACKOUT).
                # JUGGERNAUT SOLO cuenta si es el actor (el que hace el Step).
                if jugger_actor or ((not blackout) and (officer_actor or officer_tgt)):
                    state.remove_lock_corridor(frm, self.to_section)
                    lock_msg = " | LOCK retirado"

        entry_msgs: List[str] = []
        if hasattr(state, 'apply_contamination_on_enter'):
            try:
                entry_msgs.extend(list(state.apply_contamination_on_enter(actor)))
                entry_msgs.extend(list(state.apply_contamination_on_enter(self.drag_character)))
            except Exception:
                pass

        # Hazards: al entrar, pueden tumbar humanos unhelmeted
        hz_msgs = state.apply_hazard_effects() if hasattr(state, "apply_hazard_effects") else []
        msgs = list(entry_msgs) + list(hz_msgs)
        extra = (" | " + " | ".join(msgs)) if msgs else ""

        return (
            f"Acción: MOVE+DRAG {actor} arrastra {self.drag_character} ({frm} -> {self.to_section})"
            f" | restantes={state.remaining_actions()}{lock_msg}{extra}"
        )




# ---------------------------
# Breach (RM 7.2.2.2)
# ---------------------------

@dataclass
class Breach(Action):
    """BREACH (Action): remove an adjacent LOCK during Blackout (RM 7.2.2.2).

    En este prototipo:
    - Solo Humans/Robots pueden usarla (según RM).
    - Requiere BLACKOUT (o que el Character tenga ya la Ability "BREACH").
    - Target: una sección adyacente por corredor normal, y que tenga un LOCK token.
    """
    to_section: SectionId

    def validate(self, state: GameState) -> None:
        cid = state.require_active()
        ch = state.characters[cid]
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")
        if not self.to_section:
            raise ActionError("Uso: breach <SEC>")

        # Human/Robot only (RM 7.2.2.2)
        ct = _norm_data(getattr(ch, "ctype", ""))
        if ('HUMAN' not in ct) and ('ROBOT' not in ct):
            raise ActionError("BREACH en Blackout solo lo tienen Humans/Robots.")

        # Available during Blackout, or if character inherently has BREACH.
        if (not getattr(state, "is_blackout", lambda: False)()) and (not ch.has_ability(AB.BREACH)):
            raise ActionError("No puedes usar BREACH fuera de Blackout (salvo que este Character tenga BREACH).")

        frm = str(ch.section).upper()
        to = str(self.to_section).upper()

        # Must be a normal corridor adjacency and currently locked.
        if to not in state.graph.get(frm, []):
            raise ActionError("BREACH requiere un LOCK adyacente por corredor normal (no VENT/AIRLOCK).")
        if not getattr(state, "is_locked_corridor", None) or (not state.is_locked_corridor(frm, to)):
            raise ActionError("No hay un LOCK en ese corredor adyacente.")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        cid = state.require_active()
        ch = state.characters[cid]
        frm = str(ch.section).upper()
        to = str(self.to_section).upper()
        if getattr(state, "remove_lock_corridor", None):
            state.remove_lock_corridor(frm, to)
        else:
            # fallback directo
            a, b = (frm, to) if frm <= to else (to, frm)
            state.locks.discard((a, b))
        state.spend_action_point(1)
        return f"Acción: BREACH {cid} retira LOCK ({frm} <-> {to}) | restantes={state.remaining_actions()}"


# ---------------------------
# Wormtongue (Character Dossier: Counselor)
# ---------------------------

def _resolve_pid(state: GameState, pid_like: str) -> PlayerId:
    """Resuelve un PlayerId por comparación normalizada (case-insensitive)."""
    want = _norm_data(pid_like)
    for p in getattr(state, 'players', []) or []:
        pid = getattr(p, 'pid', None)
        if pid is None:
            continue
        if _norm_data(pid) == want:
            return pid
    # fallback: devuelve el texto tal cual para que el error sea claro en validate
    return str(pid_like)


@dataclass
class Wormtongue(Action):
    """WORMTONGUE (Action): mueve 1 cube de la carta de un Humano COLOCATED a Betrayal.

    Implementación del prototipo:
    - Requiere que el Character activo tenga la habilidad WORMTONGUE.
    - Target: un Humano COLOCATED.
    - Si hay cubos de varios jugadores en esa carta, puedes especificar el dueño del cube.
    - Soporta dos fuentes de "cubes en la carta":
        * Influence (state.influence)
        * bribe_tokens (legacy del prototipo)
    """

    target_character: CharacterId
    cube_owner: Optional[PlayerId] = None

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        ch = state.characters[actor]

        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        if not getattr(ch, 'has_ability', lambda *_: False)(AB.WORMTONGUE):
            raise ActionError("Este Character no tiene WORMTONGUE.")

        if not self.target_character:
            raise ActionError("Uso: wormtongue <HUMANCID> [PID]")

        tgt = str(self.target_character).upper()
        if tgt not in state.characters:
            raise ActionError("Ese personaje no existe.")

        t_ch = state.characters[tgt]
        if _is_escaped_or_annihilated(t_ch):
            raise ActionError("No puedes usar WORMTONGUE sobre un Character ESCAPED/ANNIHILATED.")

        # Must be a Human.
        if 'HUMAN' not in _norm_data(getattr(t_ch, 'ctype', '')):
            raise ActionError("WORMTONGUE requiere un objetivo Human.")

        # Must be COLOCATED.
        if str(getattr(t_ch, 'section', '')).upper() != str(getattr(ch, 'section', '')).upper():
            raise ActionError("WORMTONGUE requiere un objetivo COLOCATED.")

        # Determine available cube owners on that card.
        owners: List[PlayerId] = []
        # Influence cubes
        for p in getattr(state, 'players', []) or []:
            pid = getattr(p, 'pid', None)
            if not pid:
                continue
            n = 0
            try:
                n = int(state.influence_of(pid, tgt)) if hasattr(state, 'influence_of') else 0
            except Exception:
                n = 0
            if n > 0:
                owners.append(pid)

        # Bribe cubes (legacy): cuentan como cubes en la carta
        for pid in getattr(t_ch, 'bribe_tokens', []) or []:
            if pid not in owners:
                owners.append(pid)

        if not owners:
            raise ActionError("No hay cubes en esa carta para mover a Betrayal.")

        if self.cube_owner is not None:
            resolved = _resolve_pid(state, str(self.cube_owner))
            if resolved not in owners:
                opts = ", ".join(owners)
                raise ActionError(f"Ese jugador no tiene cubes en la carta. Opciones: {opts}")
        else:
            # If ambiguous, force explicit choice.
            if len(owners) > 1:
                opts = ", ".join(owners)
                raise ActionError(f"Hay cubes de varios jugadores en la carta. Elige: wormtongue {tgt} <PID>. Opciones: {opts}")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        actor = state.require_active()
        ch = state.characters[actor]

        tgt = str(self.target_character).upper()
        t_ch = state.characters[tgt]

        # Recomputar owners para resolver el pid si no venía.
        owners: List[PlayerId] = []
        for p in getattr(state, 'players', []) or []:
            pid = getattr(p, 'pid', None)
            if not pid:
                continue
            try:
                if int(state.influence_of(pid, tgt)) > 0:
                    owners.append(pid)
            except Exception:
                pass
        for pid in getattr(t_ch, 'bribe_tokens', []) or []:
            if pid not in owners:
                owners.append(pid)

        if self.cube_owner is not None:
            pid = _resolve_pid(state, str(self.cube_owner))
        else:
            pid = owners[0]

        # Remove one cube from the target card.
        removed_from = "INFLUENCE"
        removed = False
        try:
            cur = int(state.influence_of(pid, tgt)) if hasattr(state, 'influence_of') else 0
        except Exception:
            cur = 0

        if cur > 0 and hasattr(state, 'set_influence_of'):
            state.set_influence_of(pid, tgt, cur - 1)
            removed = True
        else:
            # Try legacy bribe_tokens list
            bt = list(getattr(t_ch, 'bribe_tokens', []) or [])
            # match normalized
            want = _norm_data(pid)
            for i, x in enumerate(bt):
                if _norm_data(x) == want:
                    bt.pop(i)
                    setattr(t_ch, 'bribe_tokens', bt)
                    removed = True
                    removed_from = "BRIBE"
                    break

        if not removed:
            # Esto no debería ocurrir tras validate, pero lo dejamos por seguridad.
            raise ActionError("No se pudo retirar el cube de la carta (estado inconsistente).")

        # Add to Betrayal
        pstate = state.player_by_id(pid)
        pstate.betrayal_cubes = int(getattr(pstate, 'betrayal_cubes', 0) or 0) + 1

        state.spend_action_point(1)
        return (
            f"Acción: WORMTONGUE | {actor}:{ch.name} mueve 1 cube de {pid} desde {tgt}:{t_ch.name} a Betrayal "
            f"({removed_from}) | restantes={state.remaining_actions()}"
        )
# ---------------------------
# Airlock (RM 13.12.3 / índice 13.13)
# ---------------------------

def _canon_outer(sec: str) -> str:
    """Normaliza nombres típicos de Outer Space a OUTER_SPACE_SECTION."""
    n = _norm_data(sec)
    if n in ("OUTERSPACE", "OUTER_SPACE", "OUTER"):
        return OUTER_SPACE_SECTION
    return str(sec).upper()


@dataclass
class AirlockMove(SectionAction):
    blackout_exempt: ClassVar[bool] = True
    """Section Action: AIRLOCK — Step hacia/desde Outer Space."""
    to_section: SectionId

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        ch = state.characters[actor]
        frm = _canon_outer(str(ch.section))
        to = _canon_outer(str(self.to_section))

        # ADRENALINE (Daredevil): AIRLOCK hacia una sección con Hazard es siempre FREE.
        adrenaline_free = False
        if ch.has_ability(AB.ADRENALINE) and hasattr(state, "section_has_hazard"):
            try:
                adrenaline_free = bool(state.section_has_hazard(to))
            except Exception:
                adrenaline_free = False

        # EMERGENCY_RESPONSE_BETA (Medical): AIRLOCK hacia una sección con algún Human DOWN es siempre FREE.
        er_free = False
        if ch.has_ability(AB.EMERGENCY_RESPONSE_BETA):
            try:
                if not (hasattr(state, 'is_outer_space') and state.is_outer_space(str(to).upper())):
                    er_free = _section_has_human_down(state, str(to).upper())
            except Exception:
                er_free = False

        # ZEROBORN (Astrochimp reveal): AIRLOCK MOVE hacia una sección SIN GRAVEDAD es FREE,
        # pero SOLO cuenta "hacia" (destino 0G). No vale por salir "desde" una sección 0G.
        # Consume el mismo slot gratis que el Free PickUp/Drop.
        zeroborn_free = False
        if ch.has_ability(AB.ZEROBORN) and not getattr(state, 'free_pickdrop_used', False):
            try:
                # Destino debe ser 0G (sin gravedad).
                if hasattr(state, 'section_has_gravity') and callable(getattr(state, 'section_has_gravity')):
                    zeroborn_free = (not state.section_has_gravity(to))
                else:
                    zg = {str(x).upper() for x in getattr(state, 'zero_g_sections', set())}
                    zeroborn_free = (str(to).upper() in zg) or (str(to).upper() in getattr(state, 'pods', {}))
            except Exception:
                zeroborn_free = False


        if state.remaining_actions() <= 0 and not (adrenaline_free or er_free or zeroborn_free):
            raise ActionError("No te quedan acciones.")

        if not getattr(state, "airlock_can_step", None):
            raise ActionError("Este estado no soporta Airlocks todavía.")

        if not state.airlock_can_step(frm, to):
            raise ActionError("AIRLOCK inválido: solo puedes ir entre un Airlock y Outer Space (según flechas).")

        # Airlock debe estar undamaged (RM 12.5.* / texto de movimiento).
        air_sec = to if getattr(state, "is_outer_space", None) and state.is_outer_space(frm) else frm
        if air_sec in getattr(state, "damaged_sections", set()):
            raise ActionError("El Airlock está dañado: no puedes usar AIRLOCK.")

        # 13.12.6: no desde Outer Space a sección dañada (refuerza lo anterior)
        if getattr(state, "is_outer_space", None) and state.is_outer_space(frm):
            if to in getattr(state, "damaged_sections", set()):
                raise ActionError("No puedes AIRLOCK desde Outer Space a una sección dañada.")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        actor = state.require_active()
        ch = state.characters[actor]
        frm = _canon_outer(str(ch.section))
        to = _canon_outer(str(self.to_section))

        adrenaline_free = False
        if ch.has_ability(AB.ADRENALINE) and hasattr(state, "section_has_hazard"):
            try:
                adrenaline_free = bool(state.section_has_hazard(to))
            except Exception:
                adrenaline_free = False

        er_free = False
        if ch.has_ability(AB.EMERGENCY_RESPONSE_BETA):
            try:
                if not (hasattr(state, 'is_outer_space') and state.is_outer_space(str(to).upper())):
                    er_free = _section_has_human_down(state, str(to).upper())
            except Exception:
                er_free = False

        # ZEROBORN (Astrochimp reveal): AIRLOCK MOVE hacia una sección SIN GRAVEDAD es FREE,
        # SOLO si el destino es 0G. Consume el slot gratis compartido con Free Pick/Drop.
        zeroborn_free = False
        if ch.has_ability(AB.ZEROBORN) and not getattr(state, 'free_pickdrop_used', False):
            try:
                if hasattr(state, 'section_has_gravity') and callable(getattr(state, 'section_has_gravity')):
                    zeroborn_free = (not state.section_has_gravity(to))
                else:
                    zg = {str(x).upper() for x in getattr(state, 'zero_g_sections', set())}
                    zeroborn_free = (str(to).upper() in zg) or (str(to).upper() in getattr(state, 'pods', {}))
            except Exception:
                zeroborn_free = False


        ch.section = to

        cost_msg = ""
        if adrenaline_free or er_free:
            reason = "ADRENALINE" if adrenaline_free else "EMERGENCY_RESPONSE"
            cost_msg = f" | coste=free({reason})"
        elif zeroborn_free:
            # Consume el slot gratis compartido con Free Pick/Drop
            state.free_pickdrop_used = True
            cost_msg = " | coste=free(ZEROBORN: usa free pick/drop)"
        else:
            state.spend_action_point(1)

        msgs = state.apply_hazard_effects() if hasattr(state, "apply_hazard_effects") else []
        extra = (" | " + " | ".join(msgs)) if msgs else ""
        return f"Acción: AIRLOCK MOVE {actor} ({frm} -> {to}) | restantes={state.remaining_actions()}{cost_msg}{extra}"


@dataclass
class AirlockMoveDrag(SectionAction):
    blackout_exempt: ClassVar[bool] = True
    """Section Action: AIRLOCK — Step + Drag hacia/desde Outer Space (RM 13.12.4)."""
    to_section: SectionId
    drag_character: CharacterId

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        if not self.drag_character or self.drag_character not in state.characters:
            raise ActionError("El personaje a draggear no existe.")
        if self.drag_character == actor:
            raise ActionError("No puedes draggearte a ti mismo.")

        ch = state.characters[actor]
        tgt = state.characters[self.drag_character]
        if getattr(tgt, "annihilated", False) or getattr(tgt, "escaped", False):
            raise ActionError("No puedes draggear a un Character ESCAPED/ANNIHILATED.")
        if str(getattr(tgt, "status", "LIVE")).upper() != "DOWN":
            raise ActionError("Solo puedes draggear a un Character DOWN.")
        if not state.colocated(actor, self.drag_character):
            raise ActionError("Para Drag, el objetivo debe estar COLOCATED contigo (misma sección).")

        if getattr(ch, "has_dragged_this_turn", False):
            raise ActionError("Este Character ya ha draggeado a alguien este turno.")
        if getattr(tgt, "dragged_this_turn", False):
            raise ActionError("Ese Character ya ha sido draggeado este turno.")

        frm = _canon_outer(str(ch.section))
        to = _canon_outer(str(self.to_section))
        if not state.airlock_can_step(frm, to):
            raise ActionError("AIRLOCK inválido: solo puedes ir entre un Airlock y Outer Space (según flechas).")

        air_sec = to if getattr(state, "is_outer_space", None) and state.is_outer_space(frm) else frm
        if air_sec in getattr(state, "damaged_sections", set()):
            raise ActionError("El Airlock está dañado: no puedes usar AIRLOCK.")

        if getattr(state, "is_outer_space", None) and state.is_outer_space(frm):
            if to in getattr(state, "damaged_sections", set()):
                raise ActionError("No puedes AIRLOCK desde Outer Space a una sección dañada.")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        actor = state.require_active()
        ch = state.characters[actor]
        tgt = state.characters[self.drag_character]

        frm = _canon_outer(str(ch.section))
        to = _canon_outer(str(self.to_section))

        ch.section = to
        tgt.section = to

        ch.has_dragged_this_turn = True
        tgt.dragged_this_turn = True

        state.spend_action_point(1)

        msgs = state.apply_hazard_effects() if hasattr(state, "apply_hazard_effects") else []
        extra = (" | " + " | ".join(msgs)) if msgs else ""
        return (
            f"Acción: AIRLOCK MOVE+DRAG {actor} arrastra {self.drag_character} ({frm} -> {to})"
            f" | restantes={state.remaining_actions()}{extra}"
        )


@dataclass
class AirlockThrow(SectionAction):
    blackout_exempt: ClassVar[bool] = True
    """Section Action: AIRLOCK — Throw en la dirección permitida hacia/desde Outer Space."""
    item: ItemId
    to_section: SectionId

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        ch = state.characters[actor]
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")
        if not self.item or not self.to_section:
            raise ActionError("Uso: airlock throw <IID> <SEC>")
        if self.item not in ch.items:
            raise ActionError("No tienes ese item.")

        # RM 8.4: Integral Items no pueden tirarse (tampoco por AIRLOCK).
        if _integral_bound_to(state, self.item):
            raise ActionError("Ese item es INTEGRAL y no puede AIRLOCK THROWarse.")

        frm = _canon_outer(str(ch.section))
        to = _canon_outer(str(self.to_section))
        if not state.airlock_can_step(frm, to):
            raise ActionError("AIRLOCK THROW inválido: solo puede ser entre Airlock y Outer Space.")

        air_sec = to if getattr(state, "is_outer_space", None) and state.is_outer_space(frm) else frm
        if air_sec in getattr(state, "damaged_sections", set()):
            raise ActionError("El Airlock está dañado: no puedes usar AIRLOCK.")
        if getattr(state, "is_outer_space", None) and state.is_outer_space(frm):
            if to in getattr(state, "damaged_sections", set()):
                raise ActionError("No puedes AIRLOCK THROW desde Outer Space a una sección dañada.")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        actor = state.require_active()
        ch = state.characters[actor]

        frm = _canon_outer(str(ch.section))
        to = _canon_outer(str(self.to_section))

        ch.items.remove(self.item)
        state.section_items.setdefault(to, []).append(self.item)

        state.spend_action_point(1)
        it = state.items.get(self.item)
        name = it.name if it else self.item
        return f"Acción: AIRLOCK THROW {self.item} ({name}) {actor} ({frm} -> {to}) | restantes={state.remaining_actions()}"


@dataclass
class AirlockEjectDown(SectionAction):
    blackout_exempt: ClassVar[bool] = True
    """Section Action: AIRLOCK — Eject a colocated Down Character into Outer Space (RM 13.12.5)."""
    target_character: CharacterId

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        ch = state.characters[actor]
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        frm = _canon_outer(str(ch.section))
        if getattr(state, "is_outer_space", None) and state.is_outer_space(frm):
            raise ActionError("No puedes EJECT desde Outer Space.")

        if not getattr(state, "is_airlock_section", None) or not state.is_airlock_section(frm):
            raise ActionError("Esta sección no es un Airlock.")
        if not state.airlock_allows(frm, "to_outer"):
            raise ActionError("Este Airlock no permite ejectar hacia Outer Space (flecha).")
        if frm in getattr(state, "damaged_sections", set()):
            raise ActionError("El Airlock está dañado: no puedes usar AIRLOCK.")

        if not self.target_character or self.target_character not in state.characters:
            raise ActionError("Target no existe.")
        if self.target_character == actor:
            raise ActionError("No puedes ejectarte a ti mismo.")

        tgt = state.characters[self.target_character]
        if getattr(tgt, "annihilated", False) or getattr(tgt, "escaped", False):
            raise ActionError("No puedes ejectar un Character ESCAPED/ANNIHILATED.")
        if str(getattr(tgt, "status", "LIVE")).upper() != "DOWN":
            raise ActionError("Solo puedes EJECT a un Character DOWN.")
        if not state.colocated(actor, self.target_character):
            raise ActionError("Para EJECT, el objetivo debe estar COLOCATED contigo (misma sección).")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        actor = state.require_active()
        ch = state.characters[actor]
        frm = _canon_outer(str(ch.section))

        tgt = state.characters[self.target_character]
        tgt.section = OUTER_SPACE_SECTION
        state.spend_action_point(1)

        msgs = state.apply_hazard_effects() if hasattr(state, "apply_hazard_effects") else []
        extra = (" | " + " | ".join(msgs)) if msgs else ""
        return f"Acción: AIRLOCK EJECT {actor} -> {self.target_character} ({frm} -> {OUTER_SPACE_SECTION}) | restantes={state.remaining_actions()}{extra}"




# ---------------------------
# Cargo Claw — Grip (Troubleshooter module)
# ---------------------------

def _room_has_grip_pickup(state: GameState, sec: str) -> bool:
    ra = getattr(state, 'room_actions', {}).get(sec, [])
    for a in ra:
        au = str(a).upper()
        if ('GRIP' in au) and (('PICK' in au) or ('PICKUP' in au) or ('PICK UP' in au)):
            return True
    return False

def _room_has_grip_down(state: GameState, sec: str) -> bool:
    ra = getattr(state, 'room_actions', {}).get(sec, [])
    for a in ra:
        au = str(a).upper()
        if ('GRIP' in au) and ('DOWN' in au):
            return True
    return False


@dataclass
class GripPickUp(SectionAction):
    """Section Action: GRIP PICK UP (Cargo Claw).

    Toma un Item que esté en OUTER SPACE y lo añade al inventario del actor.
    """

    item: ItemId

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError('No te quedan acciones.')

        ch = state.characters[actor]
        sec = str(getattr(ch, 'section', '')).upper()

        # Regla general: no se puede usar Section Action si la sección está dañada.
        if sec in getattr(state, 'damaged_sections', set()):
            raise ActionError('La sección está dañada: no puedes usar su acción de habitación.')

        if sec != 'CARGO_CLAW':
            raise ActionError('GRIP solo puede hacerse en CARGO_CLAW.')

        if not _room_has_grip_pickup(state, sec):
            raise ActionError('En esta sección no existe la acción GRIP PICK UP (según lo impreso/demo).')

        iid = str(self.item).upper()
        if iid not in getattr(state, 'items', {}):
            raise ActionError('Ese item no existe.')

        # Debe estar en OUTER SPACE (en el suelo).
        out_items = getattr(state, 'section_items', {}).get(OUTER_SPACE_SECTION, [])
        if iid not in [str(x).upper() for x in (out_items or [])]:
            raise ActionError('Ese item no está en OUTER SPACE.')

        # RM 8.4: Integral Items no pueden ser tomados de otro Character.
        bound = _integral_bound_to(state, iid)
        if bound and str(bound).upper() != str(actor).upper():
            raise ActionError('Ese item es INTEGRAL y no puede ser retirado de su Character.')

        if not state.can_receive_item(actor, add=1):
            raise ActionError('Límite de inventario alcanzado.')

    def apply(self, state: GameState) -> str:
        self.validate(state)
        actor = state.require_active()
        iid = str(self.item).upper()

        # Quitar de OUTER SPACE
        out_items = getattr(state, 'section_items', {}).setdefault(OUTER_SPACE_SECTION, [])
        out_items[:] = [x for x in out_items if str(x).upper() != iid]

        # Añadir al inventario
        ch = state.characters[actor]
        ch.items.append(iid)

        state.spend_action_point(1)
        it = getattr(state, 'items', {}).get(iid)
        name = getattr(it, 'name', iid) if it else iid
        return f'Section Action: GRIP PICK UP {iid} ({name}) from OUTER SPACE.'


@dataclass
class GripDown(SectionAction):
    """Section Action: GRIP DOWN (Cargo Claw).

    Pone DOWN a un Character que esté en OUTER SPACE.
    """

    target_character: CharacterId

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError('No te quedan acciones.')

        ch = state.characters[actor]
        sec = str(getattr(ch, 'section', '')).upper()

        if sec in getattr(state, 'damaged_sections', set()):
            raise ActionError('La sección está dañada: no puedes usar su acción de habitación.')

        if sec != 'CARGO_CLAW':
            raise ActionError('GRIP solo puede hacerse en CARGO_CLAW.')

        if not _room_has_grip_down(state, sec):
            raise ActionError('En esta sección no existe la acción GRIP DOWN (según lo impreso/demo).')

        tgt_id = str(self.target_character).upper()
        if not tgt_id or tgt_id not in getattr(state, 'characters', {}):
            raise ActionError('Target no existe.')
        if tgt_id == str(actor).upper():
            raise ActionError('No puedes hacer GRIP DOWN a ti mismo.')

        tgt = state.characters[tgt_id]
        if getattr(tgt, 'annihilated', False) or getattr(tgt, 'escaped', False):
            raise ActionError('No puedes hacer GRIP a un Character ESCAPED/ANNIHILATED.')

        if str(getattr(tgt, 'section', '')).upper() != OUTER_SPACE_SECTION:
            raise ActionError('El objetivo no está en OUTER SPACE.')

        if str(getattr(tgt, 'status', 'LIVE')).upper() == 'DOWN':
            raise ActionError('El objetivo ya está DOWN.')

    def apply(self, state: GameState) -> str:
        self.validate(state)
        tgt_id = str(self.target_character).upper()
        tgt = state.characters[tgt_id]
        tgt.status = 'DOWN'
        state.spend_action_point(1)

        msgs = state.apply_hazard_effects() if hasattr(state, 'apply_hazard_effects') else []
        extra = (' | ' + ' | '.join(msgs)) if msgs else ''
        return f'Section Action: GRIP DOWN {tgt_id} in OUTER SPACE.{extra}'
@dataclass
class PickUp(Action):
    item: ItemId
    force_cost_action: bool = False  # para Bribe/Kompromat

    def validate(self, state: GameState) -> None:
        cid = state.require_active()
        ch = state.characters[cid]
        # RM 4.6.4: los Items poseídos por un Character DOWN se pueden PICK UP
        # desde su sección (sin ROB), como si estuvieran en el suelo.
        sec_items = state.section_items.get(ch.section, [])
        if self.item not in sec_items:
            found_on_down = False
            for ocid, och in state.characters.items():
                if ocid == cid:
                    continue
                if och.section != ch.section:
                    continue
                if getattr(och, 'escaped', False) or getattr(och, 'annihilated', False):
                    continue
                if not och.is_down():
                    continue
                if self.item in getattr(och, 'items', []):
                    found_on_down = True
                    break
            if not found_on_down:
                raise ActionError("Ese item no está en la sección.")
        it = state.items[self.item]

        # RM 8.4: Integral Items no pueden ser tomados de otro Character.
        bound = _integral_bound_to(state, self.item)
        if bound and str(bound).upper() != str(cid).upper():
            raise ActionError("Ese item es INTEGRAL y no puede ser retirado de su Character.")
        if it.kind != "kompromat":
            if not state.can_receive_item(cid, add=1):
                raise ActionError("Límite de inventario alcanzado.")
        # RM 15.5.3: el Free Pick Up/Drop solo aplica a Conspirators Human/Robot durante su Activation.
        ctu = str(getattr(ch, 'ctype', '')).upper()
        is_hr = ('HUMAN' in ctu) or ('ROBOT' in ctu)
        can_use_free = (not self.force_cost_action) and is_hr and (not state.free_pickdrop_used)

        # Si no puedes usar el "free", entonces este PickUp debe costar 1 Action Point.
        if self.force_cost_action or (not can_use_free):
            if state.remaining_actions() <= 0:
                raise ActionError("No te quedan acciones.")

    def apply(self, state: GameState) -> str:
        cid = state.require_active()
        ch = state.characters[cid]
        sec = ch.section
        it = state.items[self.item]

        src_txt = ""
        if self.item in state.section_items.get(sec, []):
            state.section_items[sec].remove(self.item)
        else:
            # Item tomado de un Character DOWN en la misma sección.
            src = None
            for ocid, och in state.characters.items():
                if ocid == cid:
                    continue
                if och.section != sec:
                    continue
                if getattr(och, 'escaped', False) or getattr(och, 'annihilated', False):
                    continue
                if not och.is_down():
                    continue
                if self.item in getattr(och, 'items', []):
                    och.items.remove(self.item)
                    src = ocid
                    break
            if src is None:
                # No debería ocurrir si validate pasó; protegemos por seguridad.
                raise ActionError("Ese item no está disponible para PICK UP.")
            src_txt = f" | from={src}(DOWN)"

        # RM 15.5.3: Free Pick Up/Drop solo para Human/Robot durante la Activation.
        ctu = str(getattr(ch, 'ctype', '')).upper()
        is_hr = ('HUMAN' in ctu) or ('ROBOT' in ctu)
        can_use_free = (not self.force_cost_action) and is_hr and (not state.free_pickdrop_used)

        if it.kind == "kompromat":
            cp = state.current_player()
            cp.kompromat_hand.append(self.item)
            if self.force_cost_action or (not can_use_free):
                state.spend_action_point(1)
                cost = 'action'
            else:
                state.free_pickdrop_used = True
                cost = 'free'
            return f"Acción: PICK UP Kompromat -> mano de {cp.pid} (+1) | coste={cost}"

        ch.items.append(self.item)

        if self.force_cost_action or (not can_use_free):
            state.spend_action_point(1)
            msg = f"Acción: PICK UP {self.item} ({it.name}) -> {cid} | coste=action{src_txt}"
        else:
            state.free_pickdrop_used = True
            msg = f"Acción: PICK UP {self.item} ({it.name}) -> {cid} | coste=free{src_txt}"

        return msg


@dataclass
class Drop(Action):
    item: ItemId
    force_cost_action: bool = False
    detonate: bool = False  # solo si el item es una Bomb

    def validate(self, state: GameState) -> None:
        cid = state.require_active()
        ch = state.characters[cid]
        if self.item not in ch.items:
            raise ActionError("No tienes ese item.")

        # RM 8.4: Integral Items no pueden soltarse.
        if _integral_bound_to(state, self.item):
            raise ActionError("Ese item es INTEGRAL y no puede DROParse.")
        # RM 15.5.3: el Free Pick Up/Drop solo aplica a Conspirators Human/Robot durante su Activation.
        ctu = str(getattr(ch, 'ctype', '')).upper()
        is_hr = ('HUMAN' in ctu) or ('ROBOT' in ctu)
        can_use_free = (not self.force_cost_action) and is_hr and (not state.free_pickdrop_used)

        if self.force_cost_action or (not can_use_free):
            if state.remaining_actions() <= 0:
                raise ActionError("No te quedan acciones.")

        # Bomb (homebrew): si detona al caer, genera FIRE (y daña la sección).
        if self.detonate:
            if not _is_bomb_item(state, self.item):
                raise ActionError('Solo puedes detonar una Bomb al DROP.')
            sec = str(ch.section).upper()
            if state.has_hazard_kind(sec, 'ASPHYX'):
                raise ActionError('No puedes detonar una Bomb en una sección con ASPHYX (FIRE no puede empezar allí).')


    def apply(self, state: GameState) -> str:
        cid = state.require_active()
        ch = state.characters[cid]
        sec = ch.section
        it = state.items[self.item]

        ch.items.remove(self.item)
        state.section_items.setdefault(sec, []).append(self.item)

        # RM 15.5.3: Free Pick Up/Drop solo para Human/Robot durante la Activation.
        ctu = str(getattr(ch, 'ctype', '')).upper()
        is_hr = ('HUMAN' in ctu) or ('ROBOT' in ctu)
        can_use_free = (not self.force_cost_action) and is_hr and (not state.free_pickdrop_used)

        if self.force_cost_action or (not can_use_free):
            state.spend_action_point(1)
            msg = f"Acción: DROP {self.item} ({it.name}) en {sec} | coste=action"
        else:
            state.free_pickdrop_used = True
            msg = f"Acción: DROP {self.item} ({it.name}) en {sec} | coste=free"

        # Bomb (homebrew): puede detonar al caer y crear FIRE (daña la sección).
        if self.detonate and _is_bomb_item(state, self.item):
            msg += ' | ' + _detonate_bomb_place_fire(state, self.item, sec)

        # Hazards: si te quitas el Helmet en una Hazard, o si acabas de crear FIRE, el Hazard puede tumbarte (6.1).
        msgs = state.apply_hazard_effects()
        if msgs:
            msg += " | " + " | ".join(msgs)
        return msg


@dataclass
class Give(Action):
    """Basic Action: GIVE (RM 12.4).

    12.4.1 Move an Item from the Activated Character's card to another COLOCATED
          Character's card.
    12.4.2 Cannot be Given if it would exceed the receiver's Item Limit.
    12.4.3 Cannot be refused.
    """

    item: ItemId
    to_character: CharacterId

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        ch = state.characters[actor]

        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        iid = str(self.item).upper()
        if iid not in getattr(ch, 'items', []):
            raise ActionError("No tienes ese item.")

        # RM 8.4: Integral Items no pueden darse.
        if _integral_bound_to(state, iid):
            raise ActionError("Ese item es INTEGRAL y no puede GIVEarse.")

        if not self.to_character:
            raise ActionError("Falta el destinatario.")
        tgt_id = str(self.to_character).upper()
        if tgt_id not in state.characters:
            raise ActionError("El destinatario no existe.")
        if tgt_id == actor:
            raise ActionError("No puedes darte un item a ti mismo.")

        tgt = state.characters[tgt_id]
        if _is_escaped_or_annihilated(tgt):
            raise ActionError("No puedes GIVE a un Character ESCAPED/ANNIHILATED.")

        if not state.colocated(actor, tgt_id):
            raise ActionError("Para GIVE, el destinatario debe estar COLOCATED contigo (misma sección).")

        it = state.items.get(iid)
        if it is None:
            raise ActionError("Ese item no existe.")
        if getattr(it, 'kind', '') == 'kompromat':
            # En nuestro sistema los Kompromats viven en la mano del jugador, no en items poseídos.
            raise ActionError("No puedes GIVE un Kompromat.")

        if not state.can_receive_item(tgt_id, add=1):
            raise ActionError("El destinatario excedería su Item Limit.")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        actor = state.require_active()
        ch = state.characters[actor]
        tgt_id = str(self.to_character).upper()
        tgt = state.characters[tgt_id]
        iid = str(self.item).upper()
        it = state.items.get(iid)
        name = getattr(it, 'name', iid) if it else iid

        ch.items.remove(iid)
        tgt.items.append(iid)

        state.spend_action_point(1)

        msgs = state.apply_hazard_effects() if hasattr(state, 'apply_hazard_effects') else []
        extra = (" | " + " | ".join(msgs)) if msgs else ""

        return f"Acción: GIVE {iid} ({name}) {actor} -> {tgt_id} | restantes={state.remaining_actions()}{extra}"


@dataclass
class Wait(Action):
    def validate(self, state: GameState) -> None:
        # WAIT es una Basic Action: requiere un Character activo.
        # (En este prototipo, el comando 'move' ya equivale al Step del manual.)
        try:
            state.require_active()
        except Exception as e:
            raise ActionError(str(e))

        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

    def apply(self, state: GameState) -> str:
        cp = state.current_player()

        # RM: WAIT permite recuperar tu Activation Disc a tu suministro.
        # En nuestro modelo el disco está representado por `PlayerState.activation_disc`.
        # Importante (pedido): no recalculamos flags de exhausted en este instante.
        prev = getattr(cp, 'activation_disc', None)
        cp.activation_disc = None

        state.spend_action_point(1)
        rem = state.remaining_actions()
        tail = f" (disco devuelto desde {prev})" if prev else " (sin disco)"
        return f"Acción: WAIT{tail} | restantes={rem}"


@dataclass
class Attack(Action):
    """Basic Action: Attack (RM 12.8).

    En reglas: requiere un Gun o Bludgeon y el arma determina elegibilidad.
    En este prototipo, históricamente Attack contra Characters era simplificado.
    En v31 añadimos soporte para atacar Monsters (Project X) sin romper lo
    anterior, aplicando el requisito de arma al menos para Monsters.
    """

    target_id: str
    weapon: Optional[str] = None

    def _attacker_has_gun(self, state: GameState, attacker: CharacterId) -> bool:
        atk_ch = state.characters[attacker]
        for iid in getattr(atk_ch, "items", []):
            it = state.items.get(iid)
            if it and _norm_data(getattr(it, "name", "")) == "GUN":
                return True
        return False

    def _attacker_has_bludgeon(self, state: GameState, attacker: CharacterId) -> bool:
        atk_ch = state.characters[attacker]
        for iid in getattr(atk_ch, "items", []):
            it = state.items.get(iid)
            if it and _norm_data(getattr(it, "name", "")) == "BLUDGEON":
                return True
        return False

    def _choose_weapon_for_target(self, state: GameState, attacker: CharacterId, target_kind: str, target_id: str, forced_weapon: Optional[str] = None) -> str:
        """Devuelve "GUN" o "BLUDGEON" si es legal atacar ese target.

        - RM 12.8.1: Bludgeon -> Robot, Unhelmeted Human o Monster.
        - RM 12.8.2: Gun -> Character o Monster.
        """
        has_gun = self._attacker_has_gun(state, attacker)
        has_bludgeon = self._attacker_has_bludgeon(state, attacker)

        if not (has_gun or has_bludgeon):
            raise ActionError("Attack requiere poseer un Gun o un Bludgeon (RM 12.8).")

        gun_ok = False
        bludgeon_ok = False

        # FAST_TALK: algunos objetivos no pueden ser atacados por HUMANS con BLUDGEON en secciones iluminadas.
        fast_talk_blocked = False

        # ARMORED: algunos objetivos no pueden ser atacados por BLUDGEON.
        armored_blocked = False

        if target_kind == "MONSTER":
            gun_ok = has_gun
            bludgeon_ok = has_bludgeon
        elif target_kind == "CHAR":
            # Gun: cualquier Character
            gun_ok = has_gun
            # Bludgeon: Robot o Human unhelmeted
            # Nota (CYBORG): si un Character es a la vez Human+Robot, en ATTACK cuenta como Human.
            tgt = state.characters[target_id]
            ct = _norm_data(getattr(tgt, "ctype", ""))
            is_human = ("HUMAN" in ct)
            is_robot = ("ROBOT" in ct) and (not is_human)

            if is_robot:
                bludgeon_ok = has_bludgeon
            elif is_human:
                # Helmet protege frente a ataques con Bludgeon (RM 8.1.1 / 12.8.1)
                if not state.is_helmeted(target_id):
                    bludgeon_ok = has_bludgeon
                else:
                    # BRUTAL (Reveal Power, Cyborg): con Bludgeon puede atacar a un Human Helmeted.
                    if has_bludgeon and state.characters[attacker].has_ability(AB.BRUTAL):
                        bludgeon_ok = True
            else:
                bludgeon_ok = False

            # FAST_TALK (Dossier): no puede ser atacado por HUMANS con BLUDGEON en secciones Lit.
            if bludgeon_ok:
                try:
                    atk_ct = _norm_data(getattr(state.characters[attacker], "ctype", ""))
                    atk_is_human = ("HUMAN" in atk_ct)
                except Exception:
                    atk_is_human = False
                try:
                    sec = getattr(state.characters[attacker], "section", None) or getattr(state.characters[target_id], "section", None)
                    is_lit = bool(getattr(state, 'is_lit', lambda _s: True)(sec))
                except Exception:
                    is_lit = True
                if atk_is_human and is_lit and state.characters[target_id].has_ability(AB.FAST_TALK):
                    bludgeon_ok = False
                    fast_talk_blocked = True

            # ARMORED (Security): no puede ser atacado con BLUDGEON.
            if bludgeon_ok and tgt.has_ability(AB.ARMORED):
                bludgeon_ok = False
                armored_blocked = True

        forced = _norm_data(forced_weapon or "")
        if forced in ("GUN", "G"):
            if not gun_ok:
                raise ActionError("No puedes usar GUN contra ese objetivo.")
            return "GUN"
        if forced in ("BLUDGEON", "B", "BLUDG", "BLUD"):
            if not bludgeon_ok:
                if armored_blocked:
                    raise ActionError("ARMORED: No puedes atacar con Bludgeon a ese objetivo. Usa Gun.")
                if fast_talk_blocked:
                    raise ActionError("FAST_TALK: No puedes atacar con Bludgeon a ese objetivo en una sección iluminada si eres Human. Usa Gun o ataca en una Dark Section.")
                if target_kind == "CHAR":
                    tgt = state.characters[target_id]
                    if ('HUMAN' in _norm_data(getattr(tgt, "ctype", ""))) and state.is_helmeted(target_id) and (not state.characters[attacker].has_ability(AB.BRUTAL)):

                        raise ActionError("No puedes atacar con Bludgeon a un Human Helmeted (salvo BRUTAL).")
                raise ActionError("No puedes usar BLUDGEON contra ese objetivo.")
            return "BLUDGEON"

        # Preferimos Gun si está disponible y legal; si no, Bludgeon.
        if gun_ok:
            return "GUN"
        if bludgeon_ok:
            return "BLUDGEON"

        # Mensajes de error más claros.
        if target_kind == "CHAR":
            if armored_blocked and (not gun_ok) and has_bludgeon:
                raise ActionError("ARMORED: No puedes atacar con Bludgeon a ese objetivo. Necesitas Gun.")
            if fast_talk_blocked and (not gun_ok) and has_bludgeon:
                raise ActionError("FAST_TALK impide atacar con Bludgeon a ese objetivo en sección iluminada. Necesitas Gun o moverte a una sección Dark.")
            tgt = state.characters[target_id]
            ctype = _norm_data(getattr(tgt, "ctype", ""))
            if ('HUMAN' in ctype) and state.is_helmeted(target_id) and has_bludgeon and not has_gun:
                raise ActionError("No puedes atacar con Bludgeon a un Human Helmeted. Necesitas Gun (RM 8.1.1 / 12.8.1).")
            if has_bludgeon and not has_gun:
                raise ActionError("Con Bludgeon sólo puedes atacar Robots o Humans Unhelmeted (RM 12.8.1).")
        raise ActionError("No tienes un arma válida para atacar ese objetivo.")

    def validate(self, state: GameState) -> None:
        attacker = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        tid = str(self.target_id).upper()

        # PEACEKEEPER (Security): antes de perder la restricción, sólo puede ATTACK a
        # - FUGITIVE (ability)
        # - MONSTERS (Project X)
        # - PCs cuyo jugador NO está Innocent
        atk_ch = state.characters.get(attacker)
        if atk_ch and getattr(atk_ch, 'has_ability', lambda _x: False)(AB.PEACEKEEPER):
            allowed = False
            if tid in getattr(state, 'monsters', {}):
                allowed = True
            elif tid in getattr(state, 'characters', {}):
                if _char_has_fugitive(state, tid) or _is_revealed_pc_non_innocent(state, tid):
                    allowed = True
            if not allowed:
                raise ActionError('PEACEKEEPER: sólo puedes atacar FUGITIVE, MONSTERS o PCs no-Innocent.')

        # --- Target: Character ---
        if tid in state.characters:
            if tid == attacker:
                raise ActionError("No puedes atacarte a ti mismo.")
            tgt = state.characters[tid]
            if tgt.annihilated or tgt.escaped:
                raise ActionError("No puedes hacer acciones contra un Character ESCAPED/ANNIHILATED.")
            if not tgt.is_live():
                raise ActionError("Solo puedes atacar a un personaje LIVE.")
            if not state.colocated(attacker, tid):
                raise ActionError("Debes estar en la misma sección para atacar.")

            # RM 12.8: necesitas Gun o Bludgeon, y el arma limita targets.
            self._choose_weapon_for_target(state, attacker, "CHAR", tid, forced_weapon=self.weapon)
            return

        # --- Target: Monster (Project X) ---
        if tid in getattr(state, "monsters", {}):
            m = state.monsters[tid]
            if not m.is_live():
                raise ActionError("Solo puedes atacar a un Monster LIVE.")

            # RM 12.8: necesitas Gun o Bludgeon.
            self._choose_weapon_for_target(state, attacker, "MONSTER", tid, forced_weapon=self.weapon)
            if state.characters[attacker].section != m.section:
                raise ActionError("Debes estar en la misma sección para atacar.")
            return

        raise ActionError("Target no existe.")

    def apply(self, state: GameState) -> str:
        attacker = state.require_active()
        tid = str(self.target_id).upper()


        # WARY: no se puede atacar a un objetivo en una sección DARK.
        try:
            if tid in state.characters:
                tgt = state.characters[tid]
                if getattr(tgt, "has_ability", None) and tgt.has_ability(AB.WARY):
                    if hasattr(state, "is_lit") and (not state.is_lit(getattr(tgt, "section", ""))):
                        raise ActionError("WARY: No puedes atacar a ese objetivo en una sección DARK.")
            elif tid in getattr(state, "monsters", {}):
                mon = state.monsters[tid]
                if AB.WARY in (getattr(mon, "abilities", set()) or set()):
                    if hasattr(state, "is_lit") and (not state.is_lit(getattr(mon, "section", ""))):
                        raise ActionError("WARY: No puedes atacar a ese Monster en una sección DARK.")
        except ActionError:
            raise
        except Exception:
            # Si algo raro pasa con luz/sección, no bloqueamos el ataque.
            pass


        used_weapon = ""

        if tid in state.characters:
            used_weapon = self._choose_weapon_for_target(state, attacker, "CHAR", tid, forced_weapon=self.weapon)
            tgt = state.characters[tid]
            was_helmeted = bool(state.is_helmeted(tid))

            tgt.status = "DOWN"
            state.spend_action_point(1)

            extra = ""
            if used_weapon == "BLUDGEON" and ('HUMAN' in _norm_data(getattr(tgt, "ctype", ""))) and was_helmeted and state.characters[attacker].has_ability(AB.BRUTAL):

                # Aniquila Bludgeon (del atacante) y Helmet (del objetivo).
                blud_iid = None
                for iid in list(getattr(state.characters[attacker], "items", []) or []):
                    it = state.items.get(iid)
                    if it and _norm_data(getattr(it, "name", "")) == "BLUDGEON":
                        blud_iid = iid
                        break

                helm_iid = None
                for iid in list(getattr(tgt, "items", []) or []):
                    it = state.items.get(iid)
                    if it and getattr(it, 'is_helmet', None) and it.is_helmet():
                        helm_iid = iid
                        break

                if blud_iid and hasattr(state, 'annihilate_item'):
                    state.annihilate_item(blud_iid, reason="BRUTAL")
                if helm_iid and hasattr(state, 'annihilate_item'):
                    state.annihilate_item(helm_iid, reason="BRUTAL")

                extra = f" | 💥 BRUTAL: aniquila {blud_iid or 'Bludgeon'} y {helm_iid or 'Helmet'}"

            return f"Acción: ATTACK ({used_weapon}) {attacker} -> {tid} | {tid} queda DOWN{extra}"

        if tid in getattr(state, "monsters", {}):
            used_weapon = self._choose_weapon_for_target(state, attacker, "MONSTER", tid, forced_weapon=self.weapon)
            mon = state.monsters[tid]
            mk = _norm_data(getattr(mon, "kind", ""))


            # Tentacled Monstrosity (Project X): inmune a DOWN por Attack.
            # (Dossier: solo queda DOWN automáticamente si hay FIRE en su sección.)
            if mk == "TENTACLED":
                state.spend_action_point(1)
                return f"Acción: ATTACK ({used_weapon}) {attacker} -> {tid} (Tentacled) | No effect (ATTACK no lo baja; FIRE lo baja automáticamente)."

            # Otros Monsters: comportamiento simple.
            mon.status = "DOWN"
            state.spend_action_point(1)
            return f"Acción: ATTACK ({used_weapon}) {attacker} -> {tid} (Monster) | {tid} queda DOWN"


        raise ActionError("Target no existe.")


@dataclass
class Rob(Action):
    victim: CharacterId
    item: Optional[ItemId] = None
    data_type: Optional[DataType] = None

    def validate(self, state: GameState) -> None:
        thief = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        # RM 12.9: Rob requiere Gun o Bludgeon, y el arma limita a quién puedes robar.
        thief_ch = state.characters[thief]
        has_gun = False
        has_bludgeon = False
        for iid in getattr(thief_ch, "items", []):
            it = state.items.get(iid)
            nm = _norm_data(getattr(it, "name", "")) if it else ""
            if nm == "GUN":
                has_gun = True
            elif nm == "BLUDGEON":
                has_bludgeon = True

        if not (has_gun or has_bludgeon):
            raise ActionError("Rob requiere poseer un Gun o un Bludgeon (RM 12.9).")
        if self.victim not in state.characters:
            raise ActionError("Victim no existe.")
        vic = state.characters[self.victim]
        if vic.annihilated or vic.escaped:
            raise ActionError("No puedes hacer acciones contra un Character ESCAPED/ANNIHILATED.")
        if not vic.is_live():
            raise ActionError("Rob requiere un personaje LIVE.")
        if not state.colocated(thief, self.victim):
            raise ActionError("Debes estar en la misma sección.")

        # PRIDE (Daredevil): no puede ser ROBado.
        if vic.has_ability(AB.PRIDE):
            raise ActionError("Ese personaje tiene PRIDE y no puede ser ROBado.")

        # Elegibilidad del objetivo según arma (RM 12.9.1-12.9.2).
        ctype = _norm_data(getattr(vic, "ctype", ""))
        is_robot = ("ROBOT" in ctype)
        is_human = ("HUMAN" in ctype)
        unhelmeted_human = is_human and (not state.is_helmeted(vic.cid))

        gun_ok = has_gun
        bludgeon_ok = has_bludgeon and (is_robot or unhelmeted_human)
        if bludgeon_ok and vic.has_ability(AB.ARMORED):
            bludgeon_ok = False

        if not (gun_ok or bludgeon_ok):
            # Mensaje más claro: Helmet protege de Rob con Bludgeon (por la regla de 12.9.1).
            if vic.has_ability(AB.ARMORED) and has_bludgeon and (not has_gun):
                raise ActionError("ARMORED: No puedes Rob con Bludgeon a ese objetivo. Necesitas Gun.")
            if is_human and state.is_helmeted(vic.cid) and has_bludgeon and (not has_gun):
                raise ActionError("No puedes Rob con Bludgeon a un Human Helmeted. Necesitas Gun (RM 12.9).")
            raise ActionError("No tienes un arma válida para Rob a ese objetivo (RM 12.9).")

        if (self.item is None) and (self.data_type is None):
            raise ActionError("Uso: rob <victimCID> <IID|TYPE>")

        if (self.item is not None) and (self.data_type is not None):
            raise ActionError("Rob: especifica solo un objetivo (IID o TYPE).")

        # --- Rob de Item ---
        if self.item is not None:
            if self.item not in vic.items:
                raise ActionError("Ese item no está en el inventario del victim.")

            # RM 8.4: Integral Items no pueden ser robados.
            if _integral_bound_to(state, self.item):
                raise ActionError("Ese item es INTEGRAL y no puede ser ROBado.")
            if not state.can_receive_item(thief, add=1):
                raise ActionError("Límite de inventario alcanzado.")

            # 12.9.3: no puedes robar Helmet a un humano en Hazard si eso le haría caer DOWN.
            it = state.items.get(self.item)
            if it and it.is_helmet():
                if ('HUMAN' in _norm_data(vic.ctype)) and vic.is_live() and state.section_has_hazard(vic.section):
                    # Si le quitas el Helmet, queda unhelmeted en hazard => DOWN por 6.1
                    raise ActionError("No puedes robar el Helmet a un humano en una Hazard si eso lo haría caer DOWN.")
            return

        # --- Rob de Data (se COPIA, no se quita) ---
        want = _norm_data(self.data_type)
        if not want:
            raise ActionError("Falta TYPE de Data.")
        if not getattr(vic, "data", None):
            raise ActionError("Ese personaje no tiene Data.")
        victim_key: Optional[str] = None
        for k in vic.data.keys():
            if _norm_data(k) == want:
                victim_key = str(k)
                break
        if victim_key is None:
            raise ActionError("Ese personaje no tiene ese tipo de Data.")

        thief_ch = state.characters[thief]
        if not hasattr(thief_ch, "data") or thief_ch.data is None:
            thief_ch.data = {}

        # Ref Manual 9.2: un Character solo puede tener 1 copia de cada tipo de Data.
        for k in thief_ch.data.keys():
            if _norm_data(k) == want:
                raise ActionError("Ya tienes ese tipo de Data (solo 1 copia por tipo).")

    def apply(self, state: GameState) -> str:
        thief = state.require_active()
        vic = self.victim

        # Elegimos arma para el texto (ya validado en validate).
        def _choose_weapon() -> str:
            thief_ch = state.characters[thief]
            has_gun = False
            has_bludgeon = False
            for iid in getattr(thief_ch, "items", []):
                it = state.items.get(iid)
                nm = _norm_data(getattr(it, "name", "")) if it else ""
                if nm == "GUN":
                    has_gun = True
                elif nm == "BLUDGEON":
                    has_bludgeon = True

            tgt = state.characters[vic]
            ctype = _norm_data(getattr(tgt, "ctype", ""))
            is_robot = ("ROBOT" in ctype)
            is_human = ("HUMAN" in ctype)
            unhelmeted_human = is_human and (not state.is_helmeted(tgt.cid))

            # RM 12.9: preferimos Gun si existe y es legal; si no, Bludgeon.
            if has_gun:
                return "GUN"
            if has_bludgeon and (is_robot or unhelmeted_human) and (not tgt.has_ability(AB.ARMORED)):
                return "BLUDGEON"
            # En teoría no se llega aquí si validate ha corrido.
            return "?"

        used_weapon = _choose_weapon()

        # --- Item ---
        if self.item is not None:
            itid = self.item
            if _integral_bound_to(state, itid):
                raise ActionError("Ese item es INTEGRAL y no puede ser ROBado.")
            state.characters[vic].items.remove(itid)
            state.characters[thief].items.append(itid)
            state.spend_action_point(1)

            msgs = state.apply_hazard_effects()
            extra = (" | " + " | ".join(msgs)) if msgs else ""
            return f"Acción: ROB ({used_weapon}) {thief} roba {itid} de {vic}{extra}"

        # --- Data (copy) ---
        want = _norm_data(self.data_type)
        victim_key = None
        for k in state.characters[vic].data.keys():
            if _norm_data(k) == want:
                victim_key = str(k)
                break
        assert victim_key is not None

        thief_ch = state.characters[thief]
        if thief_ch.data is None:
            thief_ch.data = {}
        thief_ch.data[victim_key] = 1  # 1 copia por tipo

        state.spend_action_point(1)
        return f"Acción: ROB ({used_weapon}) {thief} copia DATA {victim_key} de {vic}"


@dataclass
class Sabotage(Action):
    def validate(self, state: GameState) -> None:
        cid = state.require_active()

        # PEACEKEEPER (Security): no puede SABOTAGE mientras tenga la habilidad.
        if state.characters[cid].has_ability(AB.PEACEKEEPER):
            raise ActionError('PEACEKEEPER: no puedes hacer Sabotage.')
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        # RM 12.12: Sabotage requiere poseer un Gun o un Bludgeon.
        ch = state.characters[cid]
        has_gun = False
        has_bludgeon = False
        for iid in getattr(ch, "items", []):
            it = state.items.get(iid)
            nm = _norm_data(getattr(it, "name", "")) if it else ""
            if nm == "GUN":
                has_gun = True
            elif nm == "BLUDGEON":
                has_bludgeon = True
        if not (has_gun or has_bludgeon):
            raise ActionError("Sabotage requiere poseer un Gun o un Bludgeon (RM 12.12).")

        sec = state.characters[cid].section

        # Regla global (dossier/tutor): REACTOR nunca puede ser dañada usando BLUDGEON.
        # Para dañarla mediante Sabotage necesitas un Gun (u otro efecto que no sea Bludgeon).
        if str(sec).upper() == "REACTOR" and (not has_gun):
            # Llegar aquí implica que sí tienes Bludgeon (porque validate ya comprobó arma),
            # pero la regla bloquea dañar REACTOR con Bludgeon.
            raise ActionError("REACTOR no puede ser dañada con Bludgeon. Necesitas un Gun u otro efecto.")

        if sec in state.damaged_sections:
            raise ActionError("Esa sección ya está dañada.")

    def apply(self, state: GameState) -> str:
        cid = state.require_active()
        sec = state.characters[cid].section
        # Usa helper central para que el Power Status se actualice siempre
        # que se dañe una Power Section, venga el daño de donde venga.
        if hasattr(state, "damage_section"):
            state.damage_section(sec)
        else:
            state.damaged_sections.add(sec)
            if hasattr(state, "recalc_power_status"):
                state.recalc_power_status()
        
        state.spend_action_point(1)
        return f"Acción: SABOTAGE en {sec} (queda dañada)"


@dataclass
class Revive(Action):
    # Nota: por compatibilidad histórica, mantenemos el nombre target_character,
    # pero acepta tanto CID (Characters) como MID (Monsters).
    target_character: CharacterId

    def validate(self, state: GameState) -> None:
        reviver = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        tgtid = self.target_character
        is_char = tgtid in state.characters
        is_monster = (hasattr(state, 'monsters') and tgtid in getattr(state, 'monsters', {}))

        if not is_char and not is_monster:
            raise ActionError("Target no existe.")

        if is_char and tgtid == reviver:
            raise ActionError("No puedes revivirte a ti mismo.")

        has_er_alpha = state.characters[reviver].has_ability(AB.EMERGENCY_RESPONSE_ALPHA)

        # 12.11.1: normalmente requiere Nanogel. Con EMERGENCY_RESPONSE_ALPHA,
        # puedes Revive a un HUMAN sin Nanogel.
        ng = _find_nanogel_item(state, reviver)
        if ng is None:
            if not has_er_alpha:
                raise ActionError("Revive requiere NANOGEL en tu inventario.")
            if not is_char:
                raise ActionError("Sin Nanogel, solo puedes Revive a un Human (Emergency Response).")
            tgt = state.characters[tgtid]
            if 'HUMAN' not in _norm_data(getattr(tgt, 'ctype', '')):
                raise ActionError("Sin Nanogel, solo puedes Revive a un Human (Emergency Response).")

        if is_char:
            tgt = state.characters[tgtid]
            if tgt.annihilated:
                raise ActionError("No puedes Revive a un personaje ANNIHILATED.")
            if tgt.escaped:
                raise ActionError("No puedes Revive a un personaje ESCAPED.")
            if tgt.status != "DOWN":
                raise ActionError("Solo puedes Revive a un personaje DOWN.")
            if not state.colocated(reviver, tgtid):
                raise ActionError("Debes estar en la misma sección.")

            # 12.11.2 + 6.2: no puedes revivir a un humano unhelmeted en una sección con Hazard,
            # porque quedaría inmediatamente DOWN.
            if ('HUMAN' in _norm_data(tgt.ctype)) and state.section_has_hazard(tgt.section) and (not state.is_helmeted(tgt.cid)):

                raise ActionError("No puedes revivir a un humano unhelmeted en una Hazard: quedaría inmediatamente DOWN.")

        else:
            m = state.monsters[tgtid]
            if m.status != "DOWN":
                raise ActionError("Solo puedes Revive a un Monster DOWN.")
            if state.characters[reviver].section != m.section:
                raise ActionError("Debes estar en la misma sección.")

    def apply(self, state: GameState) -> str:
        self.validate(state)

        reviver = state.require_active()
        tgtid = self.target_character

        reviver_ch = state.characters[reviver]
        has_er_alpha = reviver_ch.has_ability(AB.EMERGENCY_RESPONSE_ALPHA)
        uses_er_alpha = False
        if has_er_alpha and tgtid in state.characters:
            tgt = state.characters[tgtid]
            uses_er_alpha = ('HUMAN' in _norm_data(getattr(tgt, 'ctype', '')))

        ngid = _find_nanogel_item(state, reviver)
        ng = state.items[ngid] if ngid is not None else None

        forced_down_msg = ""

        if tgtid in state.characters:
            state.characters[tgtid].status = "LIVE"
        else:
            state.monsters[tgtid].status = "LIVE"

            # Tentacled: si hay FIRE en su sección, se mantiene DOWN (FIRE lo baja automáticamente).
            try:
                mon = state.monsters[tgtid]
                if _norm_data(getattr(mon, "kind", "")) == "TENTACLED":
                    msec = str(getattr(mon, "section", "")).upper()
                    if getattr(state, "has_hazard_kind")(msec, "FIRE"):
                        state.monsters[tgtid].status = "DOWN"
                        forced_down_msg = " | Pero hay FIRE: se queda DOWN"
            except Exception:
                pass

        state.spend_action_point(1)

        # Gastar Nanogel (12.11.1) salvo que uses Emergency Response (sin Nanogel).
        nanomsg = ""
        if uses_er_alpha:
            nanomsg = "Emergency Response (sin Nanogel)"
        else:
            assert ng is not None and ngid is not None
            if ng.charges >= 2:
                ng.charges = 1
                nanomsg = f"Nanogel({ngid}) queda en 1"
            else:
                state.characters[reviver].items.remove(ngid)
                state.items.pop(ngid, None)
                nanomsg = f"Nanogel({ngid}) se agota y se retira"

        msgs = state.apply_hazard_effects()
        extra = (" | " + " | ".join(msgs)) if msgs else ""

        # MEDICAL marker (Character Dossier): +1 por cada Human Revival realizado por Medical.
        marker_msg = ''
        try:
            if str(getattr(reviver_ch, 'name', '')).strip().upper() == 'MEDICAL' and (tgtid in state.characters):
                tgtch = state.characters.get(tgtid)
                if tgtch and ('HUMAN' in _norm_data(getattr(tgtch, 'ctype', ''))):
                    if hasattr(state, 'inc_character_counter'):
                        mk = state.inc_character_counter(reviver, 'MEDICAL_MARKER', 1, cap=11)
                        marker_msg = ' | Medical marker -> ' + str(mk)
        except Exception:
            pass

        return f"Acción: REVIVE {reviver} revive a {tgtid} (LIVE) | {nanomsg}{extra}{marker_msg}{forced_down_msg}"



@dataclass
class JuryRig(Action):
    """RM 5.1.4 + Character Dossier (Engineer / Troubleshooter):

    As an Action, Repair a Colocated Damaged Section OR Repair a Colocated Down Robot.

    CLI:
      - juryrig section
      - juryrig <CID>   (solo Robots)
      - juryrig         (auto si no hay ambigüedad)
    """

    # Si target_cid es None y target_section es False => auto.
    target_cid: Optional[CharacterId] = None
    target_section: bool = False

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        ch = state.characters[actor]
        if not state.effective_has_ability(actor, AB.JURY_RIG):
            raise ActionError("No tienes la habilidad JURY RIG.")

        here = ch.section

        # Opciones posibles
        can_repair_section = here in getattr(state, "damaged_sections", set())

        down_robots_here: List[CharacterId] = []
        for cid, other in state.characters.items():
            if cid == actor:
                continue
            if not state.colocated(actor, cid):
                continue
            if bool(getattr(other, "annihilated", False)) or bool(getattr(other, "escaped", False)):
                continue
            if 'ROBOT' not in str(getattr(other, "ctype", "")).upper():
                continue
            if str(getattr(other, "status", "")).upper() != "DOWN":
                continue
            down_robots_here.append(cid)

        # Caso explícito: reparar sección
        if self.target_section:
            if not can_repair_section:
                raise ActionError(f"La sección {here} no está dañada.")
            return

        # Caso explícito: reparar robot
        if self.target_cid is not None:
            tgtid = str(self.target_cid).upper()
            if tgtid not in state.characters:
                raise ActionError("Ese Character no existe.")
            if not state.colocated(actor, tgtid):
                raise ActionError("Debe estar COLOCATED contigo.")
            tgt = state.characters[tgtid]
            if bool(getattr(tgt, "annihilated", False)) or bool(getattr(tgt, "escaped", False)):
                raise ActionError("Target fuera del juego.")
            if 'ROBOT' not in str(getattr(tgt, "ctype", "")).upper():
                raise ActionError("JURY RIG solo repara Robots.")
            if str(getattr(tgt, "status", "")).upper() != "DOWN":
                raise ActionError("Ese Robot no está DOWN.")
            return

        # AUTO
        if not can_repair_section and not down_robots_here:
            raise ActionError("No hay nada que reparar (ni sección dañada ni Robot DOWN COLOCATED).")

        if can_repair_section and len(down_robots_here) == 0:
            self.target_section = True
            return

        if (not can_repair_section) and len(down_robots_here) == 1:
            self.target_cid = down_robots_here[0]
            return

        # Ambiguo
        opts = []
        if can_repair_section:
            opts.append("section")
        if down_robots_here:
            opts.append("robots: " + ", ".join(sorted(down_robots_here)))
        raise ActionError("JURY RIG ambiguo. Especifica: juryrig section | juryrig <CID> (" + "; ".join(opts) + ")")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        actor = state.require_active()
        here = state.characters[actor].section

        msg_core = ""
        if self.target_section:
            changed = state.repair_section(here)
            if not changed:
                raise ActionError(f"La sección {here} no está dañada.")
            msg_core = f"REPAIR SECTION {here}"
        else:
            assert self.target_cid is not None
            tgtid = str(self.target_cid).upper()
            tgt = state.characters[tgtid]
            tgt.status = "LIVE"
            msg_core = f"REPAIR ROBOT {tgtid} (LIVE)"

        state.spend_action_point(1)

        msgs = state.apply_hazard_effects()
        extra = (" | " + " | ".join(msgs)) if msgs else ""
        return f"Acción: JURY RIG {actor} -> {msg_core}{extra}"


@dataclass
class CopyData(Action):
    """
    RM 12.6 + 7.4:
    - Copias un tipo de Data que POSEES (del actor) a OTRO Character.
    - Con Jammers ON: solo a COLOCATED.
    - Con Jammers OFF: a cualquier Character (pero no Escaped/Annihilated).
    """
    data_type: DataType
    to_character: CharacterId

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")
        if not self.data_type:
            raise ActionError("data_type vacío.")
        if not self.to_character:
            raise ActionError("Uso: copydata <TYPE> <toCID>")

        if self.to_character not in state.characters:
            raise ActionError("Ese personaje destino no existe.")
        if self.to_character == actor:
            raise ActionError("CopyData debe ser a OTRO personaje (no a ti mismo).")

        tgt = state.characters[self.to_character]
        if tgt.annihilated:
            raise ActionError("No puedes copiar Data a un Character ANNIHILATED.")
        if tgt.escaped:
            raise ActionError("No puedes copiar Data a un Character ESCAPED.")

        ch = state.characters[actor]
        if not getattr(ch, "data", None):
            raise ActionError("No tienes Data para copiar.")

        want = _norm_data(self.data_type)

        # actor debe poseer ese tipo
        actor_key: Optional[str] = None
        for k in ch.data.keys():
            if _norm_data(k) == want:
                actor_key = str(k)
                break
        if actor_key is None:
            raise ActionError(f"No posees ese Data: {self.data_type}")

        # destino no puede tener ya ese tipo (1 copia por tipo)
        if not hasattr(tgt, "data") or tgt.data is None:
            tgt.data = {}
        for k in tgt.data.keys():
            if _norm_data(k) == want:
                raise ActionError("El destino ya tiene ese tipo de Data (solo 1 copia por tipo).")

        # regla Jammers (7.4.1 / 7.4.2)
        if getattr(state, "jammers_on", False):
            if not state.colocated(actor, self.to_character):
                raise ActionError("Con JAMMERS ON solo puedes Copy Data a un Character COLOCATED.")

    def apply(self, state: GameState) -> str:
        self.validate(state)

        actor = state.require_active()
        ch = state.characters[actor]
        tgt = state.characters[self.to_character]

        want = _norm_data(self.data_type)

        actor_key = None
        for k in ch.data.keys():
            if _norm_data(k) == want:
                actor_key = str(k)
                break
        assert actor_key is not None

        if tgt.data is None:
            tgt.data = {}
        tgt.data[actor_key] = 1

        state.spend_action_point(1)
        return f"Acción: COPY DATA {actor_key} {actor} -> {self.to_character}"


@dataclass
class DeleteData(Action):
    data_type: DataType

    def validate(self, state: GameState) -> None:
        cp = state.current_player()
        cid = state.require_active()
        if cp.revealed_character is None:
            raise ActionError("No puedes DELETE DATA sin haber hecho Reveal de tu PC.")
        if cid != cp.revealed_character:
            raise ActionError("DELETE DATA solo puede hacerlo tu PC (activa tu PC).")
        if state.characters[cid].data.get(self.data_type, 0) <= 0:
            raise ActionError("No tienes ese tipo de Data para borrar.")
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

    def apply(self, state: GameState) -> str:
        cid = state.require_active()
        ch = state.characters[cid]
        ch.data[self.data_type] -= 1
        if ch.data[self.data_type] <= 0:
            del ch.data[self.data_type]
        state.spend_action_point(1)
        return f"Acción: DELETE DATA {self.data_type} desde {cid} (devuelto al supply)"


@dataclass
class SetJammers(ConsoleAction):
    """
    RM 14.2: Jammers ON/OFF es una CONSOLE ACTION.
    RM 11.6: sólo en secciones con icono de consola y sin daño.
    """
    on: bool
    use_free_slot: bool = False
    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        ch = state.characters[actor]

        # HACKER (Exile): puede usar su Free Pick Up/Drop para hacer UNA Console Action.
        # Si JAMMERS está OFF, puede hacerlo desde cualquier sección (sin estar sobre la consola).
        ctu = str(getattr(ch, 'ctype', '')).upper()
        is_hr = ('HUMAN' in ctu) or ('ROBOT' in ctu)
        can_hacker_free = ch.has_ability(AB.HACKER) and is_hr and (not getattr(state, 'free_pickdrop_used', False))

        # Auto (HACKER): si queda el slot "Free Pick Up/Drop" disponible,
        # se usa AUTOMATICAMENTE para la Console Action (no hace falta pedir [free]).
        if (not self.use_free_slot) and can_hacker_free:
            self.use_free_slot = True

        if self.use_free_slot:
            if not can_hacker_free:
                raise ActionError('No puedes usar HACKER ahora (slot free ya usado o no aplica).')
        else:
            if state.remaining_actions() <= 0:
                raise ActionError('No te quedan acciones.')

        sec = state.characters[actor].section

        remote_ok = bool(self.use_free_slot) and ch.has_ability(AB.HACKER) and (not getattr(state, 'jammers_on', False))
        if remote_ok:
            if not _any_section_has_console(state, 'JAMMERS'):
                raise ActionError('No existe una Console: Jammers operativa en el mapa.')
        else:
            if sec in getattr(state, 'damaged_sections', set()):
                raise ActionError('La sección está dañada: no puedes usar su Console Action.')
            if not _room_has_console(state, sec, 'JAMMERS'):
                raise ActionError('Esta sección no tiene Console: Jammers ON/OFF (según lo impreso/demo).')

        # Reference Manual §7.2.1.1: cuando el Power Status está en Backup Power
        # (o peor), CAMERAS y JAMMERS están OFF y NO pueden encenderse hasta que
        # el Power vuelva a Normal.
        if self.on and getattr(state, 'power_status', 'Normal Power') != 'Normal Power':
            ps = getattr(state, 'power_status', '?')
            raise ActionError(f'No puedes encender JAMMERS con Power Status={ps}. Repara Power para volver a Normal.')

        # Mapa básico: si SECURITY_STATION está dañada, CAMERAS y JAMMERS deben estar OFF
        # y no pueden encenderse hasta repararla.
        if self.on and ('SECURITY_STATION' in getattr(state, 'damaged_sections', set())):
            raise ActionError('SECURITY STATION está dañada: no puedes encender los JAMMERS hasta repararla.')

    def apply(self, state: GameState) -> str:
        self.validate(state)
        state.jammers_on = bool(self.on)
        if self.use_free_slot:
            state.free_pickdrop_used = True
            cost = 'free(HACKER)'
        else:
            state.spend_action_point(1)
            cost = 'action'
        return f"Console: JAMMERS={'ON' if self.on else 'OFF'} | coste={cost}"





@dataclass
class SetCameras(SectionAction):
    """
    Cameras ON/OFF (Section Action normal).
    (De momento solo estado global; sin consecuencias aún.)
    """
    on: bool

    def validate(self, state: GameState) -> None:
        actor = getattr(state, "active_character_id", None)
        if not actor:
            raise ActionError("Tienes que activar un personaje antes de usar Cameras.")
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")
        sec = state.characters[actor].section
        if sec in getattr(state, "damaged_sections", set()):
            raise ActionError("La sección está dañada: no puedes usar su acción de habitación.")
        if not _room_has_cameras(state, sec):
            raise ActionError("En esta sección no existe la acción CAMERAS (según lo impreso).")

        # Reference Manual §7.2.1.1: con Power Status en Backup Power (o peor),
        # CAMERAS y JAMMERS no pueden encenderse hasta restaurar Power.
        if self.on and getattr(state, "power_status", "Normal Power") != "Normal Power":
            ps = getattr(state, "power_status", "?")
            raise ActionError(f"No puedes encender CAMERAS con Power Status={ps}. Repara Power para volver a Normal.")

        # Mapa básico: si SECURITY_STATION está dañada, CAMERAS y JAMMERS deben estar OFF
        # y no pueden encenderse hasta repararla.
        if self.on and ("SECURITY_STATION" in getattr(state, "damaged_sections", set())):
            raise ActionError("SECURITY STATION está dañada: no puedes encender las CAMERAS hasta repararla.")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        state.cameras_on = self.on
        state.spend_action_point(1)
        return f"Acción: CAMERAS={'ON' if self.on else 'OFF'}"


@dataclass
class TransmitData(SectionAction):
    """Section Action: Transmit (RM 13.2)

    Copia 1 tipo de Data que el Character posee a 1 Offsite (AUTHORITIES o NEWS),
    colocando un duplicado en ese Offsite. No elimina la Data original.
    """

    data_type: str
    offsite: str

    def validate(self, state: GameState) -> None:
        actor = getattr(state, "active_character_id", None)
        if not actor:
            raise ActionError("Tienes que activar un personaje antes de usar Transmit.")

        ch = state.characters[actor]
        sec = ch.section

        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        if sec in getattr(state, "damaged_sections", set()):
            raise ActionError("La sección está dañada: no puedes usar su acción de habitación.")

        if not _room_has_transmit(state, sec):
            raise ActionError("En esta sección no existe la acción TRANSMIT (según lo impreso).")

        # RM 13.2.2: Array Control (en el prototipo: 'B')
        # En este motor, nos fiamos de la acción impresa (room_actions) para la validación,
        # así no hardcodeamos el nombre exacto de la sección.

        if not getattr(ch, "data", None):
            raise ActionError("Este personaje no tiene Data para transmitir.")

        want = _norm_data(self.data_type)
        has_it = False
        for k, v in (getattr(ch, "data", {}) or {}).items():
            if _norm_data(k) == want and int(v) > 0:
                has_it = True
                break
        if not has_it:
            raise ActionError(f"No tienes ese Data: {self.data_type}")

        off = str(self.offsite).upper().strip()
        if off not in ("AUTHORITIES", "NEWS"):
            raise ActionError("Offsite inválido. Usa AUTHORITIES o NEWS.")

    def apply(self, state: GameState) -> str:
        self.validate(state)

        cp = state.current_player()
        want = _norm_data(self.data_type)
        off = str(self.offsite).upper().strip()

        state.spend_action_point(1)

        # Registrar en Offsites (y aplicar 10.2.1 si toca)
        if hasattr(state, "record_transmission"):
            return state.record_transmission(cp.pid, off, want)

        # Fallback por si falta el helper
        state.offsites_data.setdefault(off, {})
        state.offsites_data[off][want] = int(state.offsites_data[off].get(want, 0)) + 1
        return f"Acción: TRANSMIT {want} -> {off}"


@dataclass
class TimedLaunch(SectionAction):
    blackout_exempt: ClassVar[bool] = True
    """Section Action: Timed Launch (RM 13.6).

    Si estás dentro de un Pod, colocas tu Time Marker sobre ese Pod.
    En la fase RESOLVE de tu turno del minuto siguiente, el Pod se LAUNCH.
    """

    pod_section: Optional[str] = None

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        actor_sec = str(state.characters[actor].section).upper()
        if self.pod_section:
            want = str(self.pod_section).upper()
            if want != actor_sec:
                raise ActionError("Timed Launch solo puede hacerse en el Pod en el que estás (usa 'timedlaunch' sin argumentos).")

        sec = actor_sec
        if not hasattr(state, 'is_pod') or not state.is_pod(sec):
            raise ActionError("Timed Launch solo puede hacerse estando dentro de un Pod.")

        pod = getattr(state, 'pods', {}).get(sec)
        if not pod or getattr(pod, 'location', None) != 'ON_BOARD':
            raise ActionError("Ese Pod no está ON_BOARD (ya fue lanzado o no existe).")


        # RM 13.6: requiere que el Pod haya cumplido su launch requirement.
        if hasattr(state, 'pod_launch_requirement_met') and (not state.pod_launch_requirement_met(sec)):
            raise ActionError('Este Pod aún no ha cumplido su launch requirement.')

        # Validación suave según lo impreso: si existe room_actions, exigimos que aparezca.
        ra = getattr(state, 'room_actions', None)
        if isinstance(ra, dict) and sec in ra:
            if not any('TIMED LAUNCH' in str(x).upper() for x in ra.get(sec, [])):
                raise ActionError("Este Pod no tiene la acción TIMED LAUNCH (según lo impreso/demo).")

        # Solo 1 Timed Launch pendiente por Pod (evita duplicados raros).
        for tm in getattr(state, 'time_markers', []):
            if str(getattr(tm, 'kind', '')).upper() == 'TIMED_LAUNCH' and str(getattr(tm, 'target', '')).upper() == sec:
                raise ActionError("Ya hay un Time Marker de Timed Launch colocado en este Pod.")

        cp = state.current_player()
        if hasattr(state, 'time_markers_available') and state.time_markers_available(cp.pid) <= 0:
            raise ActionError("No te quedan Time Markers disponibles.")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        actor = state.require_active()
        sec = str(state.characters[actor].section).upper()

        cp = state.current_player()
        try:
            tm = state.place_time_marker(cp.pid, kind='TIMED_LAUNCH', location='POD', target=sec)
        except Exception as e:
            raise ActionError(str(e))

        state.spend_action_point(1)
        return f"Section Action: TIMED LAUNCH en {sec} | marker={tm.mid} (se resuelve en tu turno del próximo Minute)"

@dataclass
class SectionLaunch(SectionAction):
    """Section Action: Section Launch (RM 13.7).

    If in a Section connected to an Occupied Pod that has met its launch requirement,
    immediately move one such Pod to Mesosphere (i.e., LAUNCH). If the Pod is Damaged,
    it is then Annihilated along with anything in it.
    """

    pod_section: str

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        ch = state.characters[actor]
        sec = str(getattr(ch, 'section', '')).upper()

        # No se puede usar si la sección está dañada (regla general de Section Actions).
        if sec in getattr(state, "damaged_sections", set()):
            raise ActionError("La sección está dañada: no puedes usar su acción de habitación.")

        # Validación suave según lo impreso/demo.
        if not _room_has_section_launch(state, sec):
            raise ActionError("En esta sección no existe la acción SECTION LAUNCH (según lo impreso/demo).")

        pod_sec = str(self.pod_section).upper()
        pod = getattr(state, 'pods', {}).get(pod_sec)
        if not pod or getattr(pod, 'location', None) != 'ON_BOARD':
            raise ActionError("Ese Pod no está ON_BOARD (ya fue lanzado o no existe).")

        # Debe estar conectado a la sección actual (pod.attached_to).
        attached = getattr(pod, 'attached_to', None)
        if (attached is None) or (str(attached).upper() != sec):
            raise ActionError(f"Este Pod no está conectado a tu sección ({sec}).")

        # Pod debe estar "Occupied"
        if hasattr(state, 'pod_is_occupied'):
            if not state.pod_is_occupied(pod_sec):
                raise ActionError("SECTION LAUNCH requiere un Pod OCCUPIED (con algo dentro).")
        else:
            # fallback mínimo
            inside = [x for x in getattr(state, 'characters', {}).values() if str(getattr(x, 'section', '')).upper() == pod_sec and (not getattr(x, 'escaped', False)) and (not getattr(x, 'annihilated', False))]
            if not inside:
                raise ActionError("SECTION LAUNCH requiere un Pod OCCUPIED (con algo dentro).")

        # Launch requirement
        if hasattr(state, 'pod_launch_requirement_met') and (not state.pod_launch_requirement_met(pod_sec)):
            raise ActionError("Este Pod aún no ha cumplido su launch requirement.")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        pod_sec = str(self.pod_section).upper()
        state.spend_action_point(1)
        # Reutilizamos la misma lógica de LAUNCH (incluye caso DAMAGED -> ANNIHILATED)
        return state.launch_pod(pod_sec, source="SECTION LAUNCH")


@dataclass
class BridgeLaunch(SectionAction):
    """Section Action: Bridge Launch (RM 13.8).

    RM 13.8.2: Immediately move all Occupied Pods that have met their launch
    requirements to Mesosphere. If any moved Pods are Damaged, they are then
    Annihilated along with anything in them.

    RM 13.8.3: May only be performed in Bridge by a Character with OFFICER.

    RM 13.8.1: Requiere que Abandon Ship ya haya ocurrido.
    """

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        ch = state.characters[actor]
        sec = str(getattr(ch, 'section', '')).upper()

        # Regla general: no se puede usar Section Action si la sección está dañada.
        if sec in getattr(state, "damaged_sections", set()):
            raise ActionError("La sección está dañada: no puedes usar su acción de habitación.")

        # Debe ser OFFICER.
        if not getattr(ch, 'has_ability', lambda *_: False)(AB.OFFICER):
            raise ActionError("BRIDGE LAUNCH solo puede hacerlo un OFFICER (RM 13.8.3).")

        # Validación suave según lo impreso/demo.
        if not _room_has_bridge_launch(state, sec):
            raise ActionError("En esta sección no existe la acción BRIDGE LAUNCH (según lo impreso/demo).")

        # RM 13.8.1: Requiere Abandon Ship ya activado.
        if not bool(getattr(state, 'abandon_ship', False)):
            raise ActionError('BRIDGE LAUNCH requiere que Abandon Ship ya se haya activado (RM 13.8.1).')

        # Debe haber al menos 1 Pod elegible.
        eligible: List[str] = []
        for pod_sec, pod in getattr(state, 'pods', {}).items():
            if getattr(pod, 'location', None) != 'ON_BOARD':
                continue
            if hasattr(state, 'pod_is_occupied') and (not state.pod_is_occupied(pod_sec)):
                continue
            if hasattr(state, 'pod_launch_requirement_met') and (not state.pod_launch_requirement_met(pod_sec)):
                continue
            eligible.append(str(pod_sec).upper())

        if not eligible:
            raise ActionError("No hay Pods OCCUPIED elegibles para BRIDGE LAUNCH.")

    def apply(self, state: GameState) -> str:
        self.validate(state)

        # Recalcular lista (por si validate dependía de state)
        eligible: List[str] = []
        for pod_sec, pod in getattr(state, 'pods', {}).items():
            if getattr(pod, 'location', None) != 'ON_BOARD':
                continue
            if hasattr(state, 'pod_is_occupied') and (not state.pod_is_occupied(pod_sec)):
                continue
            if hasattr(state, 'pod_launch_requirement_met') and (not state.pod_launch_requirement_met(pod_sec)):
                continue
            eligible.append(str(pod_sec).upper())

        eligible = sorted(set(eligible))
        state.spend_action_point(1)

        msgs: List[str] = []
        for pod_sec in eligible:
            try:
                msgs.append(state.launch_pod(pod_sec, source="BRIDGE LAUNCH"))
            except Exception as e:
                msgs.append(f"BRIDGE LAUNCH: {pod_sec} no pudo lanzarse: {e}")

        launched = ",".join(eligible)
        return f"Section Action: BRIDGE LAUNCH | pods={launched} | " + " ; ".join(msgs)


@dataclass
class AbandonShip(SectionAction):
    """Section Action: Abandon Ship (RM 13.1).

    RM 13.1.1: Trigger Abandon Ship (7.1.) in Bridge.
    RM 13.1.2: May only be performed by a Character with OFFICER.

    Nota: Los efectos del estado Abandon Ship se implementan en
    `GameState.set_abandon_ship(True)` (RM 7.1.1).
    """

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        ch = state.characters[actor]
        sec = str(getattr(ch, 'section', '')).upper()

        # Regla general: no se puede usar Section Action si la sección está dañada.
        if sec in getattr(state, "damaged_sections", set()):
            raise ActionError("La sección está dañada: no puedes usar su acción de habitación.")

        # Debe ser OFFICER.
        if not getattr(ch, 'has_ability', lambda *_: False)(AB.OFFICER):
            raise ActionError("ABANDON SHIP solo puede hacerlo un OFFICER (RM 13.1).")

        # Validación suave según lo impreso/demo.
        if not _room_has_abandon_ship(state, sec):
            raise ActionError("En esta sección no existe la acción ABANDON SHIP (según lo impreso/demo).")

        if bool(getattr(state, 'abandon_ship', False)):
            raise ActionError("Abandon Ship ya está activado.")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        # Activar estado y aplicar efectos (remove all locks).
        if hasattr(state, 'set_abandon_ship'):
            state.set_abandon_ship(True)
        else:
            state.abandon_ship = True
            try:
                state.locks.clear()
            except Exception:
                pass

        state.spend_action_point(1)
        return "Section Action: ABANDON SHIP | Abandon Ship activado (Locks retiradas)."



@dataclass


class SelfDestruct(SectionAction):
    """Section/Console Action: Self-Destruct (Bridge).

    Prototipo (según lo pedido):
    - Solo en BRIDGE.
    - Solo OFFICER.
    - Consume 1 acción.
    - Trigger Abandon Ship (como la acción normal, retirando Locks).
    - Arma la Antimatter (RM 7.3.1) y coloca el Time Marker correspondiente.
    """

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        ch = state.characters[actor]
        sec = str(getattr(ch, 'section', '')).upper()

        if sec != 'BRIDGE':
            raise ActionError("SELF-DESTRUCT solo puede hacerse en BRIDGE.")

        if sec in getattr(state, 'damaged_sections', set()):
            raise ActionError("La sección está dañada: no puedes usar su acción de habitación.")

        if not getattr(ch, 'has_ability', lambda *_: False)(AB.OFFICER):
            raise ActionError("SELF-DESTRUCT solo puede hacerlo un OFFICER.")

        if not _room_has_self_destruct(state, sec):
            raise ActionError("En esta sección no existe la acción SELF-DESTRUCT (según lo impreso/demo).")

    def apply(self, state: GameState) -> str:
        self.validate(state)

        msgs: List[str] = []

        # 1) Abandon Ship (remueve locks)
        try:
            if hasattr(state, 'set_abandon_ship'):
                changed = bool(state.set_abandon_ship(True))
            else:
                prev = bool(getattr(state, 'abandon_ship', False))
                state.abandon_ship = True
                changed = (not prev)
                if changed:
                    try:
                        state.locks.clear()
                    except Exception:
                        pass
        except Exception:
            changed = False

        if changed:
            msgs.append("Abandon Ship activado (Locks retiradas).")
        else:
            msgs.append("Abandon Ship ya estaba activado.")

        # 2) Arm Antimatter
        if hasattr(state, 'arm_antimatter'):
            try:
                msgs.append(state.arm_antimatter(state.current_player().pid))
            except Exception as e:
                msgs.append(f"Antimatter: error al armar ({e})")
        else:
            msgs.append("Antimatter: (arm no implementado)")

        state.spend_action_point(1)
        return "Section Action: SELF-DESTRUCT | " + " | ".join([m for m in msgs if m])



def _room_has_eject_antimatter(state: GameState, sec: str) -> bool:
    """Section/Console Action: Eject Antimatter (Magnetic Containment).

    Validación suave basada en `state.room_actions[sec]` (lo impreso/demo).
    """
    ra = getattr(state, "room_actions", {}).get(sec, [])
    for a in ra:
        na = _norm_data(a)
        if na == "EJECTANTIMATTER":
            return True
        if "EJECT" in na and "ANTIMATTER" in na:
            return True
    return False




class EjectAntimatter(SectionAction):
    """Section Action: Eject Antimatter (Magnetic Containment).

    Prototipo (según lo pedido):
    - Solo en MAGNETIC_CONTAINMENT.
    - Requiere que la Antimatter esté en esa sección y NO esté poseída por nadie.
    - La mueve a OUTER SPACE (teletransporte; no requiere airlock).
    - La arma (RM 7.3.1): trigger Abandon Ship y coloca Time Marker a +4 Minutes.
    - Consume 1 acción.
    """

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        ch = state.characters[actor]
        sec = str(getattr(ch, 'section', '')).upper()

        if sec != "MAGNETIC_CONTAINMENT":
            raise ActionError("EJECT ANTIMATTER solo puede hacerse en MAGNETIC_CONTAINMENT.")

        # Regla general: no se puede usar Section Action si la sección está dañada.
        if sec in getattr(state, "damaged_sections", set()):
            raise ActionError("La sección está dañada: no puedes usar su acción de habitación.")

        # Validación suave según lo impreso/demo.
        if not _room_has_eject_antimatter(state, sec):
            raise ActionError("En esta sección no existe la acción EJECT ANTIMATTER (según lo impreso/demo).")

        aid = state.antimatter_id() if hasattr(state, 'antimatter_id') else None
        if not aid:
            raise ActionError("No hay Antimatter en esta partida.")

        loc_type, loc_val = state.item_location(aid) if hasattr(state, 'item_location') else ("NONE", "")
        if loc_type == "CHAR":
            raise ActionError(f"La Antimatter está poseída por {loc_val}; no puedes ejectarla.")
        if loc_type != "SEC" or str(loc_val).upper() != sec:
            raise ActionError("La Antimatter no está en MAGNETIC_CONTAINMENT.")

    def apply(self, state: GameState) -> str:
        self.validate(state)

        aid = state.antimatter_id()
        # Mover a OUTER SPACE (teleport)
        # Quitar de la sección actual
        cur_sec = "MAGNETIC_CONTAINMENT"
        cur_list = getattr(state, 'section_items', {}).setdefault(cur_sec, [])
        cur_list[:] = [x for x in cur_list if str(x).upper() != str(aid).upper()]

        # Añadir a Outer Space
        out_list = getattr(state, 'section_items', {}).setdefault(OUTER_SPACE_SECTION, [])
        out_list.append(str(aid).upper())

        # Arming (RM 7.3.1) se gestiona en engine.py cuando la Antimatter sale de Magnetic Containment.

        state.spend_action_point(1)
        return "Section Action: EJECT ANTIMATTER -> OUTER SPACE."


class ReleaseProjectX(SectionAction):
    """Section Action: Release Project X (RM 13.3).

    - Solo OFFICER (RM 13.3.2)
    - Puede hacerse en Bridge o Cryo Lab (lo validamos por lo impreso/demo)
    - Dispara Abandon Ship (RM 13.3.1 -> 7.1)
    - Libera Project X (RM 7.6)

    En Blackout, está explícitamente permitida (RM 7.2.2.1), y el Abandon Ship
    disparado NO retira Locks (RM 7.2.2.1).
    """

    blackout_exempt: ClassVar[bool] = True

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan acciones.")

        ch = state.characters[actor]
        sec = str(getattr(ch, 'section', '')).upper()

        # Regla general: no se puede usar Section Action si la sección está dañada.
        if sec in getattr(state, "damaged_sections", set()):
            raise ActionError("La sección está dañada: no puedes usar su acción de habitación.")

        if not getattr(ch, 'has_ability', lambda *_: False)(AB.OFFICER):
            raise ActionError("RELEASE PROJECT X solo puede hacerlo un OFFICER (RM 13.3).")

        if not _room_has_release_project_x(state, sec):
            raise ActionError("En esta sección no existe la acción RELEASE PROJECT X (según lo impreso/demo).")

        if not bool(getattr(state, 'project_x_pending_monsters', {}) or {}):
            raise ActionError("Project X ya está liberado (o no hay ninguno pendiente).")

    def apply(self, state: GameState) -> str:
        self.validate(state)

        # Abandon Ship: en Blackout NO se retiran Locks (RM 7.2.2.1)
        remove_locks = True
        try:
            if getattr(state, 'is_blackout', lambda: False)():
                remove_locks = False
        except Exception:
            pass

        if hasattr(state, 'set_abandon_ship'):
            state.set_abandon_ship(True, remove_locks=remove_locks)
        else:
            state.abandon_ship = True
            if remove_locks:
                try:
                    state.locks.clear()
                except Exception:
                    pass

        rel_msgs = []
        if hasattr(state, 'release_project_x'):
            try:
                rel_msgs = list(state.release_project_x(reason='SECTION_ACTION'))
            except Exception:
                rel_msgs = []
        else:
            pending = getattr(state, 'project_x_pending_monsters', {}) or {}
            for mid, m in list(pending.items()):
                state.monsters[mid] = m
                rel_msgs.append(f"{getattr(m,'name',mid)} aparece en {getattr(m,'section','?')}")
            pending.clear()

        state.spend_action_point(1)
        extra = (" | " + " ; ".join(rel_msgs)) if rel_msgs else ""
        lock_txt = "(no retira Locks)" if not remove_locks else "(retira Locks)"
        return f"Section Action: RELEASE PROJECT X | Abandon Ship {lock_txt}{extra}"


@dataclass
class Decontaminate(SectionAction):
    """Section Action: Decontaminate (RM 13.4).

    RM 13.4.1: Return a Contamination on any one Character in Tanks to supply.
    RM 13.4.2: May be performed by any Character in Tanks.

    Prototipo:
    - Solo afecta a Characters en la *misma* sección que el actor.
    - Elige objetivo con target_character (si no se indica, se asume el propio actor).
    """

    target_character: Optional[CharacterId] = None

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError('No te quedan acciones.')

        ch = state.characters[actor]
        sec = str(getattr(ch, 'section', '')).upper()

        # Regla general: no se puede usar Section Action si la sección está dañada.
        if sec in getattr(state, 'damaged_sections', set()):
            raise ActionError('La sección está dañada: no puedes usar su acción de habitación.')

        # Validación suave según lo impreso/demo.
        if not _room_has_decontaminate(state, sec):
            raise ActionError('En esta sección no existe la acción DECONTAMINATE (según lo impreso/demo).')

        tgt = (self.target_character or actor)
        tgt = str(tgt).upper()
        if tgt not in state.characters:
            raise ActionError('Target inválido.')

        t_ch = state.characters[tgt]
        if str(getattr(t_ch, 'section', '')).upper() != sec:
            raise ActionError('El target debe estar en tu misma sección para Decontaminate.')

        if bool(getattr(t_ch, 'annihilated', False)):
            raise ActionError('El target está ANNIHILATED.')

        if not bool(getattr(t_ch, 'contaminated', False)):
            raise ActionError('Ese personaje no está Contaminated.')

    def apply(self, state: GameState) -> str:
        self.validate(state)

        actor = state.require_active()
        ch = state.characters[actor]
        sec = str(getattr(ch, 'section', '')).upper()

        tgt = str((self.target_character or actor)).upper()
        t_ch = state.characters[tgt]
        t_ch.contaminated = False

        state.spend_action_point(1)
        return f'Section Action: DECONTAMINATE | {tgt}:{t_ch.name} ya no está Contaminated (sec={sec}).'


@dataclass
class Manufacture(SectionAction):
    kind: str
    spec: str

    def validate(self, state: GameState) -> None:
        actor = getattr(state, "active_character_id", None)
        if not actor:
            raise ActionError("Tienes que activar un personaje antes de usar Manufacture.")

        ch = state.characters[actor]
        sec = ch.section

        if getattr(state, "action_points_used", 0) >= getattr(state, "action_points_total", 0):
            raise ActionError("No te quedan acciones.")

        if sec in getattr(state, "damaged_sections", set()):
            raise ActionError("La sección está dañada: no puedes usar su acción de habitación.")

        kind_norm = _norm_data(self.kind)
        if kind_norm not in ("DATA", "ITEM"):
            raise ActionError("Uso: manufacture data <TYPE> | manufacture item <NAME>")

        spec_norm = _norm_data(self.spec)

        printed = _find_printed_manufacture(state, sec, kind_norm, spec_norm)
        if not printed:
            raise ActionError("En esta sección no está disponible ese Manufacture (según lo impreso).")

        if kind_norm == "DATA":
            if not hasattr(ch, "data") or ch.data is None:
                ch.data = {}
            for k in list(ch.data.keys()):
                if _norm_data(k) == spec_norm:
                    raise ActionError("Ya tienes ese Data (solo 1 copia por tipo).")

        if kind_norm == "ITEM":
            # RM 13.9.2: si el Item Limit del Character ya está alcanzado,
            # el Item no puede ser Manufactured.
            # Nota: Contamination ocupa 1 slot (RM 8.5.1), así que delegamos
            # en `state.can_receive_item`.
            if not state.can_receive_item(actor, add=1):
                raise ActionError("Inventario lleno: no puedes fabricar un item.")
            return

    def apply(self, state: GameState) -> str:
        self.validate(state)

        actor = state.active_character_id
        ch = state.characters[actor]
        sec = ch.section

        kind_norm = _norm_data(self.kind)
        spec_norm = _norm_data(self.spec)

        printed = _find_printed_manufacture(state, sec, kind_norm, spec_norm) or self.spec.upper()

        if kind_norm == "DATA":
            if ch.data is None:
                ch.data = {}
            ch.data[printed] = 1
            state.spend_action_point(1)
            return f"Acción: MANUFACTURE DATA {printed} -> {actor}:{ch.name}"

        # ITEM (RM 13.9.1)
        def _new_iid() -> str:
            existing = [str(x).upper() for x in getattr(state, 'items', {}).keys()]
            mx = 0
            for iid in existing:
                m = re.match(r"^I(\d+)$", iid)
                if m:
                    mx = max(mx, int(m.group(1)))
            return f"I{mx + 1}"

        # PISTOL (Print Shop) — OFFICER only (según mapa)
        if spec_norm in ("PISTOL",):
            if not getattr(ch, 'has_ability', lambda *_: False)(AB.OFFICER):
                raise ActionError("MANUFACTURE PISTOL solo puede hacerlo un OFFICER.")
            new_iid = _new_iid()
            state.items[new_iid] = Item(iid=new_iid, name="Gun", kind="GUN")
            ch.items.append(new_iid)
            state.spend_action_point(1)
            return f"Acción: MANUFACTURE ITEM PISTOL -> {new_iid} en {actor}:{ch.name}"

        # BLUDGEON (Print Shop)
        if spec_norm in ("BLUDGEON",):
            new_iid = _new_iid()
            state.items[new_iid] = Item(iid=new_iid, name="Bludgeon", kind="BLUDGEON")
            ch.items.append(new_iid)
            state.spend_action_point(1)
            return f"Acción: MANUFACTURE ITEM BLUDGEON -> {new_iid} en {actor}:{ch.name}"

        # HELMET (Print Shop)
        if spec_norm in ("HELMET",):
            new_iid = _new_iid()
            state.items[new_iid] = Item(iid=new_iid, name="Helmet", kind="HELMET")
            ch.items.append(new_iid)
            state.spend_action_point(1)
            return f"Acción: MANUFACTURE ITEM HELMET -> {new_iid} en {actor}:{ch.name}"

        # NANOGEL (Nanofactory)
        if spec_norm in ("NANOGEL",):
            new_iid = _new_iid()
            state.items[new_iid] = Item(iid=new_iid, name="Nanogel", kind="NANOGEL", charges=2)
            ch.items.append(new_iid)
            state.spend_action_point(1)
            return f"Acción: MANUFACTURE ITEM NANOGEL -> {new_iid} en {actor}:{ch.name}"

        # BOMB (Chem Lab)
        if spec_norm in ("BOMB", "FIREBOMB", "FIRE-BOMB", "FIRE BOMB"):
            new_iid = _new_iid()
            state.items[new_iid] = Item(iid=new_iid, name="Bomb", kind="BOMB")
            ch.items.append(new_iid)
            state.spend_action_point(1)
            return f"Acción: MANUFACTURE ITEM BOMB -> {new_iid} en {actor}:{ch.name}"

        raise ActionError("Manufacture ITEM: ese item no está implementado en el prototipo.")

    def resolve(self, state: GameState) -> str:
        return self.apply(state)



@dataclass
class DataMine(SectionAction):
    """Section Action: Data Mine (Shred Room).

    Dossier (Counselor): Pick up 1 Kompromat from anywhere On Board.

    Prototipo:
    - Solo en una sección con la acción impresa "Data Mine" (demo: SHRED_ROOM).
    - Se elige 1 Kompromat por id de token (I<n>).
    - El token debe estar en el tablero (en una sección), y esa sección debe ser On Board.
    - Pone el Kompromat directamente en la mano de Kompromat del jugador actual.
    - Coste: 1 Action Point.
    """

    item: ItemId

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan Action Points.")

        ch = state.characters.get(actor)
        if not ch or bool(getattr(ch, 'annihilated', False)):
            raise ActionError("Actor inválido.")

        sec = str(getattr(ch, 'section', '')).upper()
        if sec in getattr(state, 'damaged_sections', set()):
            raise ActionError("La sección está dañada: no puedes usar su acción de habitación.")

        if not _room_has_data_mine(state, sec):
            raise ActionError("En esta sección no existe la acción DATA MINE (según lo impreso/demo).")

        iid = str(self.item).upper()
        it = getattr(state, 'items', {}).get(iid)
        if not it or str(getattr(it, 'kind', '')).lower() != 'kompromat':
            raise ActionError("DATA MINE requiere un token Kompromat (id tipo I<n>).")

        # No permitir coger un Kompromat que ya está en la mano secreta de alguien.
        for p in getattr(state, 'players', []):
            if iid in [str(x).upper() for x in getattr(p, 'kompromat_hand', [])]:
                raise ActionError("Ese Kompromat ya está en la mano de un jugador.")

        # Debe estar en una sección On Board.
        loc_type, loc_val = (state.item_location(iid) if hasattr(state, 'item_location') else ("NONE", ""))
        if loc_type != 'SEC':
            raise ActionError("Ese Kompromat no está en una sección del tablero.")

        src_sec = str(loc_val).upper()
        if hasattr(state, 'on_board_sections') and src_sec not in state.on_board_sections():
            raise ActionError("Ese Kompromat no está On Board.")

    def apply(self, state: GameState) -> str:
        self.validate(state)

        iid = str(self.item).upper()
        loc_type, src_sec = state.item_location(iid)
        src_sec = str(src_sec).upper()

        arr = getattr(state, 'section_items', {}).setdefault(src_sec, [])
        # Quitar una ocurrencia.
        for i, x in enumerate(list(arr)):
            if str(x).upper() == iid:
                del arr[i]
                break

        cp = state.current_player()
        cp.kompromat_hand.append(iid)
        state.spend_action_point(1)
        return f"Section Action: DATA MINE | +1 Kompromat ({iid}) -> mano de {cp.pid} | from={src_sec}"


class RocketWingsLaunch(SectionAction):
    """Section Action: Rocket Wings Launch (Daredevil).

    Solo disponible si existe en el mapa (token) — en este prototipo se representa
    como una acción impresa en OUTER SPACE cuando Daredevil está en juego.

    Regla esencial para el prototipo:
    - Debes estar en OUTER SPACE.
    - Debes poseer ROCKET WINGS.
    - Si eres Human, además debes estar Helmeted (RM 8.1.1).
    - Coste: 1 Action Point.
    - Resultado: el Character ESCAPA (lo movemos a MESO y marcamos escaped=True).
    """

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError('No quedan Action Points.')

        ch = state.characters.get(actor)
        if not ch or bool(getattr(ch, 'annihilated', False)) or bool(getattr(ch, 'escaped', False)):
            raise ActionError('Actor inválido.')
        if str(getattr(ch, 'status', '')).upper() != 'LIVE':
            raise ActionError('Debes estar LIVE para hacer acciones.')

        sec = str(getattr(ch, 'section', '')).upper()
        if not getattr(state, 'is_outer_space', lambda s: False)(sec):
            raise ActionError('Rocket Wings Launch solo puede hacerse en OUTER SPACE.')

        if not _room_has_rocket_wings_launch(state, sec):
            raise ActionError('En esta sección no existe la acción ROCKET WINGS LAUNCH (según lo impreso/demo).')

        # Requiere poseer Rocket Wings
        has_wings = False
        for iid in getattr(ch, 'items', []):
            it = getattr(state, 'items', {}).get(str(iid).upper())
            if not it:
                continue
            name_u = str(getattr(it, 'name', '')).strip().upper()
            kind_u = str(getattr(it, 'kind', '')).strip().upper()
            if ('ROCKET' in name_u and 'WINGS' in name_u) or kind_u == 'ROCKET_WINGS':
                has_wings = True
                break
        if not has_wings:
            raise ActionError('Necesitas ROCKET WINGS en inventario.')

        # Si el Character cuenta como Human, requiere Helmet
        if 'HUMAN' in str(getattr(ch, 'ctype', '')).upper():
            if not getattr(state, 'is_helmeted', lambda *_: False)(actor):
                raise ActionError('Un Human necesita HELMET para salir a Outer Space con Rocket Wings.')

    def apply(self, state: GameState) -> str:
        self.validate(state)
        actor = state.active_character_id
        ch = state.characters[actor]
        # Escape: lo movemos a MESO y marcamos flag
        ch.section = 'MESO'
        ch.escaped = True
        state.spend_action_point(1)
        return f'Section Action: ROCKET WINGS LAUNCH | {actor}:{ch.name} ESCAPA -> MESO'

    def resolve(self, state: GameState) -> str:
        return self.apply(state)


class Meditate(SectionAction):
    """Section Action: Meditate (RM 13.10).

    RM 13.10.1: Retrieve all your Influence cubes from the Betrayal box.
    RM 13.10.2: Meditate may only be performed in Therapy Garden by a PC.

    Prototipo:
    - Solo puede hacerlo el PC del jugador activo (si ha revelado, `revealed_character`;
      si no, su `secret_identity`).
    - Solo en una sección que tenga impresa la acción MEDITATE (demo: THERAPY_GARDEN).
    """

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan Action Points.")

        ch = state.characters.get(actor)
        if not ch or bool(getattr(ch, "annihilated", False)):
            raise ActionError("Actor inválido.")

        sec = str(getattr(ch, "section", "")).upper()
        if sec in getattr(state, "damaged_sections", set()):
            raise ActionError("La sección está dañada: no puedes usar su acción de habitación.")

        if not _room_has_meditate(state, sec):
            raise ActionError("En esta sección no existe la acción MEDITATE (según lo impreso/demo).")

        cp = state.current_player()
        pc = cp.revealed_character or cp.secret_identity
        if not pc:
            raise ActionError("Aún no tienes PC asignado.")
        if str(pc).upper() != actor:
            raise ActionError("Meditate solo puede hacerlo tu PC.")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        cp = state.current_player()
        n = int(cp.betrayal_cubes or 0)
        cp.betrayal_cubes = 0
        cp.supply_cubes += n
        state.spend_action_point(1)
        return f"Section Action: MEDITATE | Recuperas {n} cubos de Betrayal → Supply."





@dataclass
class RepairRobot(SectionAction):
    """Section Action: Repair (Machine Shop) (RM 13.11).

    In Machine Shop, make a Down Colocated Robot Live.
    No requiere Nanogel ni habilidad especial.
    """

    target_character: CharacterId

    def validate(self, state: GameState) -> None:
        actor = state.require_active()
        if state.remaining_actions() <= 0:
            raise ActionError("No te quedan Action Points.")

        ch = state.characters.get(actor)
        if not ch or bool(getattr(ch, "annihilated", False)):
            raise ActionError("Actor inválido.")

        sec = str(getattr(ch, "section", "")).upper()
        if sec in getattr(state, "damaged_sections", set()):
            raise ActionError("La sección está dañada: no puedes usar su acción de habitación.")

        if not _room_has_repair_robot(state, sec):
            raise ActionError("En esta sección no existe la acción REPAIR (según lo impreso/demo).")

        tgt = str(self.target_character).upper()
        if tgt not in state.characters:
            raise ActionError("No existe ese Character.")
        t = state.characters[tgt]

        if _is_escaped_or_annihilated(t):
            raise ActionError("No puedes reparar a un Character ESCAPED/ANNIHILATED.")

        if str(getattr(t, "section", "")).upper() != sec:
            raise ActionError("El Robot debe estar COLOCATED (en tu misma sección).")

        if str(getattr(t, "ctype", "")).upper() != "ROBOT":
            raise ActionError("REPAIR solo funciona con Robots.")

        if str(getattr(t, "status", "")).upper() != "DOWN":
            raise ActionError("El Robot debe estar DOWN.")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        actor = state.active_character_id
        sec = str(state.characters[actor].section).upper()
        tgt = str(self.target_character).upper()
        state.characters[tgt].status = "LIVE"
        state.spend_action_point(1)
        return f"Section Action: REPAIR | {tgt} (Robot) pasa a LIVE en {sec}."


@dataclass
class UseKompromat(Action):
    token: ItemId
    subaction: Action
    consent: Optional[bool] = None

    def validate(self, state: GameState) -> None:
        cp = state.current_player()
        if cp.turn_kompromat_attempted:
            raise ActionError("Ya has intentado usar Kompromat este turno.")
        if state.active_character_id is None:
            raise ActionError("Debes haber activado (activate <CID>) antes de usar Kompromat.")
        if self.token not in cp.kompromat_hand:
            raise ActionError("No tienes ese Kompromat.")
        tok = state.items.get(self.token)
        if tok is None or tok.kind != "kompromat":
            raise ActionError("Ese token no es Kompromat.")
        if not tok.kompromat_target or tok.kompromat_target not in state.characters:
            raise ActionError("Ese Kompromat no tiene target válido.")
        tgt = tok.kompromat_target
        if _is_escaped_or_annihilated(state.characters[tgt]):
            raise ActionError("No puedes usar Kompromat con un Character ESCAPED/ANNIHILATED.")
        if not state.characters[tgt].is_live():
            raise ActionError("No puedes usar Kompromat con un personaje no LIVE.")

        owner = state.pc_owner_pid(tgt)
        if owner is not None and owner != cp.pid:
            if self.consent is None:
                raise ActionError("Necesitas consentimiento del dueño del PC para usar Kompromat con ese PC.")

        shadow = state.clone()
        shadow.active_character_id = tgt
        shadow.free_pickdrop_used = True
        shadow.action_points_total = 1
        shadow.action_points_used = 0

        if isinstance(self.subaction, PickUp):
            self.subaction.force_cost_action = True
        if isinstance(self.subaction, Drop):
            self.subaction.force_cost_action = True

        # Nota: No aplicamos aquí modificaciones de coste por habilidades como ZEROBORN.
        # La acción forzada se valida directamente en la subaction sobre el estado shadow.

        # STOWAWAY: si el target está fuera del mapa, la primera acción forzada debe ser MOVE a DARK.
        try:
            t_ch = shadow.characters.get(tgt)
            if t_ch is not None and _is_stowaway_undeployed(t_ch):
                if not isinstance(self.subaction, Move):
                    raise ActionError('STOWAWAY: la primera acción debe ser MOVE a una sección DARK.')
                to_u = str(getattr(self.subaction, 'to_section', '')).upper()
                unlit = {str(x).upper() for x in getattr(shadow, 'unlit_sections', set())}
                if to_u not in unlit:
                    raise ActionError('STOWAWAY: la primera acción debe ser MOVE a una sección DARK.')
        except ActionError:
            raise
        except Exception:
            pass

        self.subaction.validate(shadow)

        # RM 11.2 Self Preservation aplicado al TARGET (acción forzada).
        # Si la acción propuesta dejara al objetivo DOWN o ANNIHILATED de forma inmediata,
        # entonces esa acción no es elegible (el Character no la haría).
        try:
            sim2 = shadow.clone() if hasattr(shadow, 'clone') else None
            if sim2 is None:
                import copy
                sim2 = copy.deepcopy(shadow)
            self.subaction.validate(sim2)
            self.subaction.apply(sim2)
            sim_tgt = getattr(sim2, 'characters', {}).get(tgt)
            if sim_tgt is not None:
                would_be_down = str(getattr(sim_tgt, 'status', 'LIVE')).upper() == 'DOWN'
                would_be_annih = bool(getattr(sim_tgt, 'annihilated', False))
                if would_be_down or would_be_annih:
                    raise ActionError('Self Preservation (RM 11.2): el objetivo no puede hacer una acción que le deje DOWN o ANNIHILATED inmediatamente.')
        except ActionError:
            raise
        except Exception:
            # Si la simulación falla por algo interno, no bloqueamos (evita falsos positivos).
            pass

    def apply(self, state: GameState) -> str:
        cp = state.current_player()
        cp.turn_kompromat_attempted = True

        tok = state.items[self.token]
        tgt = tok.kompromat_target
        assert tgt is not None

        owner = state.pc_owner_pid(tgt)

        if owner is not None and owner != cp.pid and self.consent is False:
            # PC rehúsa tras oír la acción propuesta: no se ejecuta.
            proposed_desc = repr(self.subaction)

            op = state.player_by_id(owner)
            if op.legal == "Innocent":
                op.legal = "Suspect"

            # El Kompromat vuelve a la mano del jugador que lo usó (sigue en cp.kompromat_hand).
            return f"🕵️  Kompromat RECHAZADO por {owner} ({tgt}) | {proposed_desc} | legal({owner})={op.legal}"

        # Ejecutar la subacción SOBRE el estado real, pero en un contexto forzado:
        # - el actor es el target
        # - 1 AP disponible (pero suprimimos el gasto para que sea realmente gratis para el jugador)
        # - free pick/drop ya gastado

        desc = ""
        orig_active = state.active_character_id
        orig_ap_total = getattr(state, "action_points_total", 0)
        orig_ap_used = getattr(state, "action_points_used", 0)
        orig_free = getattr(state, "free_pickdrop_used", False)
        orig_suppress = getattr(state, "_suppress_action_point_spend", False)

        try:
            state.active_character_id = tgt
            state.free_pickdrop_used = True
            state.action_points_total = 1
            state.action_points_used = 0
            state._suppress_action_point_spend = True

            if isinstance(self.subaction, PickUp):
                self.subaction.force_cost_action = True
            if isinstance(self.subaction, Drop):
                self.subaction.force_cost_action = True

            desc = self.subaction.apply(state)
        finally:
            state.active_character_id = orig_active
            state.free_pickdrop_used = orig_free
            state.action_points_total = orig_ap_total
            state.action_points_used = orig_ap_used
            state._suppress_action_point_spend = orig_suppress

        state.characters[tgt].kompromat_marks += 1

        # BLOOD_FROM_A_STONE (Exile, Reveal Power): al usar Kompromat sobre un NPC, vuelve a tu mano.
        keep_token = False
        try:
            pcid = getattr(cp, "revealed_character", None)
            if pcid and pcid in state.characters:
                pcch = state.characters[pcid]
                if pcch.has_ability(AB.BLOOD_FROM_A_STONE) and str(getattr(pcch, "pc_owner", "")) == str(cp.pid):
                    keep_token = True
        except Exception:
            keep_token = False

        if keep_token and owner is None:
            return f"🕵️  Kompromat usado: {self.token} -> {tgt} | {desc} | 🩸 BLOOD FROM A STONE: vuelve a tu mano"

        # Si el Kompromat se ha usado sobre un NPC y va a descartarse, lo guardamos
        # para que TRADECRAFT (Exile) pueda recuperarlo más tarde.
        if owner is None:
            try:
                used = getattr(state, "used_npc_kompromat", None)
                if used is None:
                    state.used_npc_kompromat = {}
                state.used_npc_kompromat[self.token] = tok
            except Exception:
                pass

        cp.kompromat_hand.remove(self.token)
        state.items.pop(self.token, None)

        return f"🕵️  Kompromat usado: {self.token} -> {tgt} | {desc}"


@dataclass
class Tradecraft(Action):
    '''
    EXILE — Tradecraft (Reveal Power / acción).

    Dossier: As an Action with Exile, discard two Kompromat from your hand and
    take a previously used NPC's Kompromat into your hand.

    Implementación:
    - Requiere activar el Character y que sea tu PC revelado (pc_reveal_active),
      porque es un Reveal Power.
    - Cuesta 1 acción.
    - Descarta 2 Kompromat de tu mano (se eliminan del juego).
    - Recupera 1 Kompromat previamente usado sobre un NPC (guardado en state.used_npc_kompromat).
    '''

    discard_a: ItemId
    discard_b: ItemId
    take: ItemId

    def validate(self, state: GameState) -> None:
        cp = state.current_player()
        try:
            actor = state.require_active()
        except Exception:
            raise ActionError("Debes haber activado (activate <CID>) antes de usar Tradecraft.")

        ch = state.characters[actor]
        if not ch.has_ability(AB.TRADECRAFT):
            raise ActionError("TRADECRAFT no está disponible para este Character.")
        if str(getattr(ch, "pc_owner", "")) != str(cp.pid):
            raise ActionError("TRADECRAFT solo puede usarse con tu PC revelado.")

        if state.remaining_actions() < 1:
            raise ActionError("No te quedan acciones.")

        a = str(self.discard_a).upper()
        b = str(self.discard_b).upper()
        take = str(self.take).upper()
        if a == b:
            raise ActionError("Debes elegir 2 Kompromat distintos para descartar.")

        hand = getattr(cp, "kompromat_hand", []) or []
        for kid in (a, b):
            if kid not in hand:
                raise ActionError(f"No tienes el Kompromat {kid} en la mano.")
            tok = getattr(state, "items", {}).get(kid)
            if tok is None or getattr(tok, "kind", "") != "kompromat":
                raise ActionError(f"{kid} no es un Kompromat válido.")

        used = getattr(state, "used_npc_kompromat", {}) or {}
        if not used:
            raise ActionError("No hay Kompromat usados sobre NPC disponibles para recuperar.")
        if take not in used:
            avail = ", ".join(sorted(used.keys()))
            raise ActionError(f"Ese Kompromat no está disponible. Disponibles: {avail if avail else '(ninguno)'}")

        if take in hand:
            raise ActionError("Ese Kompromat ya está en tu mano.")

    def apply(self, state: GameState) -> str:
        self.validate(state)
        cp = state.current_player()
        a = str(self.discard_a).upper()
        b = str(self.discard_b).upper()
        take = str(self.take).upper()

        # Descarta 2 Kompromat de la mano (se eliminan).
        for kid in (a, b):
            try:
                cp.kompromat_hand.remove(kid)
            except ValueError:
                pass
            state.items.pop(kid, None)

        # Recupera 1 Kompromat usado sobre NPC.
        used = getattr(state, "used_npc_kompromat", {})
        tok = used.pop(take)
        state.items[take] = tok
        cp.kompromat_hand.append(take)

        # Coste de acción
        state.spend_action_point(1)

        tgt = getattr(tok, "kompromat_target", None)
        return f"Acción: TRADECRAFT | descartas {a},{b} | recuperas {take} -> {tgt}"


@dataclass
class UseBribe(Action):
    target_character: CharacterId
    subaction: Action
    consent: Optional[bool] = None

    def validate(self, state: GameState) -> None:
        cp = state.current_player()
        if cp.turn_bribe_attempted:
            raise ActionError("Ya has intentado usar Bribe este turno.")
        if state.active_character_id is None:
            raise ActionError("Debes haber activado (activate <CID>) antes de usar Bribe.")
        if cp.bribes <= 0:
            raise ActionError("No te quedan Bribes.")
        tgt = self.target_character
        if tgt not in state.characters:
            raise ActionError("Ese personaje no existe.")
        if _is_escaped_or_annihilated(state.characters[tgt]):
            raise ActionError("No puedes usar Bribe con un Character ESCAPED/ANNIHILATED.")
        if not state.characters[tgt].is_live():
            raise ActionError("El objetivo del Bribe debe ser un personaje LIVE.")

        owner = state.pc_owner_pid(tgt)
        if owner is not None and owner == cp.pid:
            raise ActionError("No puedes usar Bribe con tu propio PC.")
        if owner is not None and owner != cp.pid:
            if self.consent is None:
                raise ActionError("Necesitas consentimiento del dueño del PC para Bribe con ese PC.")

        shadow = state.clone()
        shadow.active_character_id = tgt
        shadow.free_pickdrop_used = True
        shadow.action_points_total = 1
        shadow.action_points_used = 0
        if isinstance(self.subaction, PickUp):
            self.subaction.force_cost_action = True
        if isinstance(self.subaction, Drop):
            self.subaction.force_cost_action = True
        # Nota: antes intentábamos considerar aquí el coste "free" de ZEROBORN.
        # Este bloque no pertenece a Kompromat/Bribe: el coste/validación de MOVE con ZEROBORN
        # se resuelve dentro de Move.validate/apply, con el active_character correcto.

        # STOWAWAY: si el target está fuera del mapa, la primera acción forzada debe ser MOVE a DARK.
        try:
            t_ch = shadow.characters.get(tgt)
            if t_ch is not None and _is_stowaway_undeployed(t_ch):
                if not isinstance(self.subaction, Move):
                    raise ActionError('STOWAWAY: la primera acción debe ser MOVE a una sección DARK.')
                to_u = str(getattr(self.subaction, 'to_section', '')).upper()
                unlit = {str(x).upper() for x in getattr(shadow, 'unlit_sections', set())}
                if to_u not in unlit:
                    raise ActionError('STOWAWAY: la primera acción debe ser MOVE a una sección DARK.')
        except ActionError:
            raise
        except Exception:
            pass

        self.subaction.validate(shadow)

        # RM 11.2 Self Preservation aplicado al TARGET (acción forzada).
        # Si la acción propuesta dejara al objetivo DOWN o ANNIHILATED de forma inmediata,
        # entonces esa acción no es elegible (el Character no la haría).
        try:
            sim2 = shadow.clone() if hasattr(shadow, 'clone') else None
            if sim2 is None:
                import copy
                sim2 = copy.deepcopy(shadow)
            self.subaction.validate(sim2)
            self.subaction.apply(sim2)
            sim_tgt = getattr(sim2, 'characters', {}).get(tgt)
            if sim_tgt is not None:
                would_be_down = str(getattr(sim_tgt, 'status', 'LIVE')).upper() == 'DOWN'
                would_be_annih = bool(getattr(sim_tgt, 'annihilated', False))
                if would_be_down or would_be_annih:
                    raise ActionError('Self Preservation (RM 11.2): el objetivo no puede hacer una acción que le deje DOWN o ANNIHILATED inmediatamente.')
        except ActionError:
            raise
        except Exception:
            # Si la simulación falla por algo interno, no bloqueamos (evita falsos positivos).
            pass

    def apply(self, state: GameState) -> str:
        cp = state.current_player()
        cp.turn_bribe_attempted = True

        tgt = self.target_character
        owner = state.pc_owner_pid(tgt)

        if owner is not None and owner != cp.pid and self.consent is False:
            proposed_desc = repr(self.subaction)
            return f"💰 Bribe RECHAZADO por {owner} ({tgt}) | {proposed_desc} | Bribe no gastado"

        # Ejecutar la subacción SOBRE el estado real, pero en un contexto forzado:
        # - el actor es el target
        # - 1 AP disponible (pero suprimimos el gasto para que sea realmente gratis para el jugador)
        # - free pick/drop ya gastado

        desc = ""
        orig_active = state.active_character_id
        orig_ap_total = getattr(state, "action_points_total", 0)
        orig_ap_used = getattr(state, "action_points_used", 0)
        orig_free = getattr(state, "free_pickdrop_used", False)
        orig_suppress = getattr(state, "_suppress_action_point_spend", False)

        try:
            state.active_character_id = tgt
            state.free_pickdrop_used = True
            state.action_points_total = 1
            state.action_points_used = 0
            state._suppress_action_point_spend = True

            if isinstance(self.subaction, PickUp):
                self.subaction.force_cost_action = True
            if isinstance(self.subaction, Drop):
                self.subaction.force_cost_action = True

            desc = self.subaction.apply(state)
        finally:
            state.active_character_id = orig_active
            state.free_pickdrop_used = orig_free
            state.action_points_total = orig_ap_total
            state.action_points_used = orig_ap_used
            state._suppress_action_point_spend = orig_suppress

        cp.bribes -= 1
        state.characters[tgt].bribe_tokens.append(cp.pid)

        return f"💰 Bribe usado con {tgt} | {desc} | bribes_restantes={cp.bribes}"


# Aliases por compatibilidad con UI antiguos
Renegotiate = RenegotiateTakeBack
Bribe = UseBribe
Kompromat = UseKompromat