from __future__ import annotations

import abilities as AB

from dataclasses import dataclass, field
from typing import Dict, List, Optional, Set, Tuple, Callable, Iterable
import copy
from collections import deque

PlayerId = str
CharacterId = str
MonsterId = str
SectionId = str
ItemId = str
DataType = str
ItemKind = str
HazardKind = str  # e.g. "FIRE", "ASPHYX"
Ability = str  # e.g. "TUNNEL RAT", "OFFICER", etc.

# Pseudo-sección para componentes fuera del juego (ANIHILATED).
OUT_OF_GAME_SECTION: SectionId = "OUT_OF_GAME"

# Sección especial (RM 5.1.7): Outer Space.
# - No es "On Board".
# - Siempre tiene ASPHYX (RM 6.4) y no puede ser removido.
# - No puede ser dañada (RM 5.1.7.2).
OUTER_SPACE_SECTION: SectionId = "OUTER_SPACE"

# Sección especial homebrew: "Tripa" del Tentacled (Project X).
# - Solo existe si el Monster TENTACLED está en la partida (vía map_modules).
# - No está conectada a nada del mapa.
# - Todo lo que esté dentro no puede interactuar con nada (no acciones, no colocation).
TENTACULOUS_GUT_SECTION: SectionId = "TENTACULOUS_GUT"

# Sección que contiene Antimatter al inicio (RM 7.3 / 13.5).
MAGNETIC_CONTAINMENT_SECTION: SectionId = "MAGNETIC_CONTAINMENT"


def _norm(s: str) -> str:
    import re
    return re.sub(r"[^A-Z0-9]", "", str(s).upper())


@dataclass
class Monster:
    """Project X Monster pawn (no es un Character en reglas).

    Diseñado para que comparta *ubicación / movimiento* con Characters (section),
    pero sin colarse en reglas de Characters (identidades, inventario, data, influence, scoring...).
    """

    mid: MonsterId
    name: str
    kind: str = "MONSTER"  # e.g. "CARNIVOROUS"
    section: SectionId = "A"
    status: str = "LIVE"  # "LIVE" | "DOWN" (si aplica en el futuro)
    abilities: Set[Ability] = field(default_factory=set)

    def is_live(self) -> bool:
        return self.status == "LIVE"

    def is_down(self) -> bool:
        return self.status != "LIVE"

@dataclass
class Item:
    iid: ItemId
    name: str
    kind: ItemKind
    charges: int = 0  # p.ej. Nanogel(2)
    kompromat_target: Optional[CharacterId] = None  # si kind == "kompromat"
    armed: bool = False  # p.ej. Antimatter (RM 7.3)

    # RM 8.4: Integral Items.
    # Si `integral_bound_to` está definido, este Item es "Integral" a ese Character:
    # no puede salir nunca de su posesión (no Drop/Throw/Give/Rob/PickUp-from-Down, etc.).
    integral_bound_to: Optional[CharacterId] = None

    def is_helmet(self) -> bool:
        # Acepta variantes de texto para permitir sufijos tipo "Helmet (Integral)".
        return _norm(self.name).startswith("HELMET")

    def is_integral(self) -> bool:
        return bool(getattr(self, 'integral_bound_to', None))

    def is_nanogel(self) -> bool:
        # "Nanogel", "Nanogel(2)", etc.
        return _norm(self.name).startswith("NANOGEL")

    def is_bomb(self) -> bool:
        # Homebrew item for the prototype.
        return _norm(self.kind) == "BOMB" or _norm(self.name) == "BOMB"


@dataclass
class ItemGrant:
    """Plantilla de Item para generar al resolverse un Reveal Power.

    En Stationfall, algunas Reveal Powers proporcionan un Item a un Character.
    Para el prototipo, lo modelamos como una plantilla que se convierte en un
    `Item` real con un nuevo ItemId cuando el jugador hace Reveal.
    """

    name: str
    kind: ItemKind = "item"
    charges: int = 0
    kompromat_target: Optional[CharacterId] = None
    armed: bool = False

@dataclass
class PodState:
    """Estado de un Pod (RM 5.5).

    Implementación del prototipo:
    - Un Pod se modela como una Section (SectionId) en el grafo.
    - En ON_BOARD está conectado bidireccionalmente a UNA única sección.
    - Al LAUNCH:
        * si el Pod está Damaged -> pasa a ANNIHILATED y todo dentro se ANNIHILATED.
        * si no -> pasa a MESO y todo dentro queda ESCAPED.
    """

    sid: SectionId
    attached_to: Optional[SectionId] = None
    location: str = 'ON_BOARD'  # ON_BOARD / MESO / ANNIHILATED
    occupancy_limit: Optional[int] = None

    # En Stationfall la mayoría de Pods requieren que Abandon Ship esté disparado
    # antes de poder lanzarse (RM 7.1.1 / 13.6 / 13.7 / 13.8). En este prototipo
    # lo tratamos como el requisito estándar.
    requires_abandon_ship: bool = True

    launch_requirement_met: bool = True
@dataclass
class TimeMarker:
    """Time Marker token (Reference Manual §15.7).

    En este prototipo, los Time Markers se usan para programar eventos que
    se resuelven durante la fase RESOLVE del jugador.

    Regla base (RM 15.7.1): al final de tu turno, retira cualquier Time Marker
    tuyo colocado durante un Minute anterior y Resuelve el evento. Si hay
    varios, eliges el orden.

    Nota: más adelante también habrá markers "en el Minute track" (RM 15.7.2).
    """

    mid: int
    owner: PlayerId
    kind: str  # e.g. "TIMED_LAUNCH"
    location: str  # e.g. "POD", "MINUTE_TRACK"
    target: str  # e.g. POD section id
    placed_minute: int
    due_minute: Optional[int] = None  # si location==MINUTE_TRACK (RM 15.7.2)



@dataclass
class Character:
    cid: CharacterId
    name: str
    ctype: str  # "Human", "Robot", etc.
    section: SectionId

    # Estado físico (manual: Live/Down). Escape/Annihilated son flags separados.
    status: str = "LIVE"  # "LIVE" / "DOWN"
    escaped: bool = False
    annihilated: bool = False

    exhausted: bool = False

    # Límite estándar de objetos por Character (manual): 3 salvo excepciones.
    item_limit: int = 3
    items: List[ItemId] = field(default_factory=list)

    # Contamination token (RM 8.5.1): no es un Item, pero ocupa 1 item slot.
    contaminated: bool = False

    # Abilities / \"powers\" (manual 4.4)
    abilities: set[Ability] = field(default_factory=set)

    # Abilities que se GANAN al hacer Reveal como PC (RM 4.4.4). Son habilidades normales; aquí solo se listan para que se añadan a `abilities` cuando se revela.
    pc_reveal_abilities: set[Ability] = field(default_factory=set)

    # Reveal Powers que proporcionan Items (RM 4.5.3.1): al hacer Reveal como PC,
    # se generan estos Items y se añaden a la posesión del Character.
    pc_reveal_item_grants: List[ItemGrant] = field(default_factory=list)

    # Reveal Powers (RM 4.5): efectos de un solo uso que se disparan al hacer Reveal como PC.
    # Se resuelven inmediatamente tras el Reveal (y NO se activan durante Stationfall).
    # Ejemplo: Counselor — RECORDED_CONFESSIONAL.
    pc_reveal_powers: set[str] = field(default_factory=set)

    # Para UI/consistencia: recordamos la resolución de cada Reveal Power.
    # Claves: nombre del power (p.ej. 'RECORDED_CONFESSIONAL'). Valores:
    #   - 'ACTIVATED' (se ejecutó)
    #   - 'SKIPPED'   (se eligió omitir o no se pudo ejecutar)
    # Esto permite mostrar el Reveal Power incluso después de resolverse.
    pc_reveal_power_resolution: Dict[str, str] = field(default_factory=dict)

    # Stationfall PC powers: efectos que se disparan DURANTE Stationfall (RM 16),
    # no al hacer Reveal. Ejemplo: Daredevil — POINT_BREAK.
    pc_stationfall_powers: set[str] = field(default_factory=set)

    # --- Identity / Stationfall scoring (Character Dossier: "Agenda") ---
    # Guardamos las condiciones como texto (aún no las evaluamos en el motor).
    # Ejemplo (Astrochimp): 3 pts si Escapes; +2 pts si tiene Briefcase, etc.
    agenda_points: List[Tuple[int, str]] = field(default_factory=list)

    # Límite de Influence impreso en la carta (usaremos en Stationfall).
    influence_limit: int = 5
    influence_limit: int = 5
    # Data “en la carta” (para PC o para prototipos)
    data: Dict[DataType, int] = field(default_factory=dict)

    # Reveal benefits (pc_reveal_abilities) are active only if the PC was revealed during normal play (not first revealed in Stationfall).
    pc_reveal_active: bool = False

    # Contadores especiales para agendas / efectos del Dossier (p.ej. Medical marker).
    # Claves recomendadas: strings en MAYÚSCULAS sin espacios.
    counters: Dict[str, int] = field(default_factory=dict)

    # Si este Character es un PC revelado, quién lo posee
    pc_owner: Optional[PlayerId] = None
    # Bribes colocados en la carta (info pública)
    bribe_tokens: List[PlayerId] = field(default_factory=list)
    # Marcas de Kompromat usados sobre esta carta (solo para UI)
    kompromat_marks: int = 0


    # Drag (12.1.2): por turno de jugador, cada Character puede arrastrar 1 vez y ser arrastrado 1 vez
    has_dragged_this_turn: bool = False
    dragged_this_turn: bool = False
    def effective_abilities(self) -> set[Ability]:
        """Return the abilities currently active on this Character.

        - `abilities` are always active.
        - `pc_reveal_abilities` become active only once this Character is revealed as a player's PC.
        """
        ab = set(getattr(self, "abilities", set()) or set())
        if getattr(self, "pc_owner", None) and bool(getattr(self, "pc_reveal_active", False)):
            ab |= set(getattr(self, "pc_reveal_abilities", set()) or set())
        return ab

    def has_ability(self, name: str) -> bool:
        want = _norm(name)
        return any(_norm(a) == want for a in self.effective_abilities())

    def is_live(self) -> bool:
        # OJO: un Character ESCAPED puede seguir "LIVE"; se bloquea por reglas aparte.
        return (not self.annihilated) and (self.status == "LIVE")

    def is_down(self) -> bool:
        return (not self.annihilated) and (self.status == "DOWN")

    def is_escaped(self) -> bool:
        return bool(self.escaped) and (not self.annihilated)

    def is_annihilated(self) -> bool:
        return bool(self.annihilated)

    def inventory_count(self) -> int:
        return len(self.items)


@dataclass(frozen=True)
class IdentityCard:
    """Identity Card (RM 3.3 / 16.4.5).

    En el juego físico, cada Identity Card tiene impreso:
      - Bonus Points type: Friend o Grudge.
      - Número de puntos (iconos).

    En este prototipo, el contenido "estático" de estas cartas vive en
    `GameState.identity_cards` para que el motor pueda puntuar Bonus Points
    sin depender de valores duplicados en PlayerState.
    """

    cid: CharacterId
    bonus_kind: str  # 'FRIEND' | 'GRUDGE'
    bonus_icons: int


@dataclass
class PlayerState:
    pid: PlayerId
    kind: str  # "HUMANO" / "BOT"
    # Nombre visible (público). No se usa como ID interno.
    name: str = ""
    supply_cubes: int = 8
    betrayal_cubes: int = 0

    # Setup: cada jugador tiene 3 Time Markers (RM setup / §15.7).
    time_markers_total: int = 3

    # Info pública por jugador
    bribes: int = 0
    legal: str = "Innocent"  # Innocent / Suspect / Guilty
    revealed_character: Optional[CharacterId] = None  # PC revelado (si aplica)
    revealed_prior_to_stationfall: bool = False  # True si se reveló durante el juego normal (no en Stationfall)
    secret_identity: Optional[CharacterId] = None  # tu PC secreto (hasta Reveal)

    # Bonus Character (RM 3.4 / 16.4.5): puntúa Bonus Points al final.
    # NOTA: En el juego real, el tipo (Friend/Grudge) y los iconos vienen impresos
    # en tu Identity Card; aquí lo modelamos directamente en el PlayerState.
    bonus_character: Optional[CharacterId] = None
    bonus_kind: Optional[str] = None  # 'FRIEND' | 'GRUDGE'
    bonus_icons: int = 0
    bonus_points_disabled: bool = False  # p.ej. Schrödinger Reveal (RM 3.5.1)

    # Por defecto la BC es secreta (igual que la PC). Algunas Reveal Powers
    # pueden hacerla pública (p.ej. Stranger: HOMEWORK si decides usarla).
    bonus_character_public: bool = False

    # Lo que el jugador tiene en mano (secreto)
    # - identity_hand: 2 Identity Cards (PC/BC) que todavía no han sido elegidas.
    # - kompromat_hand: Kompromat Tokens que el jugador posee.
    identity_hand: List[CharacterId] = field(default_factory=list)
    kompromat_hand: List[ItemId] = field(default_factory=list)

    # Disco (persistente) = último character que activaste
    activation_disc: Optional[CharacterId] = None

    # Flags del turno
    turn_influence_target: Optional[CharacterId] = None
    turn_renegotiated: bool = False
    turn_bribe_attempted: bool = False
    turn_kompromat_attempted: bool = False

    def display_name(self) -> str:
        """Nombre a usar en la UI."""
        n = str(getattr(self, 'name', '')).strip()
        return n if n else str(getattr(self, 'pid', '')).strip()


@dataclass
class GameState:
    minute: int
    players: List[PlayerState]
    characters: Dict[CharacterId, Character]
    graph: Dict[SectionId, List[SectionId]]
    items: Dict[ItemId, Item]
    # Identity Cards (cid -> metadata de Bonus Points).
    identity_cards: Dict[CharacterId, IdentityCard] = field(default_factory=dict)
    # Kompromat usados sobre NPC (descartados). Se pueden recuperar con TRADECRAFT (Exile).
    used_npc_kompromat: Dict[ItemId, Item] = field(default_factory=dict)
    # Project X unreleased Monsters (kept off-map until released)
    project_x_pending_monsters: Dict[MonsterId, Monster] = field(default_factory=dict)
    project_x_released: bool = False  # True si Project X se ha liberado al menos una vez
    monsters: Dict[MonsterId, Monster] = field(default_factory=dict)
    pods: Dict[SectionId, PodState] = field(default_factory=dict)
    # Vent connections (manual 5.4). Only usable by characters with specific Abilities.
    vents: Dict[SectionId, List[SectionId]] = field(default_factory=dict)

    # Airlocks (RM 13.12.3 / índice 13.13): conexiones especiales con Outer Space.
    # Guardamos direcciones permitidas por flechas del mapa:
    #   {'to_outer': True/False, 'from_outer': True/False}
    # No se usan como corredores normales (no aparecen en graph).
    airlocks: Dict[SectionId, Dict[str, bool]] = field(default_factory=dict)

    # Time Markers (RM 15.7): eventos diferidos.
    time_markers: List[TimeMarker] = field(default_factory=list)
    next_time_marker_id: int = 1

    # Locked corridors (Reference Manual: Locks token on a corridor; bidirectional only)
    # Stored as undirected edges: (min(secA,secB), max(secA,secB))
    locks: Set[Tuple[SectionId, SectionId]] = field(default_factory=set)
    section_items: Dict[SectionId, List[ItemId]] = field(default_factory=dict)

    # Influence “en cartas”: pid -> (cid -> cubes)
    influence: Dict[PlayerId, Dict[CharacterId, int]] = field(default_factory=dict)

    # Hazards (Reference Manual §6)
    hazards: Dict[SectionId, set] = field(default_factory=dict)  # sec -> {HazardKind}

    # Contamination (RM 8.5.1 / 13.4): NO es un Hazard.
    # - Si un Character entra en una sección contaminada, gana 1 token (máx 1).
    # - El token ocupa 1 Item Slot.
    contamination_sections: Set[SectionId] = field(default_factory=set)

    # Gravity (prototipo): por defecto las secciones tienen gravedad.
    # Guardamos aquí únicamente las secciones SIN gravedad.
    # IMPORTANTE: los Pods siempre se consideran sin gravedad.
    zero_g_sections: Set[SectionId] = field(default_factory=set)

    # Cuando una regla obliga a "Drop 1 Item" sin coste y requiere elección del jugador activo,
    # encolamos la decisión aquí para que el UI la resuelva con input().
    # Cada entrada: {"cid": <CharacterId>, "reason": <str>}
    pending_free_drop_queue: List[dict] = field(default_factory=list)

    # Reveal Powers que requieren elección inmediata del jugador que se revela.
    # El UI los resuelve justo después de hacer Reveal.
    # Cada entrada: {"power": <str>, "revealing_pid": <pid>, "pcid": <cid>, ...}
    pending_reveal_power_queue: List[dict] = field(default_factory=list)

    # Powers que se disparan al inicio de una Activation (ej. Station Chief — FORCEFUL_PRESENCE).
    # El UI puede preguntar justo tras `activate`.
    # Cada entrada: {"power": <str>, "pid": <pid>, "source": <cid>, ...}
    pending_activation_power_queue: List[dict] = field(default_factory=list)

    # Station Chief — FORCEFUL_PRESENCE: si se elige un NPC objetivo, la siguiente Basic Action
    # del turno se ejecuta con ese NPC como actor y es gratis (no consume Action Points).
    forceful_presence_actor: Optional[CharacterId] = None

    # Flag interno: suprime el gasto de Action Points durante una acción gratuita.
    _suppress_action_point_spend: bool = False

    # Flag interno para evitar re-entradas en wrappers de acciones gratuitas.
    _forceful_presence_in_progress: bool = False

    # Stranger — HOMEWORK (Reveal Power): si se elige, la próxima acción del turno
    # se ejecuta con tu Bonus Character como actor (sin necesidad de activarlo).
    homework_actor: Optional[CharacterId] = None
    homework_pid: Optional[PlayerId] = None
    _homework_in_progress: bool = False

    # Luz por sección. Por defecto todas las secciones están iluminadas;
    # aquí guardamos únicamente las que están a oscuras.
    unlit_sections: set[SectionId] = field(default_factory=set)

    # Secciones "Dark" permanentes según el setup inicial (RM 5.1.3).
    # Se usa para restaurar un estado estándar tras Blackout.
    # IMPORTANTE: una sección en este set nunca puede volverse "Lit".
    default_unlit_sections: set[SectionId] = field(default_factory=set)

    # Estados globales (Data/Jammers/Sabotage demo)
    damaged_sections: set = field(default_factory=set)
    jammers_on: bool = True  # Reference Manual: setup en ON
    cameras_on: bool = True  # Reference Manual: setup en ON

    # Power (§7.2): algunas secciones son "Power Sections" (icono Power Supply).
    # El marcador de Power tiene 3 estados: Normal Power / Backup Power / Blackout.
    power_sections: set[SectionId] = field(default_factory=set)
    power_status: str = "Normal Power"

    # Abandon Ship: estado global (lo usaremos luego para precondiciones como Bridge Launch).
    abandon_ship: bool = False

    # Antimatter (RM 7.3): modelamos armado + timer, sin consecuencias todavía.
    antimatter_detonated: bool = False
    antimatter_detonation_section: Optional[SectionId] = None
    antimatter_detonation_minute: Optional[int] = None
    antimatter_detonation_reason: Optional[str] = None

    # Stationfall (RM 16): por ahora, solo un flag cuando Antimatter detona On Board.
    stationfall_triggered: bool = False
    stationfall_reason: Optional[str] = None
    stationfall_minute: Optional[int] = None

    # Fin de partida (CLI): si Stationfall se dispara, se corta el loop.
    game_over: bool = False

    # Stationfall procedure (RM 16): una vez disparado, ejecutamos los pasos (Reveal, Deliver Data, Scoring).
    stationfall_processed: bool = False
    # True while running Stationfall (RM 16) in the UI. Used to suppress Reveal Powers.
    stationfall_mode: bool = False

    stationfall_scores: Dict[PlayerId, int] = field(default_factory=dict)
    stationfall_winners: List[PlayerId] = field(default_factory=list)

    # Deliver Data (RM 16.3): duplicados colocados en Offsites.
    offsites_data: Dict[str, Dict[DataType, int]] = field(default_factory=lambda: {"AUTHORITIES": {}, "NEWS": {}})
    # Orden de colocación de duplicados en Offsites (to support 'News ends with ...').
    # Cada vez que se TRANSMIT o DELIVER a un Offsite, se apila el DataType.
    # El último elemento es el 'top' / 'ends with'.
    offsites_stack: Dict[str, List[DataType]] = field(default_factory=lambda: {"AUTHORITIES": [], "NEWS": []})
    # Registro simple de entregas por jugador (para reglas como Guilty->Suspect al entregar Evidence a Authorities).
    stationfall_deliveries: Dict[PlayerId, Dict[str, Dict[DataType, int]]] = field(default_factory=dict)

    # Re-entry token (Minute 0): 2 fichas de Stationfall y 1 de "no pasa nada".
    # Se revela al entrar en Minute 0.
    # - "STATIONFALL": Stationfall inmediato al revelar.
    # - "SAFE": se juega el Minute 0 y Stationfall ocurre al final.
    reentry_token: str = "STATIONFALL"  # STATIONFALL | SAFE
    reentry_revealed: bool = False


    # Blackout (§7.2.2): snapshot de luz antes de forzar "todo Dark".
    blackout_saved_unlit_sections: Optional[set[SectionId]] = None

    # Turno
    # `turn_in_progress` es un flag de UI (no regla):
    # - True desde que el CLI llama a start_player_turn() hasta end_player_turn().
    # - Se usa para poder SAVE/LOAD en mitad de un turno sin que al cargar se
    #   vuelva a resetear el turno.
    turn_in_progress: bool = False
    current_player_index: int = 0
    active_character_id: Optional[CharacterId] = None
    action_points_total: int = 0
    action_points_used: int = 0
    free_pickdrop_used: bool = False

    # Station Chief (Character Dossier): al inicio de su Activation, puede preparar
    # una Free Basic Action con un NPC elegido (FORCEFUL_PRESENCE).
    # El UI selecciona el NPC y lo guarda aquí; la siguiente Basic Action se ejecuta
    # con ese NPC como actor y no consume Action Points ni el slot de Free Pick/Drop.
    forceful_presence_actor: Optional[CharacterId] = None

    # Flags internos (no reglas): usados para ejecutar acciones realmente "gratis".
    _suppress_action_point_spend: bool = False
    _forceful_presence_in_progress: bool = False

    # Log del turno actual
    turn_log: List[str] = field(default_factory=list)

    def clone(self) -> GameState:
        return copy.deepcopy(self)

    # --- Stationfall helpers ---
    def trigger_stationfall(self, reason: str) -> str:
        if bool(getattr(self, 'stationfall_triggered', False)):
            return "STATIONFALL: ya estaba activado."
        self.stationfall_triggered = True
        self.stationfall_reason = str(reason)
        self.stationfall_minute = int(getattr(self, 'minute', 0))
        # RM 7.3.1: si Antimatter está ARMED y aún no detonó, detona en Stationfall.
        det_msg = ""
        try:
            aid = self.antimatter_id() if hasattr(self, 'antimatter_id') else None
            if aid:
                it = getattr(self, 'items', {}).get(str(aid).upper())
                if it and bool(getattr(it, 'armed', False)) and (not bool(getattr(self, 'antimatter_detonated', False))):
                    det_msg = self.detonate_antimatter_now(reason='STATIONFALL (armed antimatter unresolved)')
        except Exception:
            det_msg = ""

        self.game_over = True
        msg = f"💥 STATIONFALL! (reason={self.stationfall_reason}, minute={self.stationfall_minute})"
        try:
            self.turn_log.append(msg)
        except Exception:
            pass
        if det_msg:
            try:
                self.turn_log.append(det_msg)
            except Exception:
                pass
            msg = msg + " | " + det_msg

        return msg


    # --- Stationfall steps (RM 16) ---
    def stationfall_reveal_step(self) -> List[str]:
        """RM 16.2: Reveal de Secret Identities en Stationfall.

        En orden de jugador, cualquier jugador que NO haya revelado su Secret Identity debe revelarla.
        - Sigue RM 15.3.1 (limpieza de cubos en el Character revelado: los tuyos vuelven a tu supply; los de otros van a su Betrayal).
        - NO aplica RM 15.3.2 (Reveal Powers) durante Stationfall, salvo que alguna regla/poder indique lo contrario.
        """
        msgs: List[str] = []
        for p in self.players:
            if p.revealed_character is not None:
                continue
            if not p.secret_identity:
                continue

            cid = str(p.secret_identity).upper()

            # Marca PC revelado (sin poderes)
            p.revealed_character = cid
            ch = self.characters.get(cid)
            if ch:
                ch.pc_owner = p.pid

            # RM 15.3.1: limpieza de Influence cubos en el PC revelado
            moved_to_supply = 0
            moved_to_betrayal: Dict[PlayerId, int] = {}
            for q in self.players:
                n = int(self.influence_of(q.pid, cid))
                if n <= 0:
                    continue
                self.set_influence_of(q.pid, cid, 0)
                if q.pid == p.pid:
                    p.supply_cubes += n
                    moved_to_supply += n
                else:
                    q.betrayal_cubes += n
                    moved_to_betrayal[q.pid] = moved_to_betrayal.get(q.pid, 0) + n

            parts = [f"REVEAL (SF): {p.pid} revela su PC = {cid}" + (f" ({ch.name})" if ch else "")]
            if moved_to_supply:
                parts.append(f"+{moved_to_supply} a supply")
            if moved_to_betrayal:
                extras = ", ".join([f"{pid}=+{n}" for pid, n in moved_to_betrayal.items()])
                parts.append(f"others -> Betrayal: {extras}")
            msgs.append(" | ".join(parts))

        return msgs

    def stationfall_counts_as_escaped(self, cid: CharacterId) -> bool:
        """RM 16.4.1–16.4.2."""
        ch = self.characters[cid]
        if bool(getattr(ch, 'annihilated', False)):
            return False
        if bool(getattr(ch, 'escaped', False)):
            return True
        # Characters in Mesosphere count as Escaped (RM 16.4.1).
        sec = str(getattr(ch, 'section', '')).upper()
        if sec == 'MESO':
            return True
        pod = getattr(self, 'pods', {}).get(sec)
        if pod and str(getattr(pod, 'location', 'ON_BOARD')).upper() == 'MESO':
            return True
        return False


    def stationfall_apply_pc_stationfall_powers(self) -> List[str]:
        """Aplica poderes de PC que se disparan DURANTE Stationfall (RM 16).

        Incluye dos tipos de efectos:
        (1) Efectos en Stationfall derivados de Reveal Powers que estaban activas ANTES de Stationfall.
            (RM 16.2: si te revelas en Stationfall, no obtienes beneficios de Reveal Powers.)
        (2) Powers explícitos de Stationfall (no provenientes de Reveal Powers) para casos que lo indiquen.

        Actualmente implementado:
        - Daredevil — POINT_BREAK (requiere haberse revelado antes de Stationfall)
        """
        msgs: List[str] = []

        for p in getattr(self, 'players', []) or []:
            pcid = getattr(p, 'revealed_character', None) or getattr(p, 'secret_identity', None)
            if not pcid:
                continue
            cid = str(pcid).upper()
            ch = getattr(self, 'characters', {}).get(cid)
            if not ch:
                continue

            # Mantener consistencia: PC revelado debe tener owner.
            if not getattr(ch, 'pc_owner', None):
                try:
                    ch.pc_owner = p.pid
                except Exception:
                    pass

            # 1) Reveal Powers que estaban activas ANTES de Stationfall (RM 16.2)
            if bool(getattr(p, 'revealed_prior_to_stationfall', False)):
                for pow_name in (getattr(ch, 'pc_reveal_powers', None) or set()):
                    if _norm(pow_name) == _norm(AB.POINT_BREAK):
                        msg = self._sf_apply_point_break(p.pid, cid)
                        if msg:
                            msgs.append(msg)

            # 2) Powers explícitos de Stationfall (no provenientes de Reveal Powers)
            for pow_name in (getattr(ch, 'pc_stationfall_powers', None) or set()):
                # (Reservado para futuros personajes)
                pass

        return msgs

    def _sf_apply_point_break(self, pid: PlayerId, cid: CharacterId) -> str:
        """Daredevil — POINT_BREAK (Dossier).

        Condición (en Stationfall): si el PC está LIVE, posee HELMET, y está colocated con
        ROCKET WINGS, entonces ESCAPA.
        """
        ch = getattr(self, 'characters', {}).get(cid)
        if not ch:
            return ""

        # Solo si está LIVE en el momento de Stationfall.
        if bool(getattr(ch, 'annihilated', False)) or str(getattr(ch, 'status', '')).upper() != "LIVE":
            return ""

        # Si ya cuenta como Escaped, no hacemos nada.
        try:
            if self.stationfall_counts_as_escaped(cid):
                return ""
        except Exception:
            if bool(getattr(ch, 'escaped', False)):
                return ""

        # Debe poseer Helmet.
        has_helmet = False
        for iid in (getattr(ch, 'items', None) or []):
            it = getattr(self, 'items', {}).get(str(iid).upper())
            if it and getattr(it, 'is_helmet', None) and it.is_helmet():
                has_helmet = True
                break
            if it and "HELMET" in str(getattr(it, 'name', '')).upper():
                has_helmet = True
                break
        if not has_helmet:
            return ""

        # Encontrar Rocket Wings en el pool de items.
        rw_iid = None
        for iid, it in (getattr(self, 'items', {}) or {}).items():
            if _norm(getattr(it, 'name', '')) == _norm("ROCKET WINGS"):
                rw_iid = str(iid).upper()
                break
        if not rw_iid:
            return ""

        # Colocated con Rocket Wings = misma sección que el item (si está en una sección)
        # o misma sección que quien lo posea (si está en inventario de otro Character).
        loc_type, loc_id = self.item_location(rw_iid)
        if loc_type == "NONE":
            return ""

        pc_sec = str(getattr(ch, 'section', '')).upper()
        rw_sec = None
        if loc_type == "SEC":
            rw_sec = str(loc_id).upper()
        elif loc_type == "CHAR":
            holder = getattr(self, 'characters', {}).get(str(loc_id).upper())
            if holder:
                rw_sec = str(getattr(holder, 'section', '')).upper()

        if not rw_sec or rw_sec != pc_sec:
            return ""

        # Cumple todo: ESCAPA.
        try:
            ch.escaped = True
        except Exception:
            pass

        msg = f"POINT BREAK (SF): {pid} {cid} ({getattr(ch, 'name', '?')}) ESCAPA por Helmet + colocation con Rocket Wings."
        try:
            self.turn_log.append(msg)
        except Exception:
            pass
        return msg

    def stationfall_record_delivery(self, pid: PlayerId, offsite: str, data_type: DataType, count: int) -> str:
        """RM 16.3: colocar duplicados en Offsites."""
        off = str(offsite).upper()
        if off not in self.offsites_data:
            self.offsites_data[off] = {}
        dt = str(data_type).upper()
        n = int(count)
        if n <= 0:
            return ""
        self.offsites_data[off][dt] = int(self.offsites_data[off].get(dt, 0)) + n


        # Mantener orden (para agendas tipo 'NEWS ends with ...')
        try:
            self.offsites_stack.setdefault(off, [])
            for _ in range(n):
                self.offsites_stack[off].append(dt)
        except Exception:
            pass
        # registro por jugador
        self.stationfall_deliveries.setdefault(pid, {}).setdefault(off, {})
        self.stationfall_deliveries[pid][off][dt] = int(self.stationfall_deliveries[pid][off].get(dt, 0)) + n

        # RM 16.3.2: Si un jugador Guilty entrega Evidence a Authorities durante Stationfall,
        # baja su status a Suspect y pasa a ser elegible para ganar.
        p = self.player_by_id(pid)
        if str(getattr(p, 'legal', '')).lower() == 'guilty' and off == 'AUTHORITIES' and dt == 'EVIDENCE':
            p.legal = 'Suspect'
            return f"DELIVER: {pid} entrega EVIDENCE a AUTHORITIES -> (16.3.2) baja a Suspect y puede ganar."

        return f"DELIVER: {pid} entrega {n} {dt} a {off}."


    def record_transmission(self, pid: PlayerId, offsite: str, data_type: DataType) -> str:
        """RM 13.2 + RM 10.2.1: Transmit 1 Data type to an Offsite.

        - Coloca 1 duplicado del tipo de Data sobre el icono del Offsite (AUTHORITIES/NEWS).
        - No elimina la Data original del personaje.
        - Si se transmite EVIDENCE a AUTHORITIES, todos los *otros* jugadores Suspect pasan a Guilty (RM 10.2.1).
        - Importante: esto NO se aplica a Deliver Phase en Stationfall (RM 10.2.2), que usa stationfall_record_delivery().
        """
        off = str(offsite).upper().strip()
        if off not in ("AUTHORITIES", "NEWS"):
            raise ValueError("Offsite inválido")
        dt = str(data_type).upper().strip()

        # Registrar duplicado en el Offsite
        self.offsites_data.setdefault(off, {})
        self.offsites_data[off][dt] = int(self.offsites_data[off].get(dt, 0)) + 1


        # Mantener orden (para agendas tipo 'NEWS ends with ...')
        try:
            self.offsites_stack.setdefault(off, [])
            self.offsites_stack[off].append(dt)
        except Exception:
            pass
        msg_parts = [f"Acción: TRANSMIT {dt} -> {off}."]

        # RM 10.2.1
        if off == "AUTHORITIES" and dt == "EVIDENCE":
            guilty_now: List[PlayerId] = []
            for p in self.players:
                if p.pid == pid:
                    continue
                if str(getattr(p, "legal", "")).lower() == "suspect":
                    p.legal = "Guilty"
                    guilty_now.append(p.pid)
            if guilty_now:
                msg_parts.append("10.2.1: Suspects -> Guilty: " + ", ".join(guilty_now))
            else:
                msg_parts.append("10.2.1: (no había otros Suspects)")
        return " ".join(msg_parts)

    def stationfall_compute_scores(self) -> Dict[PlayerId, int]:
        """RM 16.4. Devuelve score total por jugador."""
        scores: Dict[PlayerId, int] = {}

        def pc_has_item_name(cid: str, needle: str) -> bool:
            nd = str(needle).upper()
            ch = self.characters.get(cid)
            if not ch:
                return False
            for iid in getattr(ch, 'items', []) or []:
                it = self.items.get(str(iid).upper())
                if it and nd in str(getattr(it, 'name', '')).upper():
                    return True
            return False

        def no_fire_on_board() -> bool:
            for sec, hz in (getattr(self, 'hazards', {}) or {}).items():
                # Outer Space siempre tiene ASPHYX; ignoramos aquí
                if 'FIRE' in {str(x).upper() for x in (hz or set())}:
                    # Si es un Pod en Mesosphere, no cuenta como "On Board"
                    pod = getattr(self, 'pods', {}).get(str(sec).upper())
                    if pod and str(getattr(pod, 'location', 'ON_BOARD')).upper() != 'ON_BOARD':
                        continue
                    return False
            return True


        def did_score_bonus_points(pid: PlayerId) -> bool:
            """True si este jugador puntúa Bonus Points en Stationfall (sin sumar puntos)."""
            me = self.player_by_id(pid)
            if not me:
                return False
            if bool(getattr(me, 'bonus_points_disabled', False)):
                return False
            bc_id = getattr(me, 'bonus_character', None)
            if not bc_id:
                return False
            bc_id_u = str(bc_id).upper()
            if bc_id_u not in (getattr(self, 'characters', {}) or {}):
                return False

            # Prefer Identity Card metadata (si existe) para no depender de duplicados en PlayerState.
            kind, icons = self.bonus_meta_for(bc_id_u)
            if not kind:
                kind = str(getattr(me, 'bonus_kind', '') or '').upper()
                icons = int(getattr(me, 'bonus_icons', 0) or 0)
            if icons <= 0:
                return False

            # Friend: BC escapes. Grudge: BC is DOWN (or annihilated) and does NOT escape.
            if kind == 'FRIEND':
                return self.stationfall_counts_as_escaped(bc_id_u)
            if kind == 'GRUDGE':
                bc = self.characters.get(bc_id_u)
                if not bc:
                    return False
                downish = (str(getattr(bc, 'status', '')).upper() == 'DOWN') or bool(getattr(bc, 'annihilated', False))
                return downish and (not self.stationfall_counts_as_escaped(bc_id_u))
            return False

        def is_antimatter_armed_at_stationfall() -> bool:
            """Devuelve True si el Antimatter está Armado en Stationfall.

            Nota: si detonó, lo tratamos como 'armado' a efectos de agendas que dicen
            'Antimatter NO está Armed'.
            """
            if bool(getattr(self, 'antimatter_detonated', False)):
                return True

            aid = None
            try:
                aid = self.antimatter_id() if hasattr(self, 'antimatter_id') else None
            except Exception:
                aid = None

            if aid:
                it = (getattr(self, 'items', {}) or {}).get(str(aid).upper())
                if it is not None:
                    return bool(getattr(it, 'armed', False))

            # Fallback: busca por nombre
            for _iid, _it in (getattr(self, 'items', {}) or {}).items():
                if str(getattr(_it, 'name', '')).strip().upper() == 'ANTIMATTER':
                    return bool(getattr(_it, 'armed', False))
            return False


        def eval_agenda_clause(pid: PlayerId, cid: str, desc: str) -> bool:
            """Evaluación mínima para el prototipo basada en texto.

            Nota: soporta checks de items (Briefcase/Artifact/Gun) para que agendas como
            "Shiny Things" del Astrochimp puntúen bien.

            Además, soporta condiciones globales del Counselor (Artifact Escapes, Kompromat,
            Betrayal Box).
            """
            up = str(desc).upper()
            ok = True


            # --- TROUBLESHOOTER: +2 si Antimatter NO está ARMED en Stationfall ---
            if ("ANTIMATTER" in up) and ("ARMED" in up) and ("DETON" not in up):
                neg = ("NO" in up) or ("NOT" in up) or ("NUNCA" in up) or ("NEVER" in up) or ("DOES NOT" in up)
                if neg:
                    return not is_antimatter_armed_at_stationfall()

            # --- TROUBLESHOOTER: +2 si no hay Secciones DAMAGED On Board en Stationfall ---
            if ("DAMAGED" in up) and (("SECCION" in up) or ("SECCIÓN" in up) or ("SECTION" in up)):
                neg = ("NO" in up) or ("NOT" in up) or ("NINGUN" in up) or ("NINGÚN" in up) or ("NINGUNA" in up) or ("NONE" in up)
                if neg:
                    onb = self.on_board_sections() if hasattr(self, 'on_board_sections') else set(getattr(self, 'graph', {}) or {})
                    dmg = {str(s).upper() for s in (getattr(self, 'damaged_sections', set()) or set())}
                    return len(dmg & {str(s).upper() for s in onb}) == 0

            # --- STRANGER: +1 si tu Secret Identity no se revela hasta Stationfall ---
            if (("SECRET IDENTITY" in up) or ("IDENTIDAD SECRETA" in up)) and ("REVEL" in up or "REVEAL" in up) and ("STATIONFALL" in up):
                me = self.player_by_id(pid)
                return not bool(getattr(me, 'revealed_prior_to_stationfall', False))

            # --- STRANGER: +1 si posees X-SECRET ---
            if ("X-SECRET" in up or "XSECRET" in up or "X SECRET" in up) and ("NEWS" not in up):
                # Evitar colisión con checks de Offsites (NEWS ends with X-SECRET).
                if ("POSE" in up) or ("HAVE" in up) or ("POSEES" in up) or ("TIENES" in up):
                    ch = self.characters.get(cid)
                    try:
                        pc_data = getattr(ch, 'data', {}) or {}
                        return int(pc_data.get('X-SECRET', 0) or 0) > 0
                    except Exception:
                        return False

            # --- STRANGER: +2 si puntúas Bonus Points ---
            if ("BONUS" in up) and ("POINT" in up) and ("NEWS" not in up):
                if ("PUNT" in up) or ("SCORE" in up):
                    return did_score_bonus_points(pid)

            # --- STRANGER: +2 si estás LIVE y COLOCATED con tu Bonus Character en Stationfall ---
            if ("BONUS" in up) and ("CHARACTER" in up) and ("COLOCAT" in up) and ("LIVE" in up):
                me = self.player_by_id(pid)
                if not me:
                    return False
                bc_id = getattr(me, 'bonus_character', None)
                if not bc_id:
                    return False
                bc_id_u = str(bc_id).upper()
                if bc_id_u not in (getattr(self, 'characters', {}) or {}):
                    return False
                pcch = self.characters.get(cid)
                bcch = self.characters.get(bc_id_u)
                if not pcch or not bcch:
                    return False
                pc_live = (str(getattr(pcch, 'status', '')).upper() == 'LIVE') and (not bool(getattr(pcch, 'annihilated', False)))
                bc_present = not bool(getattr(bcch, 'annihilated', False))
                if not (pc_live and bc_present):
                    return False
                return str(getattr(pcch, 'section', '')).upper() == str(getattr(bcch, 'section', '')).upper()

            # --- CYBORG: +2 si ningún PC Human escapa ---
            # Ojo: esto es condición global (no depende de que *tu* PC escape).
            if ("NO" in up or "NINGUN" in up or "NINGÚN" in up) and ("PC" in up) and ("HUMAN" in up) and ("ESCAP" in up or "ESCAPA" in up):
                for _p in self.players:
                    pcid = getattr(_p, 'revealed_character', None) or getattr(_p, 'secret_identity', None)
                    if not pcid:
                        continue
                    pcch = self.characters.get(str(pcid).upper())
                    if not pcch:
                        continue
                    if 'HUMAN' not in str(getattr(pcch, 'ctype', '')).upper():
                        continue
                    if self.stationfall_counts_as_escaped(str(pcid).upper()):
                        return False
                return True

            # --- CYBORG: +2 si no escapa ninguna Contamination ---
            # En este prototipo, Contamination está modelada como flag `contaminated` en Characters.
            if ("NO" in up or "NINGUN" in up or "NINGÚN" in up) and ("CONTAM" in up) and ("ESCAP" in up or "ESCAPA" in up):
                for _cid, _ch in (getattr(self, 'characters', {}) or {}).items():
                    if not bool(getattr(_ch, 'contaminated', False)):
                        continue
                    if self.stationfall_counts_as_escaped(str(_cid).upper()):
                        return False
                return True

            # --- CYBORG: +1 por cada personaje con OFFICER que esté DOWN ---
            # Nota: el cálculo multiplicativo se aplica en el bucle de scoring; aquí solo
            # devolvemos True/False para que (si alguien lo usa como +clause) funcione.
            if (AB.OFFICER in up) and ("DOWN" in up) and ("POR CADA" in up or "PER" in up or "EACH" in up):
                cnt = 0
                for _cid, _ch in (getattr(self, 'characters', {}) or {}).items():
                    try:
                        ab = _ch.effective_abilities() if hasattr(_ch, 'effective_abilities') else set(getattr(_ch, 'abilities', set()) or set())
                    except Exception:
                        ab = set(getattr(_ch, 'abilities', set()) or set())
                    ab = {str(a).upper() for a in (ab or set())}
                    if 'OFFICER' not in ab:
                        continue
                    if str(getattr(_ch, 'status', '')).upper() == 'DOWN' and (not bool(getattr(_ch, 'escaped', False))):
                        cnt += 1
                return cnt > 0

            # --- ENGINEER: +3 si Antimatter detona On Board antes de Stationfall ---
            if ("ANTIMATTER" in up) and ("DETON" in up or "DETONA" in up or "EXPLO" in up):
                if not bool(getattr(self, 'antimatter_detonated', False)):
                    return False

                det_sec = str(getattr(self, 'antimatter_detonation_section', '') or '').upper()
                # Debe ser "On Board" (no MESO, no Outer Space, no fuera del juego, ni Pod en MESO).
                if det_sec in ('', str(OUT_OF_GAME_SECTION).upper(), str(OUTER_SPACE_SECTION).upper(), 'MESO'):
                    return False
                pod = getattr(self, 'pods', {}).get(det_sec)
                if pod and str(getattr(pod, 'location', 'ON_BOARD')).upper() != 'ON_BOARD':
                    return False

                # "Antes de Stationfall": o bien es la causa (reason=ANTIMATTER),
                # o bien detonó en un minuto anterior.
                sf_reason = str(getattr(self, 'stationfall_reason', '') or '').upper()
                if sf_reason == 'ANTIMATTER':
                    return True

                det_min = getattr(self, 'antimatter_detonation_minute', None)
                sf_min = getattr(self, 'stationfall_minute', None)
                if det_min is None or sf_min is None:
                    return True
                try:
                    return int(det_min) < int(sf_min)
                except Exception:
                    return False

            # --- ENGINEER: +1 si terminas INNOCENT ---
            if ("INNOCENT" in up) and ("END" in up or "FINAL" in up or "TERMIN" in up or "ACAB" in up):
                me = self.player_by_id(pid)
                return str(getattr(me, 'legal', '') or '').lower() == 'innocent'

            # --- ENGINEER: +2 si Artifact NO escapa ---
            # Importante: esto es distinto de "escapa CON Artifact" (posesión).
            if ("ARTIFACT" in up) and ("ESCAP" in up or "ESCAPA" in up) and (("DOES NOT" in up) or ("NOT" in up) or ("NO" in up) or ("NO " in up)) and (" CON " not in up) and (" WITH " not in up):
                target_iid = None
                for _iid, _it in (getattr(self, 'items', {}) or {}).items():
                    if str(getattr(_it, 'name', '')).strip().upper() == "ARTIFACT":
                        target_iid = str(_iid).upper()
                        break
                # Si el Artifact no existe en el prototipo, tratamos como "no escapa".
                if not target_iid:
                    return True

                loc_type, loc_id = self.item_location(target_iid)
                escaped = False
                if loc_type == "CHAR":
                    escaped = self.stationfall_counts_as_escaped(str(loc_id).upper())
                elif loc_type == "SEC":
                    sec = str(loc_id).upper()
                    if sec == 'MESO':
                        escaped = True
                    else:
                        pod = getattr(self, 'pods', {}).get(sec)
                        if pod and str(getattr(pod, 'location', 'ON_BOARD')).upper() == 'MESO':
                            escaped = True
                return not escaped

            # --- COUNSELOR: 4 pts if the Artifact Escapes ---
            if ("ARTIFACT" in up) and ("ESCAP" in up or "ESCAPA" in up) and (" CON " not in up) and (" WITH " not in up):
                target_iid = None
                for _iid, _it in (getattr(self, 'items', {}) or {}).items():
                    if str(getattr(_it, 'name', '')).strip().upper() == "ARTIFACT":
                        target_iid = str(_iid).upper()
                        break
                if not target_iid:
                    return False

                loc_type, loc_id = self.item_location(target_iid)
                if loc_type == "CHAR":
                    return self.stationfall_counts_as_escaped(str(loc_id).upper())
                if loc_type == "SEC":
                    sec = str(loc_id).upper()
                    if sec == 'MESO':
                        return True
                    pod = getattr(self, 'pods', {}).get(sec)
                    if pod and str(getattr(pod, 'location', 'ON_BOARD')).upper() == 'MESO':
                        return True
                    return False
                return False

            # --- COUNSELOR: 2 pts if you have more Kompromat than any other player ---
            if ("MORE KOMPROMAT" in up) or ("MÁS KOMPROMAT" in up) or ("MAS KOMPROMAT" in up):
                me = self.player_by_id(pid)
                my_k = len(getattr(me, 'kompromat_hand', []) or [])
                others = [len(getattr(p, 'kompromat_hand', []) or []) for p in self.players if p.pid != pid]
                mx = max(others) if others else 0
                return my_k > mx

            # --- COUNSELOR: 1 pt if you have the least Cubes in Betrayal Box ---
            if ("BETRAYAL" in up) and ("LEAST" in up or "MENOS" in up or "MINIMO" in up or "MÍNIMO" in up):
                me = self.player_by_id(pid)
                my_b = int(getattr(me, 'betrayal_cubes', 0) or 0)
                all_b = [int(getattr(p, 'betrayal_cubes', 0) or 0) for p in self.players]
                mn = min(all_b) if all_b else my_b
                return my_b == mn

            # --- DAREDEVIL: +2 si es el ÚNICO HUMAN que ESCAPA ---
            if (("ONLY HUMAN" in up) or ("UNICO HUMAN" in up) or ("ÚNICO HUMAN" in up)) and ("ESCAP" in up or "ESCAPA" in up):
                if not self.stationfall_counts_as_escaped(cid):
                    return False
                me_ch = self.characters.get(cid)
                if me_ch and 'HUMAN' not in str(getattr(me_ch, 'ctype', '')).upper():
                    return False
                for _ocid, _och in (getattr(self, 'characters', {}) or {}).items():
                    oc = str(_ocid).upper()
                    if oc == cid:
                        continue
                    if 'HUMAN' not in str(getattr(_och, 'ctype', '')).upper():
                        continue
                    if self.stationfall_counts_as_escaped(oc):
                        return False
                return True

            # --- DAREDEVIL: +2 si posee ARTIFACT OR está CONTAMINATED ---
            if ("ARTIFACT" in up) and ("CONTAM" in up) and ((" OR " in up) or (" O " in up) or ("OR" in up)):
                ch = self.characters.get(cid)
                has_art = pc_has_item_name(cid, "ARTIFACT")
                is_cont = bool(getattr(ch, 'contaminated', False)) if ch else False
                return has_art or is_cont            # --- Project X: liberado / no liberado ---
            if ("PROJECT X" in up) and (("RELEASE" in up) or ("LIBER" in up)):
                released = bool(getattr(self, 'project_x_released', False))
                # Soportar 'nunca fue liberado' / 'does not release'
                neg = ("NO" in up) or ("NOT" in up) or ("NUNCA" in up) or ("NEVER" in up) or ("DOES NOT" in up)
                return (not released) if neg else released


            # --- EXILE: +3 si Exile tiene EVIDENCE y NEWS no tiene EVIDENCE ---
            if ("EVIDENCE" in up) and ("NEWS" in up) and (("DOES NOT" in up) or ("NO" in up) or ("NOT" in up)):
                ch = self.characters.get(cid)
                has_ev = False
                if ch:
                    try:
                        has_ev = int((getattr(ch, 'data', {}) or {}).get('EVIDENCE', 0) or 0) > 0
                    except Exception:
                        has_ev = False
                news_ev = 0
                try:
                    news_ev = int((getattr(self, 'offsites_data', {}) or {}).get('NEWS', {}).get('EVIDENCE', 0) or 0)
                except Exception:
                    news_ev = 0
                return bool(has_ev) and (news_ev == 0)

            # --- STOWAWAY: 2 pts si NEWS termina con X-SECRET ---
            if ("NEWS" in up) and (("X-SECRET" in up) or ("XSECRET" in up) or ("X SECRET" in up)):
                # 'Ends with' se modela con offsites_stack (último duplicado colocado en NEWS).
                try:
                    st = (getattr(self, 'offsites_stack', {}) or {}).get('NEWS', [])
                    if st:
                        return str(st[-1]).upper() == 'X-SECRET'
                except Exception:
                    pass
                # Fallback (saves antiguos): si no hay orden guardado, tratamos como "presente".
                try:
                    n_x = int((getattr(self, 'offsites_data', {}) or {}).get('NEWS', {}).get('X-SECRET', 0) or 0)
                except Exception:
                    n_x = 0
                return n_x > 0

            # --- STOWAWAY: 2 pts si NEWS termina con EVIDENCE ---
            # (Ojo: distinto del check del Exile que exige que NEWS NO tenga Evidence.)
            if ("NEWS" in up) and ("EVIDENCE" in up) and not (("DOES NOT" in up) or ("NO" in up) or ("NOT" in up)):
                try:
                    st = (getattr(self, 'offsites_stack', {}) or {}).get('NEWS', [])
                    if st:
                        return str(st[-1]).upper() == 'EVIDENCE'
                except Exception:
                    pass
                # Fallback (saves antiguos): si no hay orden guardado, tratamos como "presente".
                try:
                    n_ev = int((getattr(self, 'offsites_data', {}) or {}).get('NEWS', {}).get('EVIDENCE', 0) or 0)
                except Exception:
                    n_ev = 0
                return n_ev > 0

            # --- STOWAWAY: +3 si escapa con EVIDENCE y ningún otro escapa con EVIDENCE ---
            if ("EVIDENCE" in up) and ("ESCAP" in up or "ESCAPA" in up) and (("NO OTHER" in up) or ("NINGUN OTRO" in up) or ("NINGÚN OTRO" in up) or ("NINGUNA OTRA" in up) or ("NINGÚNA OTRA" in up)):
                # Debe escapar
                if not self.stationfall_counts_as_escaped(cid):
                    return False
                ch = self.characters.get(cid)
                has_ev = False
                if ch:
                    try:
                        has_ev = int((getattr(ch, 'data', {}) or {}).get('EVIDENCE', 0) or 0) > 0
                    except Exception:
                        has_ev = False
                if not has_ev:
                    return False

                # Ningún otro Character escapado con Evidence
                for _ocid, _och in (getattr(self, 'characters', {}) or {}).items():
                    oc = str(_ocid).upper()
                    if oc == cid:
                        continue
                    if not self.stationfall_counts_as_escaped(oc):
                        continue
                    try:
                        o_ev = int((getattr(_och, 'data', {}) or {}).get('EVIDENCE', 0) or 0) > 0
                    except Exception:
                        o_ev = False
                    if o_ev:
                        return False
                return True

            # Escape
            if "ESCAP" in up or "ESCAPA" in up:
                ok = ok and self.stationfall_counts_as_escaped(cid)

            # Items
            if "HELMET" in up:
                ok = ok and pc_has_item_name(cid, "HELMET")
            if "BRIEFCASE" in up:
                ok = ok and pc_has_item_name(cid, "BRIEFCASE")
            if "ARTIFACT" in up:
                ok = ok and pc_has_item_name(cid, "ARTIFACT")
            if ("GUN" in up) or ("PISTOL" in up):
                ok = ok and (pc_has_item_name(cid, "GUN") or pc_has_item_name(cid, "PISTOL"))

            # Status
            if "CONTAM" in up:
                ch = self.characters.get(cid)
                ok = ok and bool(getattr(ch, 'contaminated', False)) if ch else False

            # "no hay FIRE..."
            if "FIRE" in up and ("NO" in up or "NOT" in up):
                ok = ok and no_fire_on_board()

            return ok
        for p in self.players:
            pid = p.pid
            cid = p.revealed_character or p.secret_identity
            if not cid or cid not in self.characters:
                scores[pid] = 0
                continue

            pc = self.characters[cid]
            total = 0

            # --- Primary points (Agenda) RM 16.4.4 ---

            # Todas las Agendas se resuelven por nombre de personaje, para que cada
            # puntuación viva en un único sitio y evitar mezclas de rutas.

            def _agenda_score_points_list(_pid: PlayerId, _cid: str, _pc: Character) -> int:
                """Scoring genérico de `agenda_points` con semántica base/+ y algunos casos multiplicativos.

                Nota: esto reproduce el comportamiento previo del prototipo.
                """
                _total = 0
                _last_base_met = True
                for _pts, _desc in getattr(_pc, 'agenda_points', []) or []:
                    d = str(_desc).lstrip()
                    is_plus = d.startswith('+')
                    up_desc = str(_desc).upper()

                    # --- CYBORG: "1 pt por cada OFFICER que esté DOWN" (multiplicativo) ---
                    if (AB.OFFICER in up_desc) and ("DOWN" in up_desc) and ("POR CADA" in up_desc or "PER" in up_desc or "EACH" in up_desc):
                        cnt = 0
                        for __cid, __ch in (getattr(self, 'characters', {}) or {}).items():
                            try:
                                ab = __ch.effective_abilities() if hasattr(__ch, 'effective_abilities') else set(getattr(__ch, 'abilities', set()) or set())
                            except Exception:
                                ab = set(getattr(__ch, 'abilities', set()) or set())
                            ab = {str(a).upper() for a in (ab or set())}
                            if 'OFFICER' not in ab:
                                continue
                            if str(getattr(__ch, 'status', '')).upper() == 'DOWN' and (not bool(getattr(__ch, 'escaped', False))):
                                cnt += 1
                        _total += int(_pts) * int(cnt)
                        _last_base_met = True
                        continue

                    # --- TROUBLESHOOTER: "1 pt por cada ROBOT LIVE" (multiplicativo) ---
                    if ("ROBOT" in up_desc) and ("LIVE" in up_desc) and ("POR CADA" in up_desc or "PER" in up_desc or "EACH" in up_desc):
                        cnt = 0
                        for __cid2, __ch2 in (getattr(self, 'characters', {}) or {}).items():
                            if bool(getattr(__ch2, 'annihilated', False)):
                                continue
                            if str(getattr(__ch2, 'status', '')).upper() != 'LIVE':
                                continue
                            if 'ROBOT' not in _norm(getattr(__ch2, 'ctype', '')):
                                continue
                            cnt += 1
                        _total += int(_pts) * int(cnt)
                        _last_base_met = True
                        continue

                    # --- EXILE: +2 por cada KOMPROMAT poseído de personajes que ESCAPAN (multiplicativo) ---
                    if ("KOMPROMAT" in up_desc) and ("ESCAP" in up_desc or "ESCAPED" in up_desc) and ("POR CADA" in up_desc or "PER" in up_desc or "EACH" in up_desc):
                        cnt = 0
                        me_p = self.player_by_id(_pid)
                        hand = getattr(me_p, 'kompromat_hand', []) or []
                        for kid in hand:
                            it = (getattr(self, 'items', {}) or {}).get(str(kid).upper())
                            if not it:
                                continue
                            if str(getattr(it, 'kind', '')).lower() != 'kompromat':
                                continue
                            tgt = getattr(it, 'kompromat_target', None)
                            if not tgt:
                                continue
                            if self.stationfall_counts_as_escaped(str(tgt).upper()):
                                cnt += 1
                        if is_plus:
                            if _last_base_met:
                                _total += int(_pts) * int(cnt)
                        else:
                            if cnt > 0:
                                _total += int(_pts) * int(cnt)
                                _last_base_met = True
                        continue

                    if not is_plus:
                        _last_base_met = eval_agenda_clause(_pid, _cid, _desc)
                        if _last_base_met:
                            _total += int(_pts)
                    else:
                        if _last_base_met and eval_agenda_clause(_pid, _cid, _desc):
                            _total += int(_pts)
                return _total

            def _agenda_score_security(_pid: PlayerId, _cid: str, _pc: Character) -> int:
                onb = self.on_board_sections() if hasattr(self, 'on_board_sections') else set(getattr(self, 'graph', {}) or {})

                def _is_down_on_board(_ch) -> bool:
                    if bool(getattr(_ch, 'escaped', False)) or bool(getattr(_ch, 'annihilated', False)):
                        return False
                    if str(getattr(_ch, 'status', '')).upper() != 'DOWN':
                        return False
                    return str(getattr(_ch, 'section', '')).upper() in onb

                def _is_revealed_pc_non_innocent(__cid: str) -> bool:
                    try:
                        if not self.is_pc(str(__cid).upper()):
                            return False
                        opid = self.pc_owner_pid(str(__cid).upper())
                        if not opid:
                            return False
                        pl = self.player_by_id(opid)
                        return str(getattr(pl, 'legal', 'Innocent') or '').lower() != 'innocent'
                    except Exception:
                        return False

                total_s = 0

                # (1) Fugitive / Monster / PC no-Innocent DOWN On Board
                cnt_targets = 0
                for __cid2, __ch2 in (getattr(self, 'characters', {}) or {}).items():
                    if not _is_down_on_board(__ch2):
                        continue
                    if __ch2.has_ability(AB.FUGITIVE) or _is_revealed_pc_non_innocent(str(__cid2).upper()):
                        cnt_targets += 1

                for __mid, __m in list((getattr(self, 'monsters', {}) or {}).items()):
                    if not __m:
                        continue
                    if str(getattr(__m, 'status', '')).upper() != 'DOWN':
                        continue
                    if str(getattr(__m, 'section', '')).upper() not in onb:
                        continue
                    cnt_targets += 1

                total_s += cnt_targets

                # (2) Humans DOWN con Gun o Bludgeon en inventario On Board
                def _has_gun_or_bludgeon(_ch) -> bool:
                    for __iid in list(getattr(_ch, 'items', []) or []):
                        it = getattr(self, 'items', {}).get(str(__iid).upper())
                        if not it:
                            continue
                        nm = str(getattr(it, 'name', '')).strip().upper()
                        if nm in ('GUN', 'PISTOL', 'BLUDGEON'):
                            return True
                    return False

                cnt_humans = 0
                for __cid2, __ch2 in (getattr(self, 'characters', {}) or {}).items():
                    if not _is_down_on_board(__ch2):
                        continue
                    if 'HUMAN' not in _norm(getattr(__ch2, 'ctype', '')):
                        continue
                    if _has_gun_or_bludgeon(__ch2):
                        cnt_humans += 1
                total_s += cnt_humans

                # (3) Briefcase / Artifact do not escape
                def _find_item_id_by_exact_name(nm: str):
                    want = str(nm).strip().upper()
                    for __iid, __it in (getattr(self, 'items', {}) or {}).items():
                        if str(getattr(__it, 'name', '')).strip().upper() == want:
                            return str(__iid).upper()
                    return None

                def _item_escapes(iid: str) -> bool:
                    if not iid:
                        return False
                    loc_type, loc_id = self.item_location(str(iid).upper())
                    if loc_type == 'CHAR':
                        return self.stationfall_counts_as_escaped(str(loc_id).upper())
                    if loc_type == 'SEC':
                        sec = str(loc_id).upper()
                        if sec == 'MESO':
                            return True
                        pod = getattr(self, 'pods', {}).get(sec)
                        if pod and str(getattr(pod, 'location', 'ON_BOARD')).upper() == 'MESO':
                            return True
                        return False
                    return False

                brief_iid = _find_item_id_by_exact_name('BRIEFCASE')
                art_iid = _find_item_id_by_exact_name('ARTIFACT')

                brief_no = (not _item_escapes(brief_iid))
                art_no = (not _item_escapes(art_iid))

                if brief_no:
                    total_s += 1
                if art_no:
                    total_s += 1
                if brief_no and art_no:
                    total_s += 1

                return total_s

            def _agenda_score_medical(_pid: PlayerId, _cid: str, _pc: Character) -> int:
                total_m = 0
                onb = self.on_board_sections() if hasattr(self, 'on_board_sections') else set(getattr(self, 'graph', {}) or {})

                # 2 pts si no hay Humans DOWN On Board
                any_human_down = False
                for __cid2, __ch2 in (getattr(self, 'characters', {}) or {}).items():
                    if bool(getattr(__ch2, 'escaped', False)) or bool(getattr(__ch2, 'annihilated', False)):
                        continue
                    if str(getattr(__ch2, 'status', '')).upper() != 'DOWN':
                        continue
                    if 'HUMAN' not in str(getattr(__ch2, 'ctype', '')).upper():
                        continue
                    if str(getattr(__ch2, 'section', '')).upper() not in onb:
                        continue
                    any_human_down = True
                    break
                if not any_human_down:
                    total_m += 2

                # Star tracker
                mk = self.get_character_counter(_cid, 'MEDICAL_MARKER', 0) if hasattr(self, 'get_character_counter') else 0
                try:
                    mk = int(mk)
                except Exception:
                    mk = 0
                if mk < 0:
                    mk = 0
                if mk > 11:
                    mk = 11
                stars = 0
                for t in (1, 2, 3, 4, 6, 8, 11):
                    if mk >= t:
                        stars += 1
                total_m += stars

                return total_m

            def _agenda_score_station_chief(_pid: PlayerId, _cid: str, _pc: Character) -> int:
                total_sc = 0
                onb = self.on_board_sections() if hasattr(self, 'on_board_sections') else set(getattr(self, 'graph', {}) or {})

                # (1) 1 pt por cada Human que escapa (excluyendo Station Chief)
                human_esc = 0
                for __cid2, __ch2 in (getattr(self, 'characters', {}) or {}).items():
                    oc = str(__cid2).upper()
                    if oc == str(_cid).upper():
                        continue
                    if not self.stationfall_counts_as_escaped(oc):
                        continue
                    if 'HUMAN' not in _norm(getattr(__ch2, 'ctype', '')):
                        continue
                    human_esc += 1
                total_sc += human_esc

                # (2) +1 adicional por cada NPC con OFFICER que escapa
                npc_officer_esc = 0
                for __cid2, __ch2 in (getattr(self, 'characters', {}) or {}).items():
                    oc = str(__cid2).upper()
                    if oc == str(_cid).upper():
                        continue
                    if self.is_pc(oc):
                        continue  # sólo NPCs
                    if not self.stationfall_counts_as_escaped(oc):
                        continue
                    try:
                        if __ch2.has_ability(AB.OFFICER):
                            npc_officer_esc += 1
                    except Exception:
                        ab = {str(a).upper() for a in (getattr(__ch2, 'abilities', set()) or set())}
                        if AB.OFFICER in ab:
                            npc_officer_esc += 1
                total_sc += npc_officer_esc

                # (3) 2 pts si Station Chief está On Board y LIVE en Stationfall
                pc_sec = str(getattr(_pc, 'section', '')).upper()
                pc_live = (str(getattr(_pc, 'status', '')).upper() == 'LIVE') and (not bool(getattr(_pc, 'annihilated', False)))
                if pc_live and (not self.stationfall_counts_as_escaped(str(_cid).upper())) and (pc_sec in onb):
                    total_sc += 2

                return total_sc

            # Dispatch por nombre (normalizado)
            pc_name = _norm(getattr(pc, 'name', ''))
            # Registramos explícitamente todos los PCs del prototipo para que TODO pase por esta tabla.
            AGENDA_SCORERS = {
                # Scorers dedicados
                'SECURITY': _agenda_score_security,
                'MEDICAL': _agenda_score_medical,
                'STATIONCHIEF': _agenda_score_station_chief,

                # Scoring por agenda_points (ruta común)
                'ALPHA': _agenda_score_points_list,
                'BETA': _agenda_score_points_list,
                'GAMMA': _agenda_score_points_list,
                'DELTA': _agenda_score_points_list,
                'EPSILON': _agenda_score_points_list,
                'ASTROCHIMP': _agenda_score_points_list,
                'COUNSELOR': _agenda_score_points_list,
                'DAREDEVIL': _agenda_score_points_list,
                'CYBORG': _agenda_score_points_list,
                'EXILE': _agenda_score_points_list,
                'ZETA': _agenda_score_points_list,
                'ENGINEER': _agenda_score_points_list,
                'STOWAWAY': _agenda_score_points_list,
                'TROUBLESHOOTER': _agenda_score_points_list,
                'STRANGER': _agenda_score_points_list,

                # Otros Characters del demo que pueden ser PC en tests
                'SERVICEBOT': _agenda_score_points_list,
                'INTEGRALHELM': _agenda_score_points_list,
                'SHOPTECH': _agenda_score_points_list,
                'MACHINEBOT': _agenda_score_points_list,
                'ZEROBORN': _agenda_score_points_list,
            }

            agenda_fn = AGENDA_SCORERS.get(pc_name, _agenda_score_points_list)
            total += int(agenda_fn(pid, cid, pc))


            # --- Bonus points RM 16.4.5 ---
            bc_id = getattr(p, 'bonus_character', None)
            if (not bool(getattr(p, 'bonus_points_disabled', False))) and bc_id and bc_id in self.characters:
                kind, icons = self.bonus_meta_for(bc_id)
                if not kind:
                    kind = str(getattr(p, 'bonus_kind', '') or '').upper()
                    icons = int(getattr(p, 'bonus_icons', 0) or 0)
                if icons > 0:
                    if kind == 'FRIEND':
                        if self.stationfall_counts_as_escaped(bc_id):
                            total += icons
                    elif kind == 'GRUDGE':
                        bc = self.characters[bc_id]
                        down = (str(getattr(bc, 'status', '')).upper() == 'DOWN') or bool(getattr(bc, 'annihilated', False))
                        if down and (not self.stationfall_counts_as_escaped(bc_id)):
                            total += icons


            # --- Other points RM 16.4.6 ---
            if int(getattr(p, 'bribes', 0)) > 0:
                total += 1  # unused bribe
            other_bribes = 0
            for tok_pid in getattr(pc, 'bribe_tokens', []) or []:
                if str(tok_pid) != str(pid):
                    other_bribes += 1
            total += other_bribes

            # --- Influence penalty RM 16.4.7 ---
            # "Outside your pool" incluye cubos en Characters + cubos en Betrayal.
            placed = 0
            for _, cubes in (getattr(self, 'influence', {}).get(pid, {}) or {}).items():
                placed += int(cubes)
            betrayal = int(getattr(p, 'betrayal_cubes', 0) or 0)
            outside_pool = placed + betrayal

            lim = int(getattr(pc, 'influence_limit', 5) or 5)
            if outside_pool > lim:
                total -= (outside_pool - lim)
            scores[pid] = total

        self.stationfall_scores = dict(scores)
        return scores

    def stationfall_compute_scores_detailed(self):
        """Devuelve (scores, breakdown) por jugador.

        - Mantiene la misma lógica que `stationfall_compute_scores()`.
        - `breakdown` es un dict pid -> info estructurada para imprimir en UI.

        Nota: esto NO intenta ser una "explicación de reglas"; sólo desglosa
        de dónde salen los puntos con la lógica actual del prototipo.
        """
        scores = {}
        breakdown = {}

        def pc_has_item_name(cid: str, needle: str) -> bool:
            nd = str(needle).upper()
            ch = self.characters.get(cid)
            if not ch:
                return False
            for iid in getattr(ch, 'items', []) or []:
                it = self.items.get(str(iid).upper())
                if it and nd in str(getattr(it, 'name', '')).upper():
                    return True
            return False

        def no_fire_on_board() -> bool:
            for sec, hz in (getattr(self, 'hazards', {}) or {}).items():
                if 'FIRE' in {str(x).upper() for x in (hz or set())}:
                    pod = getattr(self, 'pods', {}).get(str(sec).upper())
                    if pod and str(getattr(pod, 'location', 'ON_BOARD')).upper() != 'ON_BOARD':
                        continue
                    return False
            return True

        def did_score_bonus_points(pid):
            me = self.player_by_id(pid)
            if not me:
                return False
            if bool(getattr(me, 'bonus_points_disabled', False)):
                return False
            bc_id = getattr(me, 'bonus_character', None)
            if not bc_id:
                return False
            bc_id_u = str(bc_id).upper()
            if bc_id_u not in (getattr(self, 'characters', {}) or {}):
                return False

            kind, icons = self.bonus_meta_for(bc_id_u)
            if not kind:
                kind = str(getattr(me, 'bonus_kind', '') or '').upper()
                icons = int(getattr(me, 'bonus_icons', 0) or 0)
            if int(icons) <= 0:
                return False

            if kind == 'FRIEND':
                return self.stationfall_counts_as_escaped(bc_id_u)
            if kind == 'GRUDGE':
                bc = self.characters.get(bc_id_u)
                if not bc:
                    return False
                downish = (str(getattr(bc, 'status', '')).upper() == 'DOWN') or bool(getattr(bc, 'annihilated', False))
                return downish and (not self.stationfall_counts_as_escaped(bc_id_u))
            return False

        def is_antimatter_armed_at_stationfall() -> bool:
            if bool(getattr(self, 'antimatter_detonated', False)):
                return True
            aid = None
            try:
                aid = self.antimatter_id() if hasattr(self, 'antimatter_id') else None
            except Exception:
                aid = None
            if aid:
                it = (getattr(self, 'items', {}) or {}).get(str(aid).upper())
                if it is not None:
                    return bool(getattr(it, 'armed', False))
            for _iid, _it in (getattr(self, 'items', {}) or {}).items():
                if str(getattr(_it, 'name', '')).strip().upper() == 'ANTIMATTER':
                    return bool(getattr(_it, 'armed', False))
            return False

        def eval_agenda_clause(pid, cid: str, desc: str) -> bool:
            up = str(desc).upper()

            # TROUBLESHOOTER: +2 si Antimatter NO está ARMED
            if ('ANTIMATTER' in up) and ('ARMED' in up) and ('DETON' not in up):
                neg = ('NO' in up) or ('NOT' in up) or ('NUNCA' in up) or ('NEVER' in up) or ('DOES NOT' in up)
                if neg:
                    return (not is_antimatter_armed_at_stationfall())

            # TROUBLESHOOTER: +2 si no hay Secciones DAMAGED On Board
            if ('DAMAGED' in up) and (('SECCION' in up) or ('SECCIÓN' in up) or ('SECTION' in up)):
                neg = ('NO' in up) or ('NOT' in up) or ('NINGUN' in up) or ('NINGÚN' in up) or ('NINGUNA' in up) or ('NONE' in up)
                if neg:
                    onb = self.on_board_sections() if hasattr(self, 'on_board_sections') else set(getattr(self, 'graph', {}) or {})
                    dmg = {str(s).upper() for s in (getattr(self, 'damaged_sections', set()) or set())}
                    return len(dmg & {str(s).upper() for s in onb}) == 0

            # STRANGER: Secret Identity no revelada hasta Stationfall
            if (('SECRET IDENTITY' in up) or ('IDENTIDAD SECRETA' in up)) and ('REVEL' in up or 'REVEAL' in up) and ('STATIONFALL' in up):
                me = self.player_by_id(pid)
                return not bool(getattr(me, 'revealed_prior_to_stationfall', False))

            # STRANGER: Poseer X-SECRET
            if ('X-SECRET' in up or 'XSECRET' in up or 'X SECRET' in up) and ('NEWS' not in up):
                if ('POSE' in up) or ('HAVE' in up) or ('POSEES' in up) or ('TIENES' in up):
                    ch = self.characters.get(cid)
                    try:
                        pc_data = getattr(ch, 'data', {}) or {}
                        return int(pc_data.get('X-SECRET', 0) or 0) > 0
                    except Exception:
                        return False

            # STRANGER: Puntuar Bonus Points
            if ('BONUS' in up) and ('POINT' in up) and ('NEWS' not in up):
                if ('PUNT' in up) or ('SCORE' in up):
                    return did_score_bonus_points(pid)

            # STRANGER: LIVE y COLOCATED con BC
            if ('BONUS' in up) and ('CHARACTER' in up) and ('COLOCAT' in up) and ('LIVE' in up):
                me = self.player_by_id(pid)
                if not me:
                    return False
                bc_id = getattr(me, 'bonus_character', None)
                if not bc_id:
                    return False
                bc_id_u = str(bc_id).upper()
                if bc_id_u not in (getattr(self, 'characters', {}) or {}):
                    return False
                pcch = self.characters.get(cid)
                bcch = self.characters.get(bc_id_u)
                if not pcch or not bcch:
                    return False
                pc_live = (str(getattr(pcch, 'status', '')).upper() == 'LIVE') and (not bool(getattr(pcch, 'annihilated', False)))
                bc_present = not bool(getattr(bcch, 'annihilated', False))
                if not (pc_live and bc_present):
                    return False
                return str(getattr(pcch, 'section', '')).upper() == str(getattr(bcch, 'section', '')).upper()

            # CYBORG: ningún PC Human escapa
            if ('PC' in up) and ('HUMAN' in up) and ('ESCAP' in up or 'ESCAPA' in up) and (('NO' in up) or ('NINGUN' in up) or ('NINGÚN' in up)):
                for _p in self.players:
                    pcid = getattr(_p, 'revealed_character', None) or getattr(_p, 'secret_identity', None)
                    if not pcid:
                        continue
                    pcch = self.characters.get(str(pcid).upper())
                    if not pcch:
                        continue
                    if 'HUMAN' not in str(getattr(pcch, 'ctype', '')).upper():
                        continue
                    if self.stationfall_counts_as_escaped(str(pcid).upper()):
                        return False
                return True

            # CYBORG: no escapa ninguna Contamination
            if ('CONTAM' in up) and ('ESCAP' in up or 'ESCAPA' in up) and (('NO' in up) or ('NINGUN' in up) or ('NINGÚN' in up)):
                for _cid, _ch in (getattr(self, 'characters', {}) or {}).items():
                    if not bool(getattr(_ch, 'contaminated', False)):
                        continue
                    if self.stationfall_counts_as_escaped(str(_cid).upper()):
                        return False
                return True

            # ENGINEER: Antimatter detona On Board antes de Stationfall
            if ('ANTIMATTER' in up) and ('DETON' in up or 'DETONA' in up or 'EXPLO' in up):
                if not bool(getattr(self, 'antimatter_detonated', False)):
                    return False
                det_sec = str(getattr(self, 'antimatter_detonation_section', '') or '').upper()
                if det_sec in ('', str(OUT_OF_GAME_SECTION).upper(), str(OUTER_SPACE_SECTION).upper(), 'MESO'):
                    return False
                pod = getattr(self, 'pods', {}).get(det_sec)
                if pod and str(getattr(pod, 'location', 'ON_BOARD')).upper() != 'ON_BOARD':
                    return False
                sf_reason = str(getattr(self, 'stationfall_reason', '') or '').upper()
                if sf_reason == 'ANTIMATTER':
                    return True
                det_min = getattr(self, 'antimatter_detonation_minute', None)
                sf_min = getattr(self, 'stationfall_minute', None)
                if det_min is None or sf_min is None:
                    return True
                try:
                    return int(det_min) < int(sf_min)
                except Exception:
                    return False

            # ENGINEER: terminas INNOCENT
            if ('INNOCENT' in up) and ('END' in up or 'FINAL' in up or 'TERMIN' in up or 'ACAB' in up):
                me = self.player_by_id(pid)
                return str(getattr(me, 'legal', '') or '').lower() == 'innocent'

            # ENGINEER: Artifact NO escapa
            if ('ARTIFACT' in up) and ('ESCAP' in up or 'ESCAPA' in up) and (('DOES NOT' in up) or ('NOT' in up) or ('NO' in up)) and (' CON ' not in up) and (' WITH ' not in up):
                target_iid = None
                for _iid, _it in (getattr(self, 'items', {}) or {}).items():
                    if str(getattr(_it, 'name', '')).strip().upper() == 'ARTIFACT':
                        target_iid = str(_iid).upper()
                        break
                if not target_iid:
                    return True
                loc_type, loc_id = self.item_location(target_iid)
                escaped = False
                if loc_type == 'CHAR':
                    escaped = self.stationfall_counts_as_escaped(str(loc_id).upper())
                elif loc_type == 'SEC':
                    sec = str(loc_id).upper()
                    if sec == 'MESO':
                        escaped = True
                    else:
                        pod = getattr(self, 'pods', {}).get(sec)
                        if pod and str(getattr(pod, 'location', 'ON_BOARD')).upper() == 'MESO':
                            escaped = True
                return not escaped

            # COUNSELOR: Artifact escapes
            if ('ARTIFACT' in up) and ('ESCAP' in up or 'ESCAPA' in up) and (' CON ' not in up) and (' WITH ' not in up):
                target_iid = None
                for _iid, _it in (getattr(self, 'items', {}) or {}).items():
                    if str(getattr(_it, 'name', '')).strip().upper() == 'ARTIFACT':
                        target_iid = str(_iid).upper()
                        break
                if not target_iid:
                    return False
                loc_type, loc_id = self.item_location(target_iid)
                if loc_type == 'CHAR':
                    return self.stationfall_counts_as_escaped(str(loc_id).upper())
                if loc_type == 'SEC':
                    sec = str(loc_id).upper()
                    if sec == 'MESO':
                        return True
                    pod = getattr(self, 'pods', {}).get(sec)
                    if pod and str(getattr(pod, 'location', 'ON_BOARD')).upper() == 'MESO':
                        return True
                    return False
                return False

            # COUNSELOR: more Kompromat than any other
            if ('MORE KOMPROMAT' in up) or ('MÁS KOMPROMAT' in up) or ('MAS KOMPROMAT' in up):
                me = self.player_by_id(pid)
                my_k = len(getattr(me, 'kompromat_hand', []) or [])
                others = [len(getattr(p, 'kompromat_hand', []) or []) for p in self.players if p.pid != pid]
                mx = max(others) if others else 0
                return my_k > mx

            # COUNSELOR: least Betrayal
            if ('BETRAYAL' in up) and ('LEAST' in up or 'MENOS' in up or 'MINIMO' in up or 'MÍNIMO' in up):
                me = self.player_by_id(pid)
                my_b = int(getattr(me, 'betrayal_cubes', 0) or 0)
                all_b = [int(getattr(p, 'betrayal_cubes', 0) or 0) for p in self.players]
                mn = min(all_b) if all_b else my_b
                return my_b == mn

            # DAREDEVIL: only human escapes
            if (('ONLY HUMAN' in up) or ('UNICO HUMAN' in up) or ('ÚNICO HUMAN' in up)) and ('ESCAP' in up or 'ESCAPA' in up):
                if not self.stationfall_counts_as_escaped(cid):
                    return False
                me_ch = self.characters.get(cid)
                if me_ch and 'HUMAN' not in str(getattr(me_ch, 'ctype', '')).upper():
                    return False
                for _ocid, _och in (getattr(self, 'characters', {}) or {}).items():
                    oc = str(_ocid).upper()
                    if oc == cid:
                        continue
                    if 'HUMAN' not in str(getattr(_och, 'ctype', '')).upper():
                        continue
                    if self.stationfall_counts_as_escaped(oc):
                        return False
                return True

            # DAREDEVIL: possesses Artifact OR contaminated
            if ('ARTIFACT' in up) and ('CONTAM' in up) and ((' OR ' in up) or (' O ' in up) or ('OR' in up)):
                ch = self.characters.get(cid)
                has_art = pc_has_item_name(cid, 'ARTIFACT')
                is_cont = bool(getattr(ch, 'contaminated', False)) if ch else False
                return has_art or is_cont

            # Project X released / not
            if ('PROJECT X' in up) and (('RELEASE' in up) or ('LIBER' in up)):
                released = bool(getattr(self, 'project_x_released', False))
                neg = ('NO' in up) or ('NOT' in up) or ('NUNCA' in up) or ('NEVER' in up) or ('DOES NOT' in up)
                return (not released) if neg else released

            # EXILE: Evidence and NEWS no Evidence
            if ('EVIDENCE' in up) and ('NEWS' in up) and (('DOES NOT' in up) or ('NO' in up) or ('NOT' in up)):
                ch = self.characters.get(cid)
                has_ev = False
                if ch:
                    try:
                        has_ev = int((getattr(ch, 'data', {}) or {}).get('EVIDENCE', 0) or 0) > 0
                    except Exception:
                        has_ev = False
                try:
                    news_ev = int((getattr(self, 'offsites_data', {}) or {}).get('NEWS', {}).get('EVIDENCE', 0) or 0)
                except Exception:
                    news_ev = 0
                return bool(has_ev) and (news_ev == 0)

            # STOWAWAY: NEWS ends with X-SECRET
            if ('NEWS' in up) and (('X-SECRET' in up) or ('XSECRET' in up) or ('X SECRET' in up)):
                try:
                    st = (getattr(self, 'offsites_stack', {}) or {}).get('NEWS', [])
                    if st:
                        return str(st[-1]).upper() == 'X-SECRET'
                except Exception:
                    pass
                try:
                    n_x = int((getattr(self, 'offsites_data', {}) or {}).get('NEWS', {}).get('X-SECRET', 0) or 0)
                except Exception:
                    n_x = 0
                return n_x > 0

            # STOWAWAY: NEWS ends with EVIDENCE
            if ('NEWS' in up) and ('EVIDENCE' in up) and not (('DOES NOT' in up) or ('NO' in up) or ('NOT' in up)):
                try:
                    st = (getattr(self, 'offsites_stack', {}) or {}).get('NEWS', [])
                    if st:
                        return str(st[-1]).upper() == 'EVIDENCE'
                except Exception:
                    pass
                try:
                    n_ev = int((getattr(self, 'offsites_data', {}) or {}).get('NEWS', {}).get('EVIDENCE', 0) or 0)
                except Exception:
                    n_ev = 0
                return n_ev > 0

            # STOWAWAY: +3 escapes with Evidence and nobody else does
            if ('EVIDENCE' in up) and ('ESCAP' in up or 'ESCAPA' in up) and (('NO OTHER' in up) or ('NINGUN OTRO' in up) or ('NINGÚN OTRO' in up) or ('NINGUNA OTRA' in up) or ('NINGÚNA OTRA' in up)):
                if not self.stationfall_counts_as_escaped(cid):
                    return False
                ch = self.characters.get(cid)
                has_ev = False
                if ch:
                    try:
                        has_ev = int((getattr(ch, 'data', {}) or {}).get('EVIDENCE', 0) or 0) > 0
                    except Exception:
                        has_ev = False
                if not has_ev:
                    return False
                for _ocid, _och in (getattr(self, 'characters', {}) or {}).items():
                    oc = str(_ocid).upper()
                    if oc == cid:
                        continue
                    if not self.stationfall_counts_as_escaped(oc):
                        continue
                    try:
                        o_ev = int((getattr(_och, 'data', {}) or {}).get('EVIDENCE', 0) or 0) > 0
                    except Exception:
                        o_ev = False
                    if o_ev:
                        return False
                return True

            ok = True
            if 'ESCAP' in up or 'ESCAPA' in up:
                ok = ok and self.stationfall_counts_as_escaped(cid)
            if 'HELMET' in up:
                ok = ok and pc_has_item_name(cid, 'HELMET')
            if 'BRIEFCASE' in up:
                ok = ok and pc_has_item_name(cid, 'BRIEFCASE')
            if 'ARTIFACT' in up:
                ok = ok and pc_has_item_name(cid, 'ARTIFACT')
            if ('GUN' in up) or ('PISTOL' in up):
                ok = ok and (pc_has_item_name(cid, 'GUN') or pc_has_item_name(cid, 'PISTOL'))
            if 'CONTAM' in up:
                ch = self.characters.get(cid)
                ok = ok and (bool(getattr(ch, 'contaminated', False)) if ch else False)
            if ('FIRE' in up) and (('NO' in up) or ('NOT' in up)):
                ok = ok and no_fire_on_board()
            return ok

        def _agenda_lines_points_list(pid, cid, pc):
            total = 0
            last_base_met = True
            lines = []
            for pts, desc in getattr(pc, 'agenda_points', []) or []:
                d = str(desc).lstrip()
                is_plus = d.startswith('+')
                up_desc = str(desc).upper()

                # CYBORG: officer down (multiplicativo)
                if (AB.OFFICER in up_desc) and ('DOWN' in up_desc) and ('POR CADA' in up_desc or 'PER' in up_desc or 'EACH' in up_desc):
                    cnt = 0
                    for __cid, __ch in (getattr(self, 'characters', {}) or {}).items():
                        try:
                            ab = __ch.effective_abilities() if hasattr(__ch, 'effective_abilities') else set(getattr(__ch, 'abilities', set()) or set())
                        except Exception:
                            ab = set(getattr(__ch, 'abilities', set()) or set())
                        ab = {str(a).upper() for a in (ab or set())}
                        if 'OFFICER' not in ab:
                            continue
                        if str(getattr(__ch, 'status', '')).upper() == 'DOWN' and (not bool(getattr(__ch, 'escaped', False))):
                            cnt += 1
                    earned = int(pts) * int(cnt)
                    total += earned
                    last_base_met = True
                    lines.append({'status': '✅' if cnt > 0 else '❌', 'earned': earned, 'base_pts': int(pts), 'mult': cnt, 'desc': str(desc)})
                    continue

                # TROUBLESHOOTER: robot live (multiplicativo)
                if ('ROBOT' in up_desc) and ('LIVE' in up_desc) and ('POR CADA' in up_desc or 'PER' in up_desc or 'EACH' in up_desc):
                    cnt = 0
                    for __cid2, __ch2 in (getattr(self, 'characters', {}) or {}).items():
                        if bool(getattr(__ch2, 'annihilated', False)):
                            continue
                        if str(getattr(__ch2, 'status', '')).upper() != 'LIVE':
                            continue
                        if 'ROBOT' not in _norm(getattr(__ch2, 'ctype', '')):
                            continue
                        cnt += 1
                    earned = int(pts) * int(cnt)
                    total += earned
                    last_base_met = True
                    lines.append({'status': '✅' if cnt > 0 else '❌', 'earned': earned, 'base_pts': int(pts), 'mult': cnt, 'desc': str(desc)})
                    continue

                # EXILE: kompromat de escapados (multiplicativo, con semántica base/+)
                if ('KOMPROMAT' in up_desc) and ('ESCAP' in up_desc or 'ESCAPED' in up_desc) and ('POR CADA' in up_desc or 'PER' in up_desc or 'EACH' in up_desc):
                    cnt = 0
                    me_p = self.player_by_id(pid)
                    hand = getattr(me_p, 'kompromat_hand', []) or []
                    for kid in hand:
                        it = (getattr(self, 'items', {}) or {}).get(str(kid).upper())
                        if not it:
                            continue
                        if str(getattr(it, 'kind', '')).lower() != 'kompromat':
                            continue
                        tgt = getattr(it, 'kompromat_target', None)
                        if not tgt:
                            continue
                        if self.stationfall_counts_as_escaped(str(tgt).upper()):
                            cnt += 1

                    earned = 0
                    status = '❌'
                    blocked = False
                    if is_plus:
                        if not last_base_met:
                            blocked = True
                            status = '⛔'
                        else:
                            earned = int(pts) * int(cnt)
                            total += earned
                            status = '✅' if cnt > 0 else '❌'
                    else:
                        if cnt > 0:
                            earned = int(pts) * int(cnt)
                            total += earned
                            last_base_met = True
                            status = '✅'
                        else:
                            # IMPORTANT: reproduce el prototipo (no toca last_base_met)
                            status = '❌'
                    lines.append({'status': status, 'earned': earned, 'base_pts': int(pts), 'mult': cnt, 'desc': str(desc), 'blocked': blocked})
                    continue

                if not is_plus:
                    met = eval_agenda_clause(pid, cid, desc)
                    earned = int(pts) if met else 0
                    total += earned
                    last_base_met = bool(met)
                    lines.append({'status': '✅' if met else '❌', 'earned': earned, 'base_pts': int(pts), 'desc': str(desc)})
                else:
                    if not last_base_met:
                        lines.append({'status': '⛔', 'earned': 0, 'base_pts': int(pts), 'desc': str(desc), 'blocked': True})
                    else:
                        met = eval_agenda_clause(pid, cid, desc)
                        earned = int(pts) if met else 0
                        if met:
                            total += earned
                        lines.append({'status': '✅' if met else '❌', 'earned': earned, 'base_pts': int(pts), 'desc': str(desc)})
            return total, lines

        def _agenda_lines_security(pid, cid, pc):
            onb = self.on_board_sections() if hasattr(self, 'on_board_sections') else set(getattr(self, 'graph', {}) or {})

            def _is_down_on_board(_ch) -> bool:
                if bool(getattr(_ch, 'escaped', False)) or bool(getattr(_ch, 'annihilated', False)):
                    return False
                if str(getattr(_ch, 'status', '')).upper() != 'DOWN':
                    return False
                return str(getattr(_ch, 'section', '')).upper() in onb

            def _is_revealed_pc_non_innocent(__cid: str) -> bool:
                try:
                    if not self.is_pc(str(__cid).upper()):
                        return False
                    opid = self.pc_owner_pid(str(__cid).upper())
                    if not opid:
                        return False
                    pl = self.player_by_id(opid)
                    return str(getattr(pl, 'legal', 'Innocent') or '').lower() != 'innocent'
                except Exception:
                    return False

            lines = []
            total_s = 0

            # (1) Fugitive / Monster / PC no-Innocent DOWN on board
            cnt_targets = 0
            for __cid2, __ch2 in (getattr(self, 'characters', {}) or {}).items():
                if not _is_down_on_board(__ch2):
                    continue
                if __ch2.has_ability(AB.FUGITIVE) or _is_revealed_pc_non_innocent(str(__cid2).upper()):
                    cnt_targets += 1

            for __mid, __m in list((getattr(self, 'monsters', {}) or {}).items()):
                if not __m:
                    continue
                if str(getattr(__m, 'status', '')).upper() != 'DOWN':
                    continue
                if str(getattr(__m, 'section', '')).upper() not in onb:
                    continue
                cnt_targets += 1

            if cnt_targets:
                total_s += cnt_targets
            lines.append({'status': '✅' if cnt_targets else '❌', 'earned': int(cnt_targets), 'desc': '1 pt por cada Fugitive/Monster/PC no-Innocent DOWN a bordo', 'mult': int(cnt_targets), 'base_pts': 1})

            # (2) Humans DOWN con Gun o Bludgeon
            def _has_gun_or_bludgeon(_ch) -> bool:
                for __iid in list(getattr(_ch, 'items', []) or []):
                    it = getattr(self, 'items', {}).get(str(__iid).upper())
                    if not it:
                        continue
                    nm = str(getattr(it, 'name', '')).strip().upper()
                    if nm in ('GUN', 'PISTOL', 'BLUDGEON'):
                        return True
                return False

            cnt_humans = 0
            for __cid2, __ch2 in (getattr(self, 'characters', {}) or {}).items():
                if not _is_down_on_board(__ch2):
                    continue
                if 'HUMAN' not in _norm(getattr(__ch2, 'ctype', '')):
                    continue
                if _has_gun_or_bludgeon(__ch2):
                    cnt_humans += 1
            if cnt_humans:
                total_s += cnt_humans
            lines.append({'status': '✅' if cnt_humans else '❌', 'earned': int(cnt_humans), 'desc': '1 pt por cada Human DOWN con Gun o Bludgeon a bordo', 'mult': int(cnt_humans), 'base_pts': 1})

            # (3) Briefcase/Artifact no escapan (+ combo)
            def _find_item_id_by_exact_name(name: str):
                nm = str(name).strip().upper()
                for _iid, _it in (getattr(self, 'items', {}) or {}).items():
                    if str(getattr(_it, 'name', '')).strip().upper() == nm:
                        return str(_iid).upper()
                return None

            def _item_escapes(iid: str) -> bool:
                if not iid:
                    return False
                loc_type, loc_id = self.item_location(str(iid).upper())
                if loc_type == 'CHAR':
                    return self.stationfall_counts_as_escaped(str(loc_id).upper())
                if loc_type == 'SEC':
                    sec = str(loc_id).upper()
                    if sec == 'MESO':
                        return True
                    pod = getattr(self, 'pods', {}).get(sec)
                    if pod and str(getattr(pod, 'location', 'ON_BOARD')).upper() == 'MESO':
                        return True
                return False

            brief_iid = _find_item_id_by_exact_name('BRIEFCASE')
            art_iid = _find_item_id_by_exact_name('ARTIFACT')
            brief_no = (not _item_escapes(brief_iid))
            art_no = (not _item_escapes(art_iid))

            earned_brief = 1 if brief_no else 0
            earned_art = 1 if art_no else 0
            earned_combo = 1 if (brief_no and art_no) else 0
            total_s += earned_brief + earned_art + earned_combo

            lines.append({'status': '✅' if brief_no else '❌', 'earned': earned_brief, 'desc': '1 pt si Briefcase NO escapa', 'base_pts': 1})
            lines.append({'status': '✅' if art_no else '❌', 'earned': earned_art, 'desc': '1 pt si Artifact NO escapa', 'base_pts': 1})
            lines.append({'status': '✅' if (brief_no and art_no) else '❌', 'earned': earned_combo, 'desc': '+1 si Briefcase y Artifact NO escapan', 'base_pts': 1})

            return int(total_s), lines

        def _agenda_lines_medical(pid, cid, pc):
            total_m = 0
            lines = []
            onb = self.on_board_sections() if hasattr(self, 'on_board_sections') else set(getattr(self, 'graph', {}) or {})

            any_human_down = False
            for __cid2, __ch2 in (getattr(self, 'characters', {}) or {}).items():
                if bool(getattr(__ch2, 'escaped', False)) or bool(getattr(__ch2, 'annihilated', False)):
                    continue
                if str(getattr(__ch2, 'status', '')).upper() != 'DOWN':
                    continue
                if 'HUMAN' not in str(getattr(__ch2, 'ctype', '')).upper():
                    continue
                if str(getattr(__ch2, 'section', '')).upper() not in onb:
                    continue
                any_human_down = True
                break
            earned = 2 if (not any_human_down) else 0
            total_m += earned
            lines.append({'status': '✅' if (not any_human_down) else '❌', 'earned': earned, 'desc': '2 pts si no hay Humans DOWN a bordo', 'base_pts': 2})

            mk = self.get_character_counter(cid, 'MEDICAL_MARKER', 0) if hasattr(self, 'get_character_counter') else 0
            try:
                mk = int(mk)
            except Exception:
                mk = 0
            mk = max(0, min(11, mk))
            stars = 0
            for t in (1, 2, 3, 4, 6, 8, 11):
                if mk >= t:
                    stars += 1
            total_m += stars
            lines.append({'status': '✅' if stars > 0 else '❌', 'earned': int(stars), 'desc': '1 pt por cada ⭐ en Medical Track', 'base_pts': 1, 'mult': int(stars), 'note': f'marker={mk}'})

            return int(total_m), lines

        def _agenda_lines_station_chief(pid, cid, pc):
            total_sc = 0
            lines = []
            onb = self.on_board_sections() if hasattr(self, 'on_board_sections') else set(getattr(self, 'graph', {}) or {})

            human_esc = 0
            for __cid2, __ch2 in (getattr(self, 'characters', {}) or {}).items():
                oc = str(__cid2).upper()
                if oc == str(cid).upper():
                    continue
                if not self.stationfall_counts_as_escaped(oc):
                    continue
                if 'HUMAN' not in _norm(getattr(__ch2, 'ctype', '')):
                    continue
                human_esc += 1
            total_sc += human_esc
            lines.append({'status': '✅' if human_esc else '❌', 'earned': int(human_esc), 'desc': '1 pt por cada OTRO Human que ESCAPA', 'base_pts': 1, 'mult': int(human_esc)})

            npc_officer_esc = 0
            for __cid2, __ch2 in (getattr(self, 'characters', {}) or {}).items():
                oc = str(__cid2).upper()
                if oc == str(cid).upper():
                    continue
                if self.is_pc(oc):
                    continue
                if not self.stationfall_counts_as_escaped(oc):
                    continue
                try:
                    if __ch2.has_ability(AB.OFFICER):
                        npc_officer_esc += 1
                except Exception:
                    ab = {str(a).upper() for a in (getattr(__ch2, 'abilities', set()) or set())}
                    if AB.OFFICER in ab:
                        npc_officer_esc += 1
            total_sc += npc_officer_esc
            lines.append({'status': '✅' if npc_officer_esc else '❌', 'earned': int(npc_officer_esc), 'desc': '+1 pt por cada NPC con OFFICER que ESCAPA', 'base_pts': 1, 'mult': int(npc_officer_esc)})

            pc_sec = str(getattr(pc, 'section', '')).upper()
            pc_live = (str(getattr(pc, 'status', '')).upper() == 'LIVE') and (not bool(getattr(pc, 'annihilated', False)))
            met = pc_live and (not self.stationfall_counts_as_escaped(str(cid).upper())) and (pc_sec in onb)
            earned = 2 if met else 0
            total_sc += earned
            lines.append({'status': '✅' if met else '❌', 'earned': earned, 'desc': '+2 pts si Station Chief está ON BOARD y LIVE en Stationfall', 'base_pts': 2})

            return int(total_sc), lines

        # --- Main loop (players in turn order) ---
        for p in self.players:
            pid = p.pid
            cid = p.revealed_character or p.secret_identity
            pname = p.display_name() if hasattr(p, 'display_name') else str(pid)

            if not cid or cid not in self.characters:
                scores[pid] = 0
                breakdown[pid] = {'player': pname, 'total': 0, 'pc': None, 'bc': None, 'agenda': [], 'bonus': None, 'other': {}, 'influence': {}}
                continue

            pc = self.characters[cid]
            pc_name = _norm(getattr(pc, 'name', ''))

            # Agenda
            if pc_name == 'SECURITY':
                agenda_total, agenda_lines = _agenda_lines_security(pid, cid, pc)
            elif pc_name == 'MEDICAL':
                agenda_total, agenda_lines = _agenda_lines_medical(pid, cid, pc)
            elif pc_name == 'STATIONCHIEF':
                agenda_total, agenda_lines = _agenda_lines_station_chief(pid, cid, pc)
            else:
                agenda_total, agenda_lines = _agenda_lines_points_list(pid, cid, pc)

            total = int(agenda_total)

            # Bonus points
            bc_info = None
            bc_pts = 0
            bc_id = getattr(p, 'bonus_character', None)
            if (not bool(getattr(p, 'bonus_points_disabled', False))) and bc_id and (str(bc_id).upper() in self.characters):
                bc_id_u = str(bc_id).upper()
                kind, icons = self.bonus_meta_for(bc_id_u)
                if not kind:
                    kind = str(getattr(p, 'bonus_kind', '') or '').upper()
                    icons = int(getattr(p, 'bonus_icons', 0) or 0)
                icons = int(icons or 0)
                kind = str(kind or '').upper()

                bcch = self.characters.get(bc_id_u)
                bc_name = getattr(bcch, 'name', bc_id_u) if bcch else bc_id_u

                met = False
                reason = ''
                if icons > 0:
                    if kind == 'FRIEND':
                        met = self.stationfall_counts_as_escaped(bc_id_u)
                        reason = 'BC escapa' if met else 'BC no escapa'
                    elif kind == 'GRUDGE':
                        down = (str(getattr(bcch, 'status', '')).upper() == 'DOWN') or bool(getattr(bcch, 'annihilated', False))
                        esc = self.stationfall_counts_as_escaped(bc_id_u)
                        met = bool(down) and (not esc)
                        if met:
                            reason = 'BC DOWN y NO escapa'
                        else:
                            reason = ('BC no está DOWN' if not down else 'BC escapa')

                bc_pts = int(icons) if met else 0
                total += bc_pts
                bc_info = {
                    'cid': bc_id_u,
                    'name': bc_name,
                    'kind': kind,
                    'icons': icons,
                    'earned': bc_pts,
                    'met': met,
                    'reason': reason,
                }

            # Other points (bribes)
            other = {}
            unused = 1 if int(getattr(p, 'bribes', 0) or 0) > 0 else 0
            if unused:
                total += 1
            other['unused_bribe'] = unused

            sources = []
            other_bribes = 0
            for tok_pid in getattr(pc, 'bribe_tokens', []) or []:
                if str(tok_pid) != str(pid):
                    other_bribes += 1
                    op = self.player_by_id(tok_pid)
                    sources.append(op.display_name() if op and hasattr(op, 'display_name') else str(tok_pid))
            total += int(other_bribes)
            other['bribes_on_pc'] = {'count': int(other_bribes), 'from': sources}

            # Influence penalty
            placed = 0
            for _, cubes in (getattr(self, 'influence', {}).get(pid, {}) or {}).items():
                placed += int(cubes)
            betrayal = int(getattr(p, 'betrayal_cubes', 0) or 0)
            outside_pool = placed + betrayal
            lim = int(getattr(pc, 'influence_limit', 5) or 5)
            pen = max(0, int(outside_pool) - int(lim))
            if pen:
                total -= pen

            inf = {
                'placed_influence': int(placed),
                'betrayal': int(betrayal),
                'outside_pool': int(outside_pool),
                'limit': int(lim),
                'penalty': int(pen),
                'supply': int(getattr(p, 'supply_cubes', 0) or 0),
            }

            scores[pid] = int(total)
            breakdown[pid] = {
                'player': pname,
                'pid': pid,
                'legal': getattr(p, 'legal', 'Innocent'),
                'pc': {'cid': str(cid).upper(), 'name': getattr(pc, 'name', str(cid).upper())},
                'bc': bc_info,
                'agenda_total': int(agenda_total),
                'agenda': agenda_lines,
                'other': other,
                'influence': inf,
                'total': int(total),
            }

        self.stationfall_scores = dict(scores)
        return scores, breakdown



    def stationfall_determine_winners(self) -> List[PlayerId]:
        """RM 16.4.8–16.4.9 (+ RM 17.4/17.5 para 6+ jugadores sin equipos).

        - Ganador(es) = mejores puntuaciones entre jugadores NO Guilty.
          Excepción (quirks del Character Dossier): si tu PC tiene la habilidad
          "INMUNITY", puede ganar incluso estando Guilty.
        - Desempate 1 (RM 16.4.9): menos cubos en Betrayal.
        - Desempate 2 (RM 16.4.9): más cubos de Influence sin usar (supply).
        - Si sigue empatado, comparten la victoria.
        """
        if not getattr(self, 'stationfall_scores', None):
            self.stationfall_compute_scores()

        # Reunimos candidatos elegibles (no Guilty, salvo INMUNITY)
        rows: List[Dict[str, object]] = []
        for p in self.players:
            pid = p.pid
            legal = str(getattr(p, 'legal', '')).lower()

            # Quirk: algunos PCs pueden ganar incluso estando Guilty.
            pcid = getattr(p, 'revealed_character', None) or getattr(p, 'secret_identity', None)
            pc = self.characters.get(str(pcid).upper()) if pcid else None
            abil = {str(a).upper() for a in (getattr(pc, 'abilities', set()) or set())} if pc else set()
            has_inmunity = AB.INMUNITY in abil

            if legal == 'guilty' and (not has_inmunity):
                continue

            rows.append({
                'pid': pid,
                'score': int(self.stationfall_scores.get(pid, 0)),
                'betrayal': int(getattr(p, 'betrayal_cubes', 0) or 0),
                'supply': int(getattr(p, 'supply_cubes', 0) or 0),
            })

        if not rows:
            self.stationfall_winners = []
            return []

        n_players = len(getattr(self, 'players', []) or [])
        # TODO: Team games (RM 17.2/17.3). Por ahora, aplicamos el modo estándar.
        if n_players >= 9:
            n_winners = 3
        elif n_players >= 6:
            n_winners = 2
        else:
            n_winners = 1

        # Orden final aplicando desempates
        rows.sort(key=lambda r: (-int(r['score']), int(r['betrayal']), -int(r['supply'])))

        # Caso estándar: 1 ganador (a menos que el desempate no lo resuelva)
        if n_winners == 1:
            best = rows[0]
            best_key = (int(best['score']), int(best['betrayal']), int(best['supply']))
            winners = [best['pid']]
            for r in rows[1:]:
                if (int(r['score']), int(r['betrayal']), int(r['supply'])) == best_key:
                    winners.append(r['pid'])
                else:
                    break
            self.stationfall_winners = winners
            return winners

        # Caso 6+ jugadores: 2 o 3 ganadores. Si el último puesto queda empatado tras desempates, se comparte.
        take = min(n_winners, len(rows))
        base = rows[:take]
        cutoff = base[-1]
        cutoff_key = (int(cutoff['score']), int(cutoff['betrayal']), int(cutoff['supply']))
        winners = [r['pid'] for r in base]

        for r in rows[take:]:
            if (int(r['score']), int(r['betrayal']), int(r['supply'])) == cutoff_key:
                winners.append(r['pid'])
            else:
                break

        self.stationfall_winners = winners
        return winners

    # --- Re-entry token helpers ---
    def set_reentry_token(self, token: str) -> None:
        t = str(token).upper()
        if t not in ("STATIONFALL", "SAFE"):
            raise ValueError("Re-entry token inválido: usa STATIONFALL o SAFE")
        self.reentry_token = t
        # Por defecto, al setearlo por debug, lo ocultamos de nuevo.
        self.reentry_revealed = False

    def reveal_reentry_token(self) -> str:
        self.reentry_revealed = True
        return str(getattr(self, 'reentry_token', 'STATIONFALL')).upper()

    def player_by_id(self, pid: PlayerId) -> PlayerState:
        for p in self.players:
            if p.pid == pid:
                return p
        raise KeyError(pid)


    # --- Character reference helpers ---
    def resolve_character_ref(self, ref: str, *, allow_monster: bool = False) -> str:
        """Resolve a character reference into a CharacterId.

        Accepts either a canonical id (e.g. "C4") or a character name (case-insensitive,
        ignoring spaces/punctuation), e.g. "Counselor", "station_chief", "Station Chief".

        If allow_monster=True, allows Monster ids like "M1" to pass through.
        """

        raw = str(ref or "").strip()
        if not raw:
            raise KeyError(ref)

        up = raw.upper()

        # Canonical ids
        import re
        if re.match(r"^C\d+$", up):
            if up in (getattr(self, 'characters', {}) or {}):
                return up

        if allow_monster and re.match(r"^M\d+$", up):
            return up

        want = _norm(up)
        chars = getattr(self, 'characters', {}) or {}

        exact: list[str] = []
        for cid, ch in chars.items():
            nm = getattr(ch, 'name', '')
            if _norm(nm) == want:
                exact.append(str(cid).upper())

        if len(exact) == 1:
            return exact[0]
        if len(exact) > 1:
            # Should not happen in Stationfall, but be safe.
            raise KeyError(f"Ambiguous character name: {raw}")

        # Not found
        raise KeyError(raw)


    # --- Item reference helpers ---
    def resolve_item_ref(self, ref: str, *, candidates: Optional[Iterable[str]] = None) -> str:
        """Resolve an item reference into an ItemId.

        Accepts either a canonical id (e.g. "I12") or an item name (case-insensitive,
        ignoring spaces/punctuation), e.g. "Bludgeon", "NanoGel", "Rocket Wings".

        If `candidates` is provided, restricts resolution to that set (useful for
        resolving "the Bludgeon I'm holding" vs. "a Bludgeon in my room").

        For Kompromat items (name like "Kompromat(Station Chief)"), you can also
        reference by the *target character name* alone, e.g. "Station Chief".

        Returns a *deterministic* choice if multiple matches exist: the lowest
        numeric ItemId (I#) among the matches.
        """

        raw = str(ref or "").strip()
        if not raw:
            raise KeyError(ref)

        import re
        up = raw.upper()

        items: dict[str, Item] = getattr(self, 'items', {}) or {}

        # Candidate pool
        pool = [str(x).upper() for x in (candidates or items.keys())]
        pool = [iid for iid in pool if iid in items]

        # Canonical ids
        if re.match(r"^I\d+$", up):
            if up in pool:
                return up

        want = _norm(raw)

        def _sort_key(iid: str) -> int:
            s = str(iid).upper()
            if s.startswith('I') and s[1:].isdigit():
                return int(s[1:])
            return 10_000_000

        # Exact normalized-name match
        exact: list[str] = []
        for iid in pool:
            it = items.get(iid)
            if not it:
                continue
            if _norm(getattr(it, 'name', '')) == want:
                exact.append(iid)
        if exact:
            return sorted(exact, key=_sort_key)[0]

        # Prefix match (handles Nanogel(2), Helmet(Integral), etc.)
        pref: list[str] = []
        for iid in pool:
            it = items.get(iid)
            if not it:
                continue
            nm = _norm(getattr(it, 'name', ''))
            if nm.startswith(want):
                pref.append(iid)
        if pref:
            return sorted(pref, key=_sort_key)[0]

        # Kompromat special: allow referencing by target character name
        # Kompromat names normalize to "KOMPROMAT<target>".
        kspec: list[str] = []
        for iid in pool:
            it = items.get(iid)
            if not it:
                continue
            if str(getattr(it, 'kind', '')).lower() != 'kompromat':
                continue
            nm = _norm(getattr(it, 'name', ''))
            if nm.startswith('KOMPROMAT') and nm.endswith(want):
                kspec.append(iid)
        if kspec:
            return sorted(kspec, key=_sort_key)[0]

        # Not found
        raise KeyError(raw)


    # --- Identity Card helpers ---
    def identity_card_for(self, cid: CharacterId) -> Optional[IdentityCard]:
        """Return the IdentityCard metadata for this CharacterId, if available."""
        cid_u = str(cid).upper()
        cards = getattr(self, 'identity_cards', {}) or {}
        return cards.get(cid_u)

    def bonus_meta_for(self, cid: CharacterId) -> Tuple[Optional[str], int]:
        """Return (bonus_kind, bonus_icons) for the given CharacterId.

        If Identity Cards are not configured in this state, returns (None, 0).
        """
        card = self.identity_card_for(cid)
        if card is None:
            return (None, 0)
        return (str(card.bonus_kind).upper(), int(card.bonus_icons))

    

    # --- Special counters / markers ---
    def get_character_counter(self, cid: CharacterId, key: str, default: int = 0) -> int:
        ch = (getattr(self, 'characters', {}) or {}).get(str(cid).upper())
        if not ch:
            return int(default)
        d = getattr(ch, 'counters', None)
        if not isinstance(d, dict):
            return int(default)
        try:
            return int(d.get(str(key).upper(), default) or 0)
        except Exception:
            return int(default)

    def set_character_counter(self, cid: CharacterId, key: str, value: int) -> None:
        ch = (getattr(self, 'characters', {}) or {}).get(str(cid).upper())
        if not ch:
            return
        if not isinstance(getattr(ch, 'counters', None), dict):
            ch.counters = {}
        ch.counters[str(key).upper()] = int(value)

    def inc_character_counter(self, cid: CharacterId, key: str, delta: int = 1, *, cap: int | None = None) -> int:
        cur = self.get_character_counter(cid, key, 0)
        nxt = int(cur) + int(delta)
        if cap is not None:
            try:
                nxt = min(int(cap), nxt)
            except Exception:
                pass
        if nxt < 0:
            nxt = 0
        self.set_character_counter(cid, key, nxt)
        return nxt


    # --- Annihilation helpers ---
    def annihilate_character(self, cid: CharacterId, *, reason: str = "") -> None:
        """Aniquila un Character y todo lo que contiene.

        Regla: cuando un Character es ANNIHILATED, también se ANNIHILATED
        sus posesiones (al menos Items; en el prototipo también vaciamos Data).
        """
        if cid not in self.characters:
            raise KeyError(cid)
        ch = self.characters[cid]
        if getattr(ch, 'annihilated', False):
            return        # Mueve inventario a OUT_OF_GAME_SECTION (fuera del juego)
        inv0 = list(getattr(ch, 'items', []) or [])

        # RM 7.3.3: si Antimatter fuera a ser ANNIHILATED, detona inmediatamente.
        if inv0 and not bool(getattr(self, 'antimatter_detonated', False)):
            for _iid in inv0:
                _iid_u = str(_iid).upper()
                it = getattr(self, 'items', {}).get(_iid_u)
                if it and _norm(getattr(it, 'kind', '')) == 'ANTIMATTER':
                    try:
                        self.detonate_antimatter_now(
                            reason=f"would be annihilated with {str(cid).upper()}",
                            override_section=str(getattr(ch, 'section', '')).upper() or None,
                        )
                    except Exception:
                        pass
                    break

        # Recalcular inventario tras posible detonación (Antimatter se retira)
        inv = list(getattr(ch, 'items', []) or [])
        if inv:
            self.section_items.setdefault(OUT_OF_GAME_SECTION, []).extend(inv)
            ch.items = []

        # Vaciamos Data “en la carta” (en prototipo, la carta sale del juego)
        try:
            ch.data = {}
        except Exception:
            pass


        ch.escaped = False
        ch.annihilated = True
        ch.status = "DOWN"
        ch.section = OUT_OF_GAME_SECTION
    def is_pc(self, cid: CharacterId) -> bool:
        for p in self.players:
            if p.revealed_character == cid:
                return True
        ch = self.characters.get(cid)
        return bool(ch and ch.pc_owner is not None)

    def pc_owner_pid(self, cid: CharacterId) -> Optional[PlayerId]:
        for p in self.players:
            if p.revealed_character == cid:
                return p.pid
        ch = self.characters.get(cid)
        return ch.pc_owner if ch else None

    # --- Activation Disc helpers (para "exhausted") ---
    def activation_discs_on(self, cid: CharacterId) -> List[PlayerId]:
        """Devuelve los PlayerId cuyos discos de activación están sobre ese Character."""
        res: List[PlayerId] = []
        for p in self.players:
            if getattr(p, "activation_disc", None) == cid:
                res.append(p.pid)
        return res

    def has_activation_disc(self, cid: CharacterId) -> bool:
        return bool(self.activation_discs_on(cid))

    # --- Turn helpers ---
    def current_player(self) -> PlayerState:
        return self.players[self.current_player_index]

    # --- Time Markers (RM 15.7) ---
    def time_markers_on_board(self, pid: PlayerId) -> int:
        """Cuántos Time Markers de pid están actualmente colocados en el tablero."""
        return len([tm for tm in getattr(self, 'time_markers', []) if getattr(tm, 'owner', None) == pid])

    def time_markers_available(self, pid: PlayerId) -> int:
        """Cuántos Time Markers le quedan a pid en su supply."""
        p = self.player_by_id(pid)
        total = int(getattr(p, 'time_markers_total', 3))
        return max(0, total - self.time_markers_on_board(pid))


    def place_time_marker(
        self,
        pid: PlayerId,
        kind: str,
        location: str,
        target: str,
        *,
        due_minute: Optional[int] = None,
        ignore_supply: bool = False,
    ) -> TimeMarker:
        """Coloca un Time Marker del jugador pid.

        - RM 15.7.1: si el marker está "en el tablero" (no Minute track), se Resuelve
          al final de tu turno si fue colocado en un Minute anterior.
        - RM 15.7.2: si el marker está en el Minute track, debe tener `due_minute` y
          se Resuelve al final de tu turno en ESE Minute.

        `ignore_supply=True` se usa solo para efectos obligatorios (p.ej. Antimatter).
        """
        loc_u = str(location).upper()

        if (not ignore_supply) and self.time_markers_available(pid) <= 0:
            raise ValueError('No te quedan Time Markers disponibles.')

        if loc_u == 'MINUTE_TRACK' and due_minute is None:
            raise ValueError('Time Marker en Minute track requiere due_minute.')

        mid = int(getattr(self, 'next_time_marker_id', 1))
        self.next_time_marker_id = mid + 1

        tm = TimeMarker(
            mid=mid,
            owner=pid,
            kind=str(kind).upper(),
            location=loc_u,
            target=str(target).upper(),
            placed_minute=int(getattr(self, 'minute', 0)),
            due_minute=(int(due_minute) if due_minute is not None else None),
        )
        self.time_markers.append(tm)
        return tm

    def time_markers_due_for_player(self, pid: PlayerId) -> List[TimeMarker]:
        """Devuelve los Time Markers de pid que deben resolverse al final de ESTE turno.

        RM 15.7.1: "Remove any of your time markers on the board placed during a previous Minute and Resolve the event."
        """
        cur_min = int(getattr(self, 'minute', 0))
        due: List[TimeMarker] = []
        for tm in list(getattr(self, 'time_markers', [])):
            if getattr(tm, 'owner', None) != pid:
                continue
            loc = str(getattr(tm, 'location', '')).upper()
            placed_min = int(getattr(tm, 'placed_minute', -999))

            # RM 15.7.1: markers "en el tablero" (no Minute track) colocados en un Minute anterior.
            # En este prototipo el contador de Minute va hacia atrás (9->0),
            # así que "Minute anterior" significa placed_minute > current_minute.
            if loc != 'MINUTE_TRACK' and placed_min > cur_min:
                due.append(tm)

            # RM 15.7.2: si tu marker está en el Minute track, se Resuelve al final de tu turno en ESE Minute.
            if loc == 'MINUTE_TRACK':
                dm = getattr(tm, 'due_minute', None)
                if dm is not None and int(dm) == cur_min:
                    due.append(tm)

        return sorted(due, key=lambda x: int(getattr(x, 'mid', 0)))

    def resolve_time_marker(self, marker_id: int) -> str:
        """Retira y resuelve un Time Marker por id."""
        mid = int(marker_id)
        tm: TimeMarker | None = None
        for x in list(getattr(self, 'time_markers', [])):
            if int(getattr(x, 'mid', -1)) == mid:
                tm = x
                break
        if tm is None:
            raise ValueError('Time Marker no existe.')

        # Retirar del tablero ANTES de resolver (RM 15.7.1)
        self.time_markers = [x for x in self.time_markers if int(getattr(x, 'mid', -1)) != mid]

        kind = str(getattr(tm, 'kind', '')).upper()
        if kind == 'TIMED_LAUNCH':
            pod_sec = str(getattr(tm, 'target', '')).upper()
            # Si el Pod ya no está ON_BOARD (o no existe), el evento no tiene efecto.
            pod = getattr(self, 'pods', {}).get(pod_sec)
            if not pod or getattr(pod, 'location', None) != 'ON_BOARD':
                return f"RESOLVE: Timed Launch en {pod_sec} no tiene efecto (Pod no está ON_BOARD)."
            try:
                return self.launch_pod(pod_sec, source='TIMED LAUNCH (resolve)')
            except Exception as e:
                return f"RESOLVE: Timed Launch en {pod_sec} falló: {e}"
        if kind == 'ANTIMATTER':
            # RM 7.3.1: detona cuando el marker del Minute track se Resuelve.
            return self.detonate_antimatter_now(reason='timer resolved')

        if kind == AB.OVERLOAD:
            tgt = str(getattr(tm, 'target', '')).upper()

            # Si el objetivo es un Pod que ya se lanzó a Mesosphere antes de resolver,
            # el Pod queda ANNIHILATED cuando se resuelve el marker (Engineer dossier).
            pod = (getattr(self, 'pods', {}) or {}).get(tgt)
            if pod is not None:
                loc = str(getattr(pod, 'location', 'ON_BOARD')).upper()
                if loc == 'MESO':
                    # Aniquilar el Pod y todo lo que contiene.
                    try:
                        pod.location = 'ANNIHILATED'
                    except Exception:
                        pass

                    inside = [ch for ch in getattr(self, 'characters', {}).values()
                              if str(getattr(ch, 'section', '')).upper() == tgt and not bool(getattr(ch, 'annihilated', False))]
                    for ch in inside:
                        try:
                            self.annihilate_character(ch.cid, reason=f"OVERLOAD: Pod {tgt} (Mesosphere)")
                        except Exception:
                            pass

                    # Items sueltos en el Pod: si hay Antimatter, NO se aniquila; detona (RM 7.3.3).
                    try:
                        loose = list((getattr(self, 'section_items', {}) or {}).get(tgt, []) or [])
                        if loose and not bool(getattr(self, 'antimatter_detonated', False)):
                            for _iid in loose:
                                _iid_u = str(_iid).upper()
                                it = (getattr(self, 'items', {}) or {}).get(_iid_u)
                                if it and _norm(getattr(it, 'kind', '')) == 'ANTIMATTER':
                                    try:
                                        self.detonate_antimatter_now(
                                            reason=f"OVERLOAD: would be annihilated in Pod {tgt} (Mesosphere)",
                                            override_section=tgt,
                                        )
                                    except Exception:
                                        pass
                                    break

                        # Tras posible detonación, mover el resto fuera del juego.
                        if tgt in (getattr(self, 'section_items', {}) or {}):
                            rest = list((getattr(self, 'section_items', {}) or {}).get(tgt, []) or [])
                            if rest:
                                self.section_items.setdefault(OUT_OF_GAME_SECTION, []).extend(rest)
                            (getattr(self, 'section_items', {}) or {}).pop(tgt, None)
                    except Exception:
                        pass

                    return f"RESOLVE: Overload -> Pod {tgt} en MESO queda ANNIHILATED | dentro={len(inside)}"

                if loc != 'ON_BOARD':
                    return f"RESOLVE: Overload -> sin efecto (Pod {tgt} no está ON_BOARD/MESO; estado={loc})."

            # Sección normal (o Pod ON_BOARD): se daña.
            try:
                changed = self.damage_section(tgt)
                if changed:
                    return f"RESOLVE: Overload -> {tgt} queda DAMAGED."
                return f"RESOLVE: Overload -> {tgt} ya estaba DAMAGED."
            except Exception as e:
                return f"RESOLVE: Overload -> error dañando {tgt}: {e}"

        return f"RESOLVE: (sin implementación) Time Marker {mid} kind={kind}."

    def start_player_turn(self) -> None:
        # Si estamos cargando un SAVE en mitad de un turno, NO debemos resetear el turno.
        if bool(getattr(self, 'turn_in_progress', False)):
            return

        self.turn_in_progress = True
        # Mantener el flag "exhausted" sincronizado con la posición de los discos.
        # (Compatibilidad con UI/prints antiguos.)
        self.refresh_exhausted_flags()
        cp = self.current_player()
        cp.turn_influence_target = None
        cp.turn_renegotiated = False
        cp.turn_bribe_attempted = False
        cp.turn_kompromat_attempted = False

        self.active_character_id = None
        self.action_points_total = 0
        self.action_points_used = 0
        self.free_pickdrop_used = False
        self.turn_log = []


        # Reset Drag-per-player-turn flags (12.1.2)
        for ch in self.characters.values():
            ch.has_dragged_this_turn = False
            ch.dragged_this_turn = False

    def end_player_turn(self) -> None:
        # Importante: un Character NO queda "exhausted" permanentemente.
        # La limitación de 1 acción al activar se modela por la presencia de
        # Activation Disc(s) en la carta antes de activar.
        self.active_character_id = None
        self.action_points_total = 0
        self.action_points_used = 0
        self.free_pickdrop_used = False
        self.turn_in_progress = False

    def advance_player(self) -> None:
        self.current_player_index = (self.current_player_index + 1) % len(self.players)

    def advance_minute(self) -> List[str]:
        """Avanza el Minute track (cuenta atrás 9 -> 0) y resuelve triggers de fin.

        Regla (versión simplificada para el prototipo):
        - Al ENTRAR en Minute 0 (paso 1->0), se revela el Re-entry token.
            * STATIONFALL: se dispara inmediatamente.
            * SAFE: se juega el Minute 0 normal; Stationfall se dispara al final del Minute 0.
        - Al FINALIZAR el Minute 0 (cuando "bajaría" a -1), se dispara Stationfall si el token era SAFE.

        Devuelve mensajes para imprimirlos en main.
        """
        msgs: List[str] = []
        try:
            prev = int(getattr(self, 'minute', 0))
        except Exception:
            prev = 0

        # Si Stationfall ya terminó la partida, no hacemos nada.
        if bool(getattr(self, 'game_over', False)):
            return msgs

        if prev > 0:
            self.minute = max(0, prev - 1)

            # RM 7.1.2: Abandon Ship se dispara automáticamente cuando el Minute marker llega a "1".
            # En nuestro contador, eso ocurre cuando pasamos de 2 -> 1 al final del round.
            if prev == 2 and self.minute == 1 and (not bool(getattr(self, 'abandon_ship', False))):
                try:
                    changed = self.set_abandon_ship(True) if hasattr(self, 'set_abandon_ship') else False
                except Exception:
                    changed = False
                    self.abandon_ship = True
                if changed or bool(getattr(self, 'abandon_ship', False)):
                    msgs.append("🚨 Minute 1 alcanzado: se dispara Abandon Ship automáticamente (RM 7.1.2).")
                    try:
                        self.turn_log.append(msgs[-1])
                    except Exception:
                        pass

            # Entramos en Minute 0 (1->0): revelar token.
            if prev == 1 and self.minute == 0:
                tok = self.reveal_reentry_token() if not bool(getattr(self, 'reentry_revealed', False)) else str(getattr(self, 'reentry_token', 'STATIONFALL')).upper()
                tok_txt = 'STATIONFALL' if tok == 'STATIONFALL' else 'SAFE (no pasa nada)'
                msgs.append(f"🎲 Re-entry token revelado en Minute 0: {tok_txt}.")
                try:
                    self.turn_log.append(msgs[-1])
                except Exception:
                    pass

                if tok == 'STATIONFALL':
                    msgs.append(self.trigger_stationfall('RE-ENTRY TOKEN (Minute 0)'))

            return msgs

        # prev == 0: esto representa "fin del Minute 0" (paso hacia -1).
        if bool(getattr(self, 'reentry_revealed', False)) and str(getattr(self, 'reentry_token', '')).upper() == 'SAFE':
            if not bool(getattr(self, 'stationfall_triggered', False)):
                msgs.append(self.trigger_stationfall('END OF MINUTE 0'))
        return msgs

    # --- Exhausted (compatibilidad): depende de Activation Discs ---
    def refresh_exhausted_flags(self) -> None:
        # Conteo de discos por Character.
        disc_counts: Dict[CharacterId, int] = {}
        for p in self.players:
            ad = getattr(p, 'activation_disc', None)
            if ad:
                disc_counts[ad] = disc_counts.get(ad, 0) + 1

        for cid, ch in self.characters.items():
            # Por defecto: Exhausted con 1+ disco.
            # UNCANNY (Cyborg): Exhausted solo con 2+ discos.
            need = 2 if ch.has_ability(AB.UNCANNY) else 1
            ch.exhausted = disc_counts.get(cid, 0) >= need

    # --- Influence helpers ---
    def influence_of(self, pid: PlayerId, cid: CharacterId) -> int:
        return self.influence.get(pid, {}).get(cid, 0)

    def set_influence_of(self, pid: PlayerId, cid: CharacterId, n: int) -> None:
        if pid not in self.influence:
            self.influence[pid] = {}
        self.influence[pid][cid] = max(0, n)

    def conspirators_of(self, pid: PlayerId) -> List[CharacterId]:
        res: List[CharacterId] = []
        for cid, ch in self.characters.items():
            # Conspirators: solo LIVE y no Escaped/Annihilated
            if not ch.is_live():
                continue
            if ch.is_escaped() or ch.is_annihilated():
                continue

            vals = [self.influence_of(p.pid, cid) for p in self.players]
            m = max(vals) if vals else 0
            if m == 0:
                continue
            if self.influence_of(pid, cid) == m:
                res.append(cid)

        # Tu PC LIVE y no Escaped/Annihilated (si ya lo revelaste) también cuenta
        p = self.player_by_id(pid)
        if p.revealed_character is not None:
            pcid = p.revealed_character
            if pcid in self.characters:
                pc = self.characters[pcid]
                if pc.is_live() and (not pc.is_escaped()) and (not pc.is_annihilated()) and pcid not in res:
                    res.append(pcid)

        return sorted(res)

    def is_conspirator(self, pid: PlayerId, cid: CharacterId) -> bool:
        return cid in self.conspirators_of(pid)

    # --- Troubleshooter (Character Dossier): Reveal Power — Talk Them Through It ---
    def troubleshooter_talk_them_through_it_active(self, pid: PlayerId) -> bool:
        """True si `pid` ha revelado un PC con TALK_THEM_THROUGH_IT y ese PC está LIVE.

        Efecto (Dossier): Durante tu turno, si tu PC con TALK_THEM_THROUGH_IT está LIVE,
        tus Conspirators se mueven y actúan como si tuvieran JURY RIG y TUNNEL RAT.
        """
        try:
            p = self.player_by_id(pid)
        except Exception:
            return False

        pcid = getattr(p, 'revealed_character', None)
        if not pcid:
            return False

        pcid_u = str(pcid).upper()
        pc = getattr(self, 'characters', {}).get(pcid_u)
        if pc is None:
            return False

        # Debe pertenecer a pid
        if str(getattr(pc, 'pc_owner', '')) != str(pid):
            return False

        # Debe estar LIVE (RM 4.6: Escaped puede seguir siendo LIVE, y cuenta como LIVE).
        try:
            if not pc.is_live():
                return False
        except Exception:
            if str(getattr(pc, 'status', '')).upper() != 'LIVE' or bool(getattr(pc, 'annihilated', False)):
                return False

        # Debe tener la habilidad (normalmente ganada al Reveal).
        try:
            if not pc.has_ability(AB.TALK_THEM_THROUGH_IT):
                return False
        except Exception:
            # fallback defensivo: mirar set crudo
            try:
                abil = getattr(pc, 'abilities', set()) or set()
                if _norm(AB.TALK_THEM_THROUGH_IT) not in {_norm(x) for x in abil}:
                    return False
            except Exception:
                return False

        return True


    def effective_has_ability(self, cid: CharacterId, ability: str, *, acting_pid: Optional[PlayerId] = None) -> bool:
        """Chequeo de habilidad con efectos temporales.

        Implementado:
          - Troubleshooter (Reveal Power): durante el turno del dueño, sus Conspirators actúan
            como si tuvieran JURY RIG y TUNNEL RAT mientras Troubleshooter esté LIVE.
        """
        cu = str(cid).upper()
        ab = str(ability or '')
        ch = getattr(self, 'characters', {}).get(cu)
        if ch is None:
            return False

        # Normal
        try:
            if ch.has_ability(ab):
                return True
        except Exception:
            pass

        want = _norm(ab)
        # Compat: algunos saves antiguos podían guardar "TUNNELRAT" como alias.
        if want not in {_norm(AB.JURY_RIG), _norm(AB.TUNNEL_RAT), _norm('TUNNELRAT')}:
            return False

        # Determinar jugador que está actuando
        pid = acting_pid
        if pid is None:
            try:
                pid = self.current_player().pid
            except Exception:
                pid = None
        if pid is None:
            return False

        # Solo durante SU turno
        try:
            if str(self.current_player().pid) != str(pid):
                return False
        except Exception:
            pass

        # Solo para Conspirators
        try:
            if not bool(self.is_conspirator(pid, cu)):
                return False
        except Exception:
            return False

        if not self.troubleshooter_talk_them_through_it_active(pid):
            return False

        return True

    # --- Action economy helpers ---
    def remaining_actions(self) -> int:
        return max(0, self.action_points_total - self.action_points_used)

    def spend_action_point(self, n: int = 1) -> None:
        # Algunos poderes permiten una acción realmente gratis (no consume AP).
        # Se implementa con un flag interno temporal.
        if bool(getattr(self, '_suppress_action_point_spend', False)):
            return
        self.action_points_used += n

    def require_active(self) -> CharacterId:
        if self.active_character_id is None:
            raise ValueError("No active character")
        if self.active_character_id not in self.characters:
            raise ValueError("Active character no existe")
        ch = self.characters[self.active_character_id]
        # RM 4.6.5.2 / 4.6.6.2: no acciones con/contra Annihilated/Escaped
        if ch.is_annihilated():
            raise ValueError("El personaje activo está ANNIHILATED (fuera del juego).")
        if ch.is_escaped():
            raise ValueError("El personaje activo está ESCAPED (no puedes hacer acciones con él).")
        if not ch.is_live():
            raise ValueError("El personaje activo no está LIVE.")

        # Homebrew: Tripa del Tentacled.
        # Todo lo que esté ahí NO puede interactuar con nada (no puede hacer acciones).
        if self.is_tentaculous_gut(getattr(ch, 'section', '')):
            raise ValueError("El personaje activo está en la TRIPA DEL TENTACULOUS: no puede hacer acciones ni interactuar con nada.")
        return self.active_character_id

    def can_receive_item(self, cid: CharacterId, add: int = 1) -> bool:
        ch = self.characters[cid]
        # Contamination ocupa 1 slot (RM 8.5.1).
        used = ch.inventory_count() + (1 if bool(getattr(ch, 'contaminated', False)) else 0)
        return (used + add) <= ch.item_limit

    # --- Contamination (RM 8.5.1 / 13.4) ---
    def is_contamination_section(self, sec: SectionId) -> bool:
        s = str(sec).upper()
        return s in {str(x).upper() for x in getattr(self, 'contamination_sections', set())}

    def apply_contamination_on_enter(self, cid: CharacterId, *, reason: str = "ENTER") -> List[str]:
        """Aplica Contamination si el Character está en una sección contaminada.

        - No acumula (máx 1 token por Character).
        - Si al ganar Contamination no hay slots libres, el jugador activo debe dropear 1 Item gratis.
          La elección se encola en `pending_free_drop_queue` para que el UI pregunte.
        """
        msgs: List[str] = []
        if cid not in self.characters:
            return msgs
        ch = self.characters[cid]
        if ch.is_annihilated() or ch.is_escaped():
            return msgs

        sec = str(getattr(ch, 'section', '')).upper()
        if not sec or not self.is_contamination_section(sec):
            return msgs

        # Bio Lab (mapa básico): al entrar te contaminas salvo si hay FIRE en la sección.
        if sec == "BIO_LAB" and self.has_hazard_kind(sec, "FIRE"):
            return msgs

        if bool(getattr(ch, 'contaminated', False)):
            return msgs

        ch.contaminated = True
        msgs.append(f"☣ CONTAMINATION: {cid} se contamina en {sec} (ocupa 1 slot)")

        # Si ya ibas con inventario lleno, ahora debes dropear 1 item gratis.
        # (Condición: items + 1 > limit)  <=> items >= limit
        if getattr(ch, 'item_limit', None) is not None:
            if len(getattr(ch, 'items', []) or []) >= int(ch.item_limit):
                if getattr(ch, 'items', None):
                    self.pending_free_drop_queue.append({"cid": str(cid).upper(), "reason": "CONTAMINATION"})
                    msgs.append("🆓 Inventario lleno: debes dropear 1 item gratis")

        return msgs


    # --- Gravity (prototipo) ---
    def section_has_gravity(self, sec: SectionId) -> bool:
        """Devuelve True si la sección tiene gravedad.

        - Por defecto: True.
        - Si la sección está marcada como 0G en `zero_g_sections`: False.
        - Los Pods SIEMPRE se consideran 0G.
        """
        s = str(sec).upper()
        if s in getattr(self, 'pods', {}):
            return False
        zg = {str(x).upper() for x in getattr(self, 'zero_g_sections', set())}
        return s not in zg

    def set_section_gravity(self, sec: SectionId, has_gravity: bool) -> None:
        """Marca una sección como con/sin gravedad (solo data, por ahora)."""
        s = str(sec).upper()
        if not hasattr(self, 'zero_g_sections') or getattr(self, 'zero_g_sections', None) is None:
            self.zero_g_sections = set()
        if has_gravity:
            self.zero_g_sections = {x for x in self.zero_g_sections if str(x).upper() != s}
        else:
            self.zero_g_sections.add(s)


    # --- Item location helpers ---
    def item_location(self, iid: ItemId) -> tuple[str, str]:
        """Devuelve la localización pública del item.

        Retorna ("CHAR", cid) si lo posee un Character, ("SEC", sec) si está en una sección,
        o ("NONE", "") si no se encuentra.
        """
        iid = str(iid).upper()

        for cid, ch in getattr(self, 'characters', {}).items():
            if iid in [str(x).upper() for x in getattr(ch, 'items', [])]:
                return ("CHAR", str(cid).upper())

        for sec, arr in getattr(self, 'section_items', {}).items():
            if iid in [str(x).upper() for x in arr]:
                return ("SEC", str(sec).upper())

        return ("NONE", "")

    def annihilate_item(self, iid: ItemId, *, reason: str = "") -> None:
        """Saca un Item del juego (ANNIHILATED).

        En este prototipo, lo movemos a OUT_OF_GAME_SECTION (para debug)
        y lo retiramos de cualquier inventario/sección.
        """
        iid = str(iid).upper()

        # Quitar de inventarios
        for cid, ch in getattr(self, "characters", {}).items():
            inv = list(getattr(ch, "items", []) or [])
            if any(str(x).upper() == iid for x in inv):
                ch.items = [x for x in inv if str(x).upper() != iid]

        # Quitar de secciones
        for sec in list(getattr(self, "section_items", {}).keys()):
            arr = list(getattr(self, "section_items", {}).get(sec, []) or [])
            if any(str(x).upper() == iid for x in arr):
                new_arr = [x for x in arr if str(x).upper() != iid]
                if new_arr:
                    self.section_items[str(sec).upper()] = new_arr
                else:
                    self.section_items.pop(str(sec).upper(), None)

        # Guardarlo fuera del juego (evitar duplicados)
        og = self.section_items.setdefault(OUT_OF_GAME_SECTION, [])
        if not any(str(x).upper() == iid for x in og):
            og.append(iid)

        # Log
        if reason:
            try:
                self.turn_log.append(f"ITEM ANNIHILATED: {iid} ({reason})")
            except Exception:
                pass

    def mint_item_id(self) -> ItemId:
        """Genera un nuevo ItemId del tipo I<n> (simple, monotónico)."""
        import re

        existing = [str(x).upper() for x in getattr(self, 'items', {}).keys()]
        mx = 0
        for iid in existing:
            m = re.match(r"^I(\d+)$", iid)
            if m:
                try:
                    mx = max(mx, int(m.group(1)))
                except Exception:
                    pass
        return f"I{mx + 1}"

    def grant_item_to_character_from_reveal_power(self, cid: CharacterId, grant: ItemGrant) -> ItemId:
        """Crea un Item nuevo y lo pone directamente en la posesión del Character."""
        new_iid = self.mint_item_id()
        self.items[new_iid] = Item(
            iid=new_iid,
            name=str(getattr(grant, 'name', 'Item')),
            kind=str(getattr(grant, 'kind', 'item')),
            charges=int(getattr(grant, 'charges', 0) or 0),
            kompromat_target=getattr(grant, 'kompromat_target', None),
            armed=bool(getattr(grant, 'armed', False)),
        )
        self.characters[cid].items.append(new_iid)
        return new_iid

    def apply_pc_reveal_item_grants(self, revealing_pid: PlayerId, pcid: CharacterId) -> List[str]:
        """Aplica los Reveal Powers que proporcionan Items (RM 4.5.3.1).

        Regla: si un Reveal Power proporciona un Item y el Character ya está en su
        Item Limit, debe dropear inmediatamente 1 Item a elección del jugador que
        revela.

        En el prototipo:
        - Primero añadimos el Item a la posesión del PC.
        - Si eso deja al Character por encima del límite, encolamos un "free drop"
          (sin coste) para que el UI pida la elección.
        """
        msgs: List[str] = []
        pcid = str(pcid).upper()
        if pcid not in getattr(self, 'characters', {}):
            return msgs

        ch = self.characters[pcid]
        grants = list(getattr(ch, 'pc_reveal_item_grants', []) or [])
        if not grants:
            return msgs

        for g in grants:
            new_iid = self.grant_item_to_character_from_reveal_power(pcid, g)
            it = self.items.get(new_iid)
            nm = getattr(it, 'name', new_iid) if it else new_iid
            msgs.append(f"🎁 Reveal Power: {pcid} gana {new_iid} ({nm})")

            # Check overflow vs Item Limit. Contamination ocupa 1 slot (RM 8.5.1).
            used = len(getattr(ch, 'items', []) or []) + (1 if bool(getattr(ch, 'contaminated', False)) else 0)
            lim = int(getattr(ch, 'item_limit', 0) or 0)
            if used > lim and len(getattr(ch, 'items', []) or []) > 0:
                self.pending_free_drop_queue.append({"cid": pcid, "reason": "REVEAL_POWER_ITEM"})
                msgs.append(f"🆓 Item Limit: dropea 1 item gratis (elige {revealing_pid})")

        return msgs

    def apply_pc_reveal_ability_grants(self, pcid: CharacterId) -> list[str]:
        """Aplica *grants* de habilidades al hacer Reveal como PC.

        En este proyecto, las habilidades "que se ganan al Reveal" NO son un tipo distinto:
        son habilidades normales del diccionario, simplemente listadas en `pc_reveal_abilities`
        para que se añadan a `abilities` en el momento del Reveal (si ocurre antes de Stationfall).
        """
        msgs: list[str] = []
        pcid_u = str(pcid).upper()
        if pcid_u not in getattr(self, 'characters', {}):
            return msgs
        ch = self.characters[pcid_u]

        grants = set(getattr(ch, 'pc_reveal_abilities', set()) or set())
        if not grants:
            return msgs

        # Idempotente: sólo añadimos las que no estén ya.
        already = set(getattr(ch, 'abilities', set()) or set())
        to_add = set(grants) - set(already)
        if to_add:
            try:
                ch.abilities |= set(to_add)
            except Exception:
                try:
                    for a in to_add:
                        ch.abilities.add(a)
                except Exception:
                    pass

        # NO limpiamos `pc_reveal_abilities`: lo tratamos como "lista de carta" para UI.
        # (La aplicación es idempotente y el Reveal sólo ocurre una vez.)

        shown = sorted([str(a) for a in grants])
        msgs.append("🧠 Reveal: " + pcid_u + " gana habilidades: " + ", ".join(shown))
        try:
            self.turn_log.append(msgs[-1])
        except Exception:
            pass
        return msgs

    def apply_pc_reveal_auto_powers(self, revealing_pid: PlayerId, pcid: CharacterId) -> List[str]:
        """Aplica Reveal Powers automáticos (sin elección).

        Sólo se llama cuando el Reveal ocurre durante juego normal (NO en Stationfall).
        """
        msgs: List[str] = []
        pcid = str(pcid).upper()
        if pcid not in getattr(self, 'characters', {}):
            return msgs

        ch = self.characters[pcid]
        powers = set(getattr(ch, 'pc_reveal_powers', set()) or set())
        if not powers:
            return msgs

        # Record of what has already been resolved (for UI + idempotency).
        res = getattr(ch, 'pc_reveal_power_resolution', None)
        if not isinstance(res, dict):
            try:
                ch.pc_reveal_power_resolution = {}
            except Exception:
                pass
            res = getattr(ch, 'pc_reveal_power_resolution', {})

        # Security: AUTHORIZED_FORCE -> pierde PEACEKEEPER al revelarse.
        if any(str(p).upper() == AB.AUTHORIZED_FORCE for p in powers) and (str(AB.AUTHORIZED_FORCE).upper() not in (res or {})):
            try:
                if AB.PEACEKEEPER in (getattr(ch, 'abilities', set()) or set()):
                    ch.abilities.discard(AB.PEACEKEEPER)
            except Exception:
                pass
            msg = f"REVEAL POWER: Authorized Force -> {pcid} pierde PEACEKEEPER."
            msgs.append(msg)
            try:
                self.turn_log.append(msg)
            except Exception:
                pass
            try:
                res[str(AB.AUTHORIZED_FORCE).upper()] = 'ACTIVATED'
            except Exception:
                pass

        # Medical: HAYWIRE (Character Dossier)
        # Efecto: al revelarse, gana 1 Bludgeon.
        if any(str(p).upper() == AB.HAYWIRE for p in powers) and (str(AB.HAYWIRE).upper() not in (res or {})):
            try:
                # Sin efecto si está fuera del juego.
                if bool(getattr(ch, 'annihilated', False)) or bool(getattr(ch, 'escaped', False)):
                    pass
                else:
                    grant = ItemGrant(name='Bludgeon', kind='item')
                    new_iid = self.grant_item_to_character_from_reveal_power(pcid, grant)
                    it = self.items.get(new_iid)
                    nm = getattr(it, 'name', new_iid) if it else new_iid
                    msg = f"REVEAL POWER: Haywire -> {pcid} gana {new_iid} ({nm})."
                    msgs.append(msg)
                    try:
                        self.turn_log.append(msg)
                    except Exception:
                        pass

                    # Item Limit overflow: Contamination ocupa 1 slot (RM 8.5.1).
                    used = len(getattr(ch, 'items', []) or []) + (1 if bool(getattr(ch, 'contaminated', False)) else 0)
                    lim = int(getattr(ch, 'item_limit', 0) or 0)
                    if used > lim and len(getattr(ch, 'items', []) or []) > 0:
                        self.pending_free_drop_queue.append({"cid": pcid, "reason": "REVEAL_POWER_ITEM"})
                        msgs.append(f"🆓 Item Limit: dropea 1 item gratis (elige {revealing_pid})")
            except Exception:
                pass
            try:
                res[str(AB.HAYWIRE).upper()] = 'ACTIVATED'
            except Exception:
                pass

        return msgs


    # --- Reveal Powers (RM 4.5) ---
    def enqueue_pc_reveal_powers(self, revealing_pid: PlayerId, pcid: CharacterId) -> None:
        """Encola Reveal Powers de un solo uso que requieren elección inmediata.

        Se llama tras un Reveal normal (NO durante Stationfall). El UI debe
        resolver `pending_reveal_power_queue` justo después del Reveal.
        """
        pcid = str(pcid).upper()
        if pcid not in getattr(self, 'characters', {}):
            return
        ch = self.characters[pcid]

        powers = set(getattr(ch, 'pc_reveal_powers', set()) or set())
        if not powers:
            return

        # No re-encolar powers ya resueltos (para soportar save/load y para UI).
        res = getattr(ch, 'pc_reveal_power_resolution', None)
        if isinstance(res, dict) and res:
            done = {str(k).upper() for k in res.keys()}
            powers = {p for p in powers if str(p).upper() not in done}
            if not powers:
                return

        # Counselor: RECORDED_CONFESSIONAL (Character Dossier)
        if any(str(p).upper() == AB.RECORDED_CONFESSIONAL for p in powers):
            # Condición: al revelarse, el PC debe estar LIVE.
            if not ch.is_live():
                return
            sec = str(getattr(ch, 'section', '')).upper()
            targets: list[str] = []
            for cid2, c2 in getattr(self, 'characters', {}).items():
                cid2u = str(cid2).upper()
                if cid2u == pcid:
                    continue
                if 'HUMAN' not in str(getattr(c2, 'ctype', '')).upper():
                    continue
                if c2.is_annihilated() or c2.is_escaped():
                    continue
                if self.colocated(pcid, cid2u):
                    targets.append(cid2u)

            if targets:
                self.pending_reveal_power_queue.append({
                    'power': AB.RECORDED_CONFESSIONAL,
                    'revealing_pid': str(revealing_pid),
                    'pcid': pcid,
                    'section': sec,
                    'targets': sorted(set(targets)),
                })

        # Engineer: OVERLOAD (Character Dossier)
        if any(str(p).upper() == AB.OVERLOAD for p in powers):
            # Target: cualquier sección *Unescaped*. En el prototipo lo interpretamos
            # como cualquier Section ON_BOARD (RM 5.1.6).
            targets2: list[str] = []
            try:
                targets2 = sorted(set([str(s).upper() for s in self.on_board_sections()]))
            except Exception:
                targets2 = sorted(set([str(s).upper() for s in getattr(self, 'graph', {}).keys()]))

            # Filtrar secciones especiales / inválidas.
            clean: list[str] = []
            for sec2 in targets2:
                su = str(sec2).upper()
                if not su:
                    continue
                if su in (str(OUTER_SPACE_SECTION).upper(), str(OUT_OF_GAME_SECTION).upper(), 'MESO'):
                    continue
                clean.append(su)

            clean = sorted(set(clean))
            if clean:
                self.pending_reveal_power_queue.append({
                    'power': AB.OVERLOAD,
                    'revealing_pid': str(revealing_pid),
                    'pcid': pcid,
                    'targets': clean,
                })

        # Stowaway: SECRET_CACHE (Character Dossier)
        # Efecto: al revelarse, Stowaway o uno de tus Conspirators gana 1 Helmet.
        if any(str(p).upper() == AB.SECRET_CACHE for p in powers):
            candidates: list[str] = []
            # Siempre puedes elegirse a sí mismo.
            candidates.append(pcid)
            try:
                candidates.extend([str(x).upper() for x in self.conspirators_of(revealing_pid)])
            except Exception:
                pass

            valid3: list[str] = []
            for cid2 in candidates:
                cu = str(cid2).upper()
                if not cu or cu not in getattr(self, 'characters', {}):
                    continue
                ch2 = self.characters.get(cu)
                if ch2 is None:
                    continue
                if bool(getattr(ch2, 'annihilated', False)) or bool(getattr(ch2, 'escaped', False)):
                    continue
                valid3.append(cu)

            valid3 = sorted(set(valid3))
            if valid3:
                self.pending_reveal_power_queue.append({
                    'power': AB.SECRET_CACHE,
                    'revealing_pid': str(revealing_pid),
                    'pcid': pcid,
                    'targets': valid3,
                })

        # Stranger: HOMEWORK (Character Dossier)
        # Efecto: al revelarse, puedes revelar tu BC y hacer 1 acción con ese BC.
        if any(str(p).upper() == AB.HOMEWORK for p in powers):
            # Requiere BC asignado y Bonus Points no desactivados (no Schrödinger).
            pst = None
            for _p in getattr(self, 'players', []):
                if str(getattr(_p, 'pid', '')) == str(revealing_pid):
                    pst = _p
                    break

            bc = getattr(pst, 'bonus_character', None) if pst else None
            bd = bool(getattr(pst, 'bonus_points_disabled', False)) if pst else False
            if bc and (not bd):
                bc_u = str(bc).upper()
                if bc_u in getattr(self, 'characters', {}):
                    bc_ch = self.characters[bc_u]
                    # El BC debe poder actuar (LIVE y no fuera por ESCAPED/ANNIHILATED).
                    if bc_ch.is_live() and (not bc_ch.is_escaped()) and (not bc_ch.is_annihilated()):
                        self.pending_reveal_power_queue.append({
                            'power': AB.HOMEWORK,
                            'revealing_pid': str(revealing_pid),
                            'pcid': pcid,
                            'bcid': bc_u,
                        })




    def apply_recorded_confessional(self, revealing_pid: PlayerId, target_human: CharacterId) -> str:
        """Aplica el Reveal Power del Counselor: RECORDED_CONFESSIONAL.

        Efecto: todos los *otros* jugadores Innocent que tengan a `target_human`
        como Conspirator pasan a Suspect.
        """
        revealing_pid = str(revealing_pid)
        target = str(target_human).upper()
        changed: list[PlayerId] = []
        for p in self.players:
            if str(p.pid) == revealing_pid:
                continue
            if str(getattr(p, 'legal', '')).strip().lower() != 'innocent':
                continue
            try:
                is_cons = bool(self.is_conspirator(p.pid, target))
            except Exception:
                is_cons = False
            if is_cons:
                p.legal = 'Suspect'
                changed.append(p.pid)

        # Log
        tgt_name = ''
        try:
            c = self.characters.get(target)
            if c:
                tgt_name = str(getattr(c, 'name', '') or '')
        except Exception:
            tgt_name = ''

        if changed:
            lst = ', '.join([str(x) for x in changed])
            msg = f"REVEAL POWER: Recorded Confessional -> {lst} pasan a Suspect (target={target}{' ' + tgt_name if tgt_name else ''})."
        else:
            msg = f"REVEAL POWER: Recorded Confessional -> sin efecto (target={target}{' ' + tgt_name if tgt_name else ''})."

        try:
            self.turn_log.append(msg)
        except Exception:
            pass
        return msg

    def apply_overload(self, revealing_pid: PlayerId, target_section: SectionId) -> str:
        """Aplica el Reveal Power del Engineer: OVERLOAD.

        Efecto: al hacer Reveal como PC (fuera de Stationfall), coloca 1 Time Marker
        en una Section *Unescaped*. Cuando ese marker se resuelve, la Section se daña
        (se implementa en `resolve_time_marker`).
        """
        revealing_pid = str(revealing_pid)
        sec = str(target_section).upper()

        try:
            tm = self.place_time_marker(revealing_pid, kind=AB.OVERLOAD, location='SECTION', target=sec)
            msg = f"REVEAL POWER: Overload -> Time Marker {tm.mid} en {sec} (Damage al resolver)."
        except Exception as e:
            msg = f"REVEAL POWER: Overload -> no pudo colocar Time Marker en {sec}: {e}"

        try:
            self.turn_log.append(msg)
        except Exception:
            pass
        return msg

    def apply_secret_cache(self, revealing_pid: PlayerId, receiver_cid: CharacterId) -> str:
        """Aplica el Reveal Power del Stowaway: SECRET_CACHE.

        Efecto: al revelarse como PC (fuera de Stationfall), Stowaway o uno de tus
        Conspirators gana 1 Helmet. Si el receptor excede su Item Limit, debe
        dropear 1 Item gratis inmediatamente (RM 4.5.3.1).
        """
        revealing_pid = str(revealing_pid)
        rcid = str(receiver_cid).upper()
        if rcid not in getattr(self, 'characters', {}):
            return f"REVEAL POWER: Secret Cache -> objetivo inválido ({rcid})."

        ch = self.characters[rcid]
        if bool(getattr(ch, 'annihilated', False)) or bool(getattr(ch, 'escaped', False)):
            return f"REVEAL POWER: Secret Cache -> sin efecto (objetivo fuera del juego: {rcid})."

        grant = ItemGrant(name='Helmet', kind='item')
        new_iid = self.grant_item_to_character_from_reveal_power(rcid, grant)
        it = self.items.get(new_iid)
        nm = getattr(it, 'name', new_iid) if it else new_iid

        msg = f"REVEAL POWER: Secret Cache -> {rcid} gana {new_iid} ({nm})."

        # Item Limit overflow: Contamination ocupa 1 slot (RM 8.5.1).
        used = len(getattr(ch, 'items', []) or []) + (1 if bool(getattr(ch, 'contaminated', False)) else 0)
        lim = int(getattr(ch, 'item_limit', 0) or 0)
        if used > lim and len(getattr(ch, 'items', []) or []) > 0:
            self.pending_free_drop_queue.append({'cid': rcid, 'reason': 'REVEAL_POWER_ITEM'})
            msg += f" → Item Limit: dropea 1 item gratis (elige {revealing_pid})."

        try:
            self.turn_log.append(msg)
        except Exception:
            pass
        return msg



    def antimatter_id(self) -> Optional[ItemId]:
        for iid, it in getattr(self, 'items', {}).items():
            if _norm(getattr(it, 'kind', '')) == 'ANTIMATTER' or _norm(getattr(it, 'name', '')) == 'ANTIMATTER':
                return str(iid).upper()
        return None

    def arm_antimatter(self, acting_pid: PlayerId) -> str:
        """RM 7.3.1: Arming. Flip Antimatter, trigger Abandon Ship, y colocar Time Marker en Minute track."""
        aid = self.antimatter_id()
        if not aid:
            return "Antimatter: (no existe)"
        it = self.items.get(aid)
        if not it:
            return "Antimatter: (no existe)"

        if bool(getattr(it, 'armed', False)):
            return "Antimatter: ya estaba armed."

        it.armed = True

        # RM 7.3.1: trigger Abandon Ship.
        try:
            self.set_abandon_ship(True)
        except Exception:
            self.abandon_ship = True

        # RM 7.3.1: place the acting player's time marker 4 Minutes into the future.
        # Como el contador de Minute va hacia atrás (9->0), "en el futuro" equivale a restar.
        cur = int(getattr(self, 'minute', 0))
        due = cur - 4
        # Si no llega a resolverse antes de Stationfall, detonará en Stationfall.
        # Para el prototipo, lo aproximamos fijando el due_minute a 0 (último Minute).
        if due < 0:
            due = 0
        try:
            tm = self.place_time_marker(acting_pid, 'ANTIMATTER', 'MINUTE_TRACK', 'ANTIMATTER', due_minute=due, ignore_supply=True)
            mid = int(getattr(tm, 'mid', 0))
            return f"☢️  ANTIMATTER ARMED: se coloca Time Marker {mid} en Minute track (detona en minute {due}) y se dispara Abandon Ship."
        except Exception as e:
            return f"☢️  ANTIMATTER ARMED: (timer no colocado por error: {e}) y se dispara Abandon Ship."


    def detonate_antimatter_now(self, *, reason: str = "", override_section: Optional[SectionId] = None) -> str:
        """Detona Antimatter inmediatamente.

        RM 7.3.3: If Antimatter would be ANNIHILATED, it detonates immediately.
        RM 7.3.1: Antimatter also detonates when its Minute-track Time Marker resolves.

        Efectos (RM 7.3.2 / simplificado):
        - En Outer Space: aniquila todo lo que esté en Outer Space y DAÑA todas las secciones con flechas de Outer Space.
        - En un Pod en Mesosphere: aniquila el Pod y todo lo que haya dentro.
        - En Mesosphere sin Pod (poseída): aniquila al Character que la posee y todas sus posesiones.
        - On Board: dispara Stationfall (por ahora solo flag).

        Nota: aquí también eliminamos el Time Marker de Antimatter para evitar doble resolución.
        """
        if bool(getattr(self, 'antimatter_detonated', False)):
            return "Antimatter: ya detonada."

        aid = self.antimatter_id()

        # Localización antes de retirarla
        loc_type, loc_val = ("NONE", "")
        if aid:
            try:
                loc_type, loc_val = self.item_location(aid)
            except Exception:
                pass

        carrier_cid: Optional[str] = None
        det_sec: Optional[SectionId] = None
        if override_section:
            det_sec = str(override_section).upper()
        else:
            if loc_type == "SEC":
                det_sec = str(loc_val).upper()
            elif loc_type == "CHAR":
                carrier_cid = str(loc_val).upper()
                ch = self.characters.get(carrier_cid)
                det_sec = str(getattr(ch, 'section', '')).upper() if ch else None

        # Registrar el evento
        self.antimatter_detonated = True
        self.antimatter_detonation_section = det_sec
        self.antimatter_detonation_minute = int(getattr(self, 'minute', 0))
        self.antimatter_detonation_reason = reason or "detonate"

        # Evitar que "detone otra vez" por un marker pendiente
        try:
            self.time_markers = [
                tm for tm in getattr(self, 'time_markers', [])
                if str(getattr(tm, 'kind', '')).upper() != 'ANTIMATTER'
            ]
        except Exception:
            pass

        # Marcar como armed (info pública)
        if aid and aid in getattr(self, 'items', {}):
            try:
                self.items[aid].armed = True
            except Exception:
                pass

        # Quitar el item de donde esté (ya ha detonado)
        if aid:
            if loc_type == "CHAR":
                cid = str(loc_val).upper()
                ch = self.characters.get(cid)
                if ch:
                    ch.items = [x for x in getattr(ch, 'items', []) if str(x).upper() != aid]

            if loc_type == "SEC":
                sec = str(loc_val).upper()
                arr = self.section_items.get(sec, [])
                self.section_items[sec] = [x for x in arr if str(x).upper() != aid]
                if not self.section_items.get(sec):
                    self.section_items.pop(sec, None)

            # Guardarlo "fuera del juego" para debug
            self.section_items.setdefault(OUT_OF_GAME_SECTION, []).append(aid)

        # --- Aplicar efectos según dónde detona ---
        det_sec_u = str(det_sec).upper() if det_sec else ""

        def _is_meso_pod(sec: str) -> bool:
            if not sec:
                return False
            if sec not in getattr(self, 'pods', {}):
                return False
            pod = self.pods.get(sec)
            loc = str(getattr(pod, 'location', '')).upper() if pod else ''
            return (loc != 'ON_BOARD')

        def _is_meso_free() -> bool:
            # En este prototipo usamos 'MESO' como zona de Mesosphere.
            if det_sec_u == 'MESO':
                return True
            # Si lo posee un character Escaped y NO está en un Pod.
            if loc_type == 'CHAR':
                cid = str(loc_val).upper()
                ch = self.characters.get(cid)
                if ch and bool(getattr(ch, 'escaped', False)) and det_sec_u not in getattr(self, 'pods', {}):
                    return True
            return False

        summary: str = ""

        if det_sec_u == str(OUTER_SPACE_SECTION).upper():
            # Outer Space
            # 1) Annihilate everything in Outer Space
            victims = [cid for cid, ch in getattr(self, 'characters', {}).items()
                       if str(getattr(ch, 'section', '')).upper() == det_sec_u and not bool(getattr(ch, 'annihilated', False))]
            for cid in victims:
                try:
                    self.annihilate_character(cid, reason="ANTIMATTER: detona en Outer Space")
                except Exception:
                    pass

            # Items sueltos en Outer Space
            try:
                loose = list(getattr(self, 'section_items', {}).get(det_sec_u, []) or [])
                if loose:
                    rest = [x for x in loose if str(x).upper() != str(aid).upper()]
                    if rest:
                        self.section_items.setdefault(OUT_OF_GAME_SECTION, []).extend(rest)
                self.section_items.pop(det_sec_u, None)
            except Exception:
                pass

            # 2) Damage all Sections with Outer Space arrows
            damaged_secs = []
            for sec, info in getattr(self, 'airlocks', {}).items():
                try:
                    if bool(info.get('to_outer')) or bool(info.get('from_outer')):
                        if self.damage_section(str(sec).upper()):
                            damaged_secs.append(str(sec).upper())
                except Exception:
                    pass

            # Re-assert invariants
            try:
                self.ensure_outer_space_invariants()
            except Exception:
                pass

            summary = f"Outer Space: aniquila {len(victims)} Character(s) y daña {len(damaged_secs)} sección(es) con flechas a Outer Space."

        elif _is_meso_pod(det_sec_u):
            # Mesosphere Pod
            try:
                pod = self.pods.get(det_sec_u)
                if pod:
                    pod.location = 'ANNIHILATED'
            except Exception:
                pass

            inside = [cid for cid, ch in getattr(self, 'characters', {}).items()
                      if str(getattr(ch, 'section', '')).upper() == det_sec_u and not bool(getattr(ch, 'annihilated', False))]
            for cid in inside:
                try:
                    self.annihilate_character(cid, reason=f"ANTIMATTER: detona en Pod {det_sec_u} (Mesosphere)")
                except Exception:
                    pass

            # Items sueltos en el pod
            try:
                loose = list(getattr(self, 'section_items', {}).get(det_sec_u, []) or [])
                if loose:
                    rest = [x for x in loose if str(x).upper() != str(aid).upper()]
                    if rest:
                        self.section_items.setdefault(OUT_OF_GAME_SECTION, []).extend(rest)
                self.section_items.pop(det_sec_u, None)
            except Exception:
                pass

            summary = f"Mesosphere Pod {det_sec_u}: aniquila el Pod y {len(inside)} Character(s) dentro."

        elif _is_meso_free():
            # Mesosphere sin Pod (poseída)
            killed = 0
            if loc_type == 'CHAR':
                cid = str(loc_val).upper()
                if cid in getattr(self, 'characters', {}):
                    try:
                        self.annihilate_character(cid, reason="ANTIMATTER: detona en Mesosphere (sin Pod)")
                        killed = 1
                    except Exception:
                        pass
            summary = f"Mesosphere (sin Pod): aniquila {killed} Character poseedor y sus posesiones."

        else:
            # On Board -> Stationfall
            self.trigger_stationfall('ANTIMATTER')
            summary = "On Board: se dispara STATIONFALL."

        msg = "☢️  ANTIMATTER DETONA"
        if det_sec:
            msg += f" en {det_sec_u}"
        if reason:
            msg += f" ({reason})"
        msg += f". {summary}"

        try:
            self.turn_log.append(msg)
        except Exception:
            pass
        return msg

    def colocated(self, a: CharacterId, b: CharacterId) -> bool:
        if a == b:
            return False
        if a not in self.characters or b not in self.characters:
            return False
        ca = self.characters[a]
        cb = self.characters[b]
        if ca.is_annihilated() or cb.is_annihilated():
            return False

        # Homebrew: Tripa del Tentacled.
        # Mientras alguien esté ahí, NO se considera colocated con nada.
        # (Esto evita Give/Rob/Attack/Revive/etc. sobre esos personajes.)
        if self.is_tentaculous_gut(getattr(ca, 'section', '')) or self.is_tentaculous_gut(getattr(cb, 'section', '')):
            return False

        # Si uno está Escaped y el otro no, nunca cuentan como colocated.
        # Si ambos están Escaped, consideramos que “colocated” si comparten la misma
        # sección “off-station” (demo).
        if ca.is_escaped() or cb.is_escaped():
            return ca.is_escaped() and cb.is_escaped() and (ca.section == cb.section)

        return ca.section == cb.section

    # --- Lock corridors helpers ---
    def _lock_key(self, a: SectionId, b: SectionId) -> Tuple[SectionId, SectionId]:
        return (a, b) if a <= b else (b, a)

    def is_locked_corridor(self, a: SectionId, b: SectionId) -> bool:
        return self._lock_key(a, b) in self.locks

    def add_lock_corridor(self, a: SectionId, b: SectionId) -> None:
        """Adds a LOCK token on a *bidirectional* corridor a<->b.

        Note: In the board game, locks are physical tokens on corridors, so this is an
        undirected edge that blocks Steps for non-Officers.
        """
        if not a or not b or a == b:
            raise ValueError('Invalid corridor for lock.')
        if b not in self.graph.get(a, []):
            raise ValueError(f'No corridor {a}->{b} to lock.')
        if a not in self.graph.get(b, []):
            raise ValueError(f'Locks must be bidirectional: missing {b}->{a}.')
        # Vents are separate connections; avoid mixing.
        if b in self.vents.get(a, [] ) or a in self.vents.get(b, []):
            raise ValueError('Vents cannot be locked.')
        self.locks.add(self._lock_key(a, b))

    # --- Vents helpers ---
    def is_vent(self, frm: SectionId, to: SectionId) -> bool:
        """True si existe una conexión por VENT frm->to (manual 5.4)."""
        return str(to).upper() in {str(x).upper() for x in getattr(self, "vents", {}).get(str(frm).upper(), [])}

    def remove_lock_corridor(self, a: SectionId, b: SectionId) -> None:
        self.locks.discard(self._lock_key(a, b))

    # =========================================================
    # Project X — Monsters (prototype)
    #
    # Nota: por reglas (RM 15.7.3), los Monsters actúan al final de la fase RESOLVE.
    #       Aquí implementamos el "script" del CARNIVOROUS (dossier), con elección
    #       del jugador activo en caso de empate.
    # =========================================================

    def has_unreleased_project_x(self) -> bool:
        """True si Project X aún no ha sido liberado (no hay Monsters en el mapa)."""
        pending = getattr(self, "project_x_pending_monsters", None) or {}
        return bool(pending)

    def release_project_x(self, reason: str = "RELEASE") -> List[str]:
        """Libera Project X: mueve los Monsters pendientes al mapa.

        En este prototipo, 'Project X liberado' se representa simplemente como:
        - Monsters en `self.monsters` (interactuables, actúan en RESOLVE)
        - `project_x_pending_monsters` vacío
        """
        pending = getattr(self, "project_x_pending_monsters", None)
        if not pending:
            return []
        # Marcamos que Project X se ha liberado (para scoring de agendas).
        try:
            self.project_x_released = True
        except Exception:
            pass
        msgs: List[str] = []
        for mid, m in list(pending.items()):
            kind = _norm(getattr(m, "kind", ""))
            # Setup (Launch Manual / Dossier): Tentacled Monstrosity entra en VAULT_X.
            # Ojo: puede moverse después en RESOLVE; aquí solo fijamos la sección de aparición.
            if kind == "TENTACLED":
                sec = "VAULT_X"
            else:
                sec = str(getattr(m, "section", "") or "VAULT_X").upper()
            m.section = sec
            self.monsters[mid] = m
            msgs.append(f"🔓 Project X RELEASED ({reason}): {m.name} aparece en {sec}.")

            # Carnivorous Bioexperiment (dossier): cae INMEDIATAMENTE si está en una sección con Hazard.
            if _norm(getattr(m, "kind", "")) == "CARNIVOROUS" and getattr(m, "status", "LIVE") == "LIVE":
                if self.section_has_hazard(sec):
                    m.status = "DOWN"
                    msgs.append(f"👾 {m.name} ({mid}) queda DOWN por Hazard en {sec} (al aparecer).")

        pending.clear()

        # Re-aplicar módulos de mapa dinámicos tras la liberación (p.ej. Tripa del Tentacled).
        try:
            from map_modules import apply_map_modules
            self.map_modules_applied = apply_map_modules(self)
        except Exception:
            pass


        # Tentacled Monstrosity: si aparece en una sección con FIRE, queda DOWN automáticamente.
        try:
            for _mid, _m in (getattr(self, "monsters", {}) or {}).items():
                if _norm(getattr(_m, "kind", "")) == "TENTACLED":
                    msgs.extend(self._apply_tentacled_fire_down(getattr(_m, "section", "VAULT_X"), reason="RELEASE_IN_FIRE"))
        except Exception:
            pass
        return msgs


    Choice = Tuple[str, str]  # (value, label)

    def _is_off_station_section(self, sec: SectionId) -> bool:
        s = _norm(sec)
        return s in ("OUTERSPACE", "OUTER_SPACE", "OUTOFGAME", "MESO", "MESOSPHERE")

    def _monster_neighbors(self, m: Monster, frm: SectionId) -> List[SectionId]:
        """Secciones a las que un Monster puede Step en 1 paso.

        - Corridors normales según el grafo, respetando LOCKS.
        - VENTS solo si el Monster tiene TUNNEL RAT.
        - No permitimos Pods / Outer Space / Mesosphere (simplificación segura).
        """
        frm = str(frm).upper()
        res: List[SectionId] = []

        ab = {str(a).upper() for a in getattr(m, "abilities", set())}
        has_juggernaut = AB.JUGGERNAUT in ab

        # Corridors normales
        for to in list(self.graph.get(frm, []) or []):
            to_u = str(to).upper()
            if self._is_off_station_section(to_u):
                continue
            if getattr(self, "is_pod", None) and self.is_pod(to_u):
                continue
            if hasattr(self, "is_locked_corridor") and self.is_locked_corridor(frm, to_u):
                # JUGGERNAUT: puede atravesar LOCK como si no existiera.
                if not has_juggernaut:
                    continue
            res.append(to_u)

        # Vents
        if AB.TUNNEL_RAT in ab:
            for to in list(getattr(self, "vents", {}).get(frm, []) or []):
                to_u = str(to).upper()
                if self._is_off_station_section(to_u):
                    continue
                if getattr(self, "is_pod", None) and self.is_pod(to_u):
                    continue
                res.append(to_u)

        # dedupe, keep stable order
        seen = set()
        out: List[SectionId] = []
        for x in res:
            if x not in seen:
                seen.add(x)
                out.append(x)
        return out

    def _bfs_distance(
        self,
        m: Monster,
        start: SectionId,
        goals: Set[SectionId],
        *,
        blocked: Optional[Set[SectionId]] = None,
    ) -> Optional[int]:
        """Distancia mínima (en Steps) desde start hasta cualquiera de goals.

        - `blocked`: secciones que el Monster no debería atravesar (p.ej. Hazards por Self‑Preservation).
          Nota: si una sección de `goals` está en `blocked`, se permite *llegar* a esa meta pero no atravesar
          otras secciones bloqueadas.
        """
        start_u = str(start).upper()
        goals_u = {str(g).upper() for g in goals}
        blocked_u = {str(b).upper() for b in (blocked or set())}
        if start_u in goals_u:
            return 0

        q: deque[Tuple[str, int]] = deque()
        q.append((start_u, 0))
        seen = {start_u}

        while q:
            cur, d = q.popleft()
            nd = d + 1
            for nb in self._monster_neighbors(m, cur):
                if nb in seen:
                    continue
                # No atravesar secciones bloqueadas (salvo que sean meta).
                if nb in blocked_u and nb not in goals_u:
                    continue
                if nb in goals_u:
                    return nd
                seen.add(nb)
                q.append((nb, nd))
        return None

    def _live_humans_for_monsters(self) -> List[CharacterId]:
        res: List[CharacterId] = []
        for cid, ch in self.characters.items():
            if getattr(ch, "annihilated", False) or getattr(ch, "escaped", False):
                continue
            if getattr(ch, "status", "LIVE") != "LIVE":
                continue
            if "HUMAN" not in _norm(getattr(ch, "ctype", "")):
                continue
            res.append(cid)
        return res

    def _choose(self, chooser: Optional[Callable[[str, List[Choice]], str]], prompt: str, choices: List[Choice]) -> str:
        if not choices:
            raise ValueError("No choices provided")
        if chooser is None:
            return choices[0][0]
        return str(chooser(prompt, choices)).upper()

    def _carnivorous_act(self, m: Monster, acting_pid: PlayerId, chooser: Optional[Callable[[str, List[Choice]], str]] = None) -> List[str]:
        msgs: List[str] = []

        # Si está DOWN, no actúa.
        if not getattr(m, "is_live", lambda: False)():
            return [f"{m.name} ({m.mid}) está DOWN y no actúa."]

        sec = str(getattr(m, "section", "")).upper()

        # Downed by hazards: si está en una sección con Hazard, queda DOWN y no actúa.
        if hasattr(self, "section_has_hazard") and self.section_has_hazard(sec):
            m.status = "DOWN"
            return [f"{m.name} ({m.mid}) queda DOWN por Hazard en {sec}."]

        # 1) Si está colocated con un humano vivo, debe tumbar a uno.
        colocated: List[CharacterId] = []
        for cid in self._live_humans_for_monsters():
            ch = self.characters[cid]
            if str(getattr(ch, "section", "")).upper() == sec:
                colocated.append(cid)

        if colocated:
            # Elegir target si hay empate.
            if len(colocated) == 1:
                tgt = colocated[0]
            else:
                choices: List[GameState.Choice] = []
                for cid in sorted(colocated):
                    nm = getattr(self.characters[cid], "name", cid)
                    choices.append((cid, f"{cid} — {nm}"))
                tgt = self._choose(chooser, f"👾 {m.name}: elige a qué humano tumba (colocated en {sec})", choices)

            self.characters[tgt].status = "DOWN"
            msgs.append(f"👾 {m.name} tumba a {tgt} en {sec}.")
            return msgs

        # 2) Si no, Step 1 sección más cerca del humano vivo más cercano.
        humans = self._live_humans_for_monsters()
        if not humans:
            return [f"{m.name} ({m.mid}) no encuentra humanos vivos: no se mueve."]

        # Self-Preservation: medimos distancia por rutas "seguras" evitando Hazards.
        # Si no, puede ocurrir que la ruta más corta pase por un Hazard (que luego evitamos),
        # y el Monster se quede inmóvil aunque exista un camino alternativo más largo.
        all_secs: Set[str] = set()
        try:
            g = (getattr(self, "graph", {}) or {})
            all_secs.update({str(x).upper() for x in g.keys()})
            for _frm, _tos in g.items():
                for _to in (_tos or []):
                    all_secs.add(str(_to).upper())
        except Exception:
            pass
        try:
            all_secs.update({str(x).upper() for x in (getattr(self, "hazards", {}) or {}).keys()})
        except Exception:
            pass
        blocked_hazards: Set[str] = set()
        try:
            for s in all_secs:
                if self.section_has_hazard(s):
                    blocked_hazards.add(s)
        except Exception:
            blocked_hazards = set()

        # Distancia desde el monster a cada sección de humano.
        dist_by_cid: Dict[str, int] = {}
        for cid in humans:
            hsec = str(getattr(self.characters[cid], "section", "")).upper()
            d = self._bfs_distance(m, sec, {hsec}, blocked=blocked_hazards)
            if d is not None:
                dist_by_cid[cid] = int(d)

        if not dist_by_cid:
            return [f"{m.name} ({m.mid}) no puede alcanzar a ningún humano: no se mueve."]

        min_d = min(dist_by_cid.values())
        closest = [cid for cid, d in dist_by_cid.items() if d == min_d]

        # Candidatos de Step: vecinos que reducen la distancia hacia ALGUNO de los closest.
        neighbors = self._monster_neighbors(m, sec)
        step_choices: List[SectionId] = []

        # Self-Preservation: evitamos entrar en Hazards. Si todos los pasos válidos
        # serían a Hazard, entonces no se mueve.
        for nb in neighbors:
            # evitar Hazards como destino
            if hasattr(self, "section_has_hazard") and self.section_has_hazard(nb):
                continue

            # ¿Existe un closest al que este vecino esté en un camino más corto?
            # (1 + dist(nb -> hsec) == dist(cur -> hsec))
            ok = False
            for cid in closest:
                hsec = str(getattr(self.characters[cid], "section", "")).upper()
                d2 = self._bfs_distance(m, nb, {hsec}, blocked=blocked_hazards)
                if d2 is None:
                    continue
                if 1 + int(d2) == int(dist_by_cid[cid]):
                    ok = True
                    break
            if ok:
                step_choices.append(nb)

        if not step_choices:
            return [f"{m.name} ({m.mid}) no tiene un Step seguro que lo acerque: no se mueve."]

        step_choices = sorted(list(dict.fromkeys(step_choices)))
        if len(step_choices) == 1:
            to_sec = step_choices[0]
        else:
            # Empate: el jugador activo decide.
            labeled: List[GameState.Choice] = [(s, s) for s in step_choices]
            to_sec = self._choose(chooser, f"👾 {m.name}: empate de rutas (elige a qué sección Step)", labeled)

        frm = sec

        # Monsters con JUGGERNAUT pueden atravesar LOCKS y los revienta al pasar.
        ab_m = {str(a).upper() for a in getattr(m, "abilities", set())}
        if AB.JUGGERNAUT in ab_m and hasattr(self, "is_locked_corridor") and self.is_locked_corridor(frm, to_sec):
            self.remove_lock_corridor(frm, to_sec)
            msgs.append(f"🔓 {m.name} revienta el LOCK entre {frm} y {to_sec}.")

        m.section = to_sec
        msgs.append(f"👾 {m.name} se mueve {frm} -> {to_sec}.")

        # Si por cualquier razón acabó en Hazard, cae.
        if hasattr(self, "section_has_hazard") and self.section_has_hazard(to_sec):
            m.status = "DOWN"
            msgs.append(f"👾 {m.name} queda DOWN por Hazard en {to_sec}.")

        return msgs

    def _tentacled_act(self, m: Monster, acting_pid: PlayerId, chooser: Optional[Callable[[str, List[Choice]], str]] = None) -> List[str]:
        """Script del Tentacled Monstrosity (Project X, dossier).

        1) Si hay Characters o Items *unpossessed* colocated con el Monster, el jugador activo elige 1 y lo consume:
           - El target se mueve a la Tripa (TENTACULOUS_GUT_SECTION).
           - Si es un Human sin Helmet, queda DOWN.
        2) Si no hay nada colocated, el jugador activo mueve 1 Character o Item unpossessed *adyacente* (solo corridors sin LOCK; sin Vents)
           a la sección del Tentacled.
        3) Si tampoco hay, el jugador activo hace Step con el Tentacled 1 sección más cerca del Human no consumido más cercano (LIVE o DOWN).
           - Si hay empate, el jugador activo decide.
        """
        msgs: List[str] = []

        sec = str(getattr(m, "section", "")).upper()

        # FIRE: el Tentacled queda DOWN automáticamente si hay FIRE en su sección.
        try:
            if self.has_hazard_kind(sec, "FIRE"):
                if getattr(m, "status", "LIVE") != "DOWN":
                    m.status = "DOWN"
                    msgs.append(f"🔥 {m.name} ({m.mid}) queda DOWN por FIRE en {sec}.")
                    try:
                        msgs.extend(self.dump_tentaculous_gut_contents(sec, reason="FIRE"))
                    except Exception:
                        pass
                else:
                    msgs.append(f"🔥 {m.name} ({m.mid}) está DOWN por FIRE en {sec}.")
                return msgs
        except Exception:
            pass

        if not getattr(m, "is_live", lambda: False)():
            return [f"{m.name} ({m.mid}) está DOWN y no actúa."]
        gut = TENTACULOUS_GUT_SECTION

        # -------------------------
        # 1) Consume colocated
        # -------------------------
        coloc_choices: List[GameState.Choice] = []

        # Characters colocated (LIVE o DOWN), excluyendo escaped/annihilated.
        for cid, ch in (getattr(self, "characters", {}) or {}).items():
            if getattr(ch, "annihilated", False) or getattr(ch, "escaped", False):
                continue
            if str(getattr(ch, "section", "")).upper() != sec:
                continue
            nm = getattr(ch, "name", cid)
            st = getattr(ch, "status", "LIVE")
            coloc_choices.append((f"CHAR:{cid}", f"{cid} — {nm} ({st})"))

        # Unpossessed items colocated
        for iid in list((getattr(self, "section_items", {}) or {}).get(sec, []) or []):
            it = (getattr(self, "items", {}) or {}).get(iid)
            label = f"{iid} — {getattr(it, 'name', iid)}"
            coloc_choices.append((f"ITEM:{iid}@{sec}", label))

        if coloc_choices:
            # mantener un orden estable: primero characters por cid, luego items por iid
            chars = [c for c in coloc_choices if str(c[0]).startswith("CHAR:")]
            items = [c for c in coloc_choices if str(c[0]).startswith("ITEM:")]
            chars.sort(key=lambda x: x[0])
            items.sort(key=lambda x: x[0])
            choices = chars + items

            pick = self._choose(chooser, f"🐙 {m.name}: elige qué consume (colocated en {sec})", choices)

            if pick.startswith("CHAR:"):
                cid = pick.split(":", 1)[1].upper()
                ch = self.characters[cid]
                ch.section = gut
                msgs.append(f"🐙 {m.name} consume a {cid}: pasa a la TRIPA.")

                # Si es Human sin Helmet -> DOWN.
                if ("HUMAN" in _norm(getattr(ch, "ctype", ""))) and (not self.is_helmeted(cid)):
                    ch.status = "DOWN"
                    msgs.append(f"💀 {cid} queda DOWN (Human sin Helmet) al ser consumido.")
                return msgs

            if pick.startswith("ITEM:"):
                # ITEM:<iid>@<fromsec>
                rest = pick.split(":", 1)[1]
                iid, from_sec = rest.split("@", 1)
                iid = iid.upper()
                from_u = str(from_sec).upper()
                self.section_items.setdefault(from_u, [])
                self.section_items.setdefault(gut, [])
                try:
                    self.section_items[from_u].remove(iid)
                except ValueError:
                    pass
                self.section_items[gut].append(iid)
                it = self.items.get(iid)
                msgs.append(f"🐙 {m.name} consume el Item {iid} ({getattr(it, 'name', iid)}): pasa a la TRIPA.")
                return msgs

        # -------------------------
        # 2) Pull adjacent (solo corridors SIN LOCK; sin vents)
        # -------------------------
        adj_sections: List[SectionId] = []
        for to in list((getattr(self, "graph", {}) or {}).get(sec, []) or []):
            to_u = str(to).upper()
            if self._is_off_station_section(to_u):
                continue
            if getattr(self, "is_pod", None) and self.is_pod(to_u):
                continue
            if hasattr(self, "is_locked_corridor") and self.is_locked_corridor(sec, to_u):
                continue
            adj_sections.append(to_u)

        pull_choices: List[GameState.Choice] = []
        for adj in sorted(list(dict.fromkeys(adj_sections))):
            # Characters in adj
            for cid, ch in (getattr(self, "characters", {}) or {}).items():
                if getattr(ch, "annihilated", False) or getattr(ch, "escaped", False):
                    continue
                if str(getattr(ch, "section", "")).upper() != adj:
                    continue
                nm = getattr(ch, "name", cid)
                st = getattr(ch, "status", "LIVE")
                pull_choices.append((f"CHAR:{cid}", f"{cid} — {nm} ({st}) en {adj}"))
            # Unpossessed items in adj
            for iid in list((getattr(self, "section_items", {}) or {}).get(adj, []) or []):
                it = self.items.get(iid)
                pull_choices.append((f"ITEM:{iid}@{adj}", f"{iid} — {getattr(it, 'name', iid)} en {adj}"))

        if pull_choices:
            # ordenar estable
            pull_choices.sort(key=lambda x: x[0])
            pick = self._choose(chooser, f"🐙 {m.name}: no hay nada colocated. Elige qué atrae (adyacente) hacia {sec}", pull_choices)

            if pick.startswith("CHAR:"):
                cid = pick.split(":", 1)[1].upper()
                ch = self.characters[cid]
                from_u = str(getattr(ch, "section", "")).upper()
                ch.section = sec
                msgs.append(f"🐙 {m.name} atrae a {cid} desde {from_u} -> {sec}.")
                return msgs

            if pick.startswith("ITEM:"):
                rest = pick.split(":", 1)[1]
                iid, from_sec = rest.split("@", 1)
                iid = iid.upper()
                from_u = str(from_sec).upper()
                self.section_items.setdefault(from_u, [])
                self.section_items.setdefault(sec, [])
                try:
                    self.section_items[from_u].remove(iid)
                except ValueError:
                    pass
                self.section_items[sec].append(iid)
                it = self.items.get(iid)
                msgs.append(f"🐙 {m.name} atrae el Item {iid} ({getattr(it, 'name', iid)}) desde {from_u} -> {sec}.")
                return msgs

        # -------------------------
        # 3) Step 1 más cerca del Human no consumido más cercano (LIVE o DOWN)
        # -------------------------
        humans: List[CharacterId] = []
        for cid, ch in (getattr(self, "characters", {}) or {}).items():
            if getattr(ch, "annihilated", False) or getattr(ch, "escaped", False):
                continue
            if "HUMAN" not in _norm(getattr(ch, "ctype", "")):
                continue
            if self.is_tentaculous_gut(getattr(ch, "section", "")):
                continue
            humans.append(cid)

        if not humans:
            return [f"{m.name} ({m.mid}) no encuentra Humans no consumidos: no se mueve."]

        # Self-Preservation (Tentacled): para rutas evitamos atravesar secciones con FIRE.
        all_secs: Set[str] = set()
        try:
            g = (getattr(self, "graph", {}) or {})
            all_secs.update({str(x).upper() for x in g.keys()})
            for _frm, _tos in g.items():
                for _to in (_tos or []):
                    all_secs.add(str(_to).upper())
        except Exception:
            pass
        try:
            all_secs.update({str(x).upper() for x in (getattr(self, "hazards", {}) or {}).keys()})
        except Exception:
            pass
        fire_blocked: Set[str] = set()
        try:
            for s in all_secs:
                if self.has_hazard_kind(s, "FIRE"):
                    fire_blocked.add(s)
        except Exception:
            fire_blocked = set()

        dist_by_cid: Dict[str, int] = {}
        for cid in humans:
            hsec = str(getattr(self.characters[cid], "section", "")).upper()
            d = self._bfs_distance(m, sec, {hsec}, blocked=fire_blocked)
            if d is not None:
                dist_by_cid[cid] = int(d)

        if not dist_by_cid:
            return [f"{m.name} ({m.mid}) no puede alcanzar a ningún Human: no se mueve."]

        min_d = min(dist_by_cid.values())
        closest = [cid for cid, d in dist_by_cid.items() if d == min_d]

        if len(closest) == 1:
            target_cid = closest[0]
        else:
            chs: List[GameState.Choice] = []
            for cid in sorted(closest):
                h = self.characters[cid]
                hsec = str(getattr(h, "section", "")).upper()
                st = getattr(h, "status", "LIVE")
                chs.append((cid, f"{cid} — {getattr(h, 'name', cid)} ({st}) en {hsec}"))
            target_cid = self._choose(chooser, f"🐙 {m.name}: empate de Humans más cercanos. Elige a cuál persigue.", chs)

        target_sec = str(getattr(self.characters[target_cid], "section", "")).upper()
        dist_to_target = int(dist_by_cid[target_cid])

        neighbors = self._monster_neighbors(m, sec)
        step_choices: List[SectionId] = []

        for nb in neighbors:
            # Self-Preservation (Tentacled): como solo puede quedar DOWN por FIRE,
            # nunca hará un Step que acabe entrando en una sección con FIRE.
            try:
                if self.has_hazard_kind(nb, "FIRE"):
                    continue
            except Exception:
                pass
            d2 = self._bfs_distance(m, nb, {target_sec}, blocked=fire_blocked)
            if d2 is None:
                continue
            if 1 + int(d2) == dist_to_target:
                step_choices.append(nb)

        if not step_choices:
            return [f"{m.name} ({m.mid}) no tiene un Step seguro que lo acerque: no se mueve."]

        step_choices = sorted(list(dict.fromkeys(step_choices)))

        if len(step_choices) == 1:
            to_sec = step_choices[0]
        else:
            labeled: List[GameState.Choice] = [(s, s) for s in step_choices]
            to_sec = self._choose(chooser, f"🐙 {m.name}: empate de rutas (elige a qué sección Step)", labeled)

        frm = sec
        ab_m = {str(a).upper() for a in getattr(m, "abilities", set())}
        if AB.JUGGERNAUT in ab_m and hasattr(self, "is_locked_corridor") and self.is_locked_corridor(frm, to_sec):
            self.remove_lock_corridor(frm, to_sec)
            msgs.append(f"🔓 {m.name} revienta el LOCK entre {frm} y {to_sec}.")

        m.section = to_sec
        msgs.append(f"🐙 {m.name} se mueve {frm} -> {to_sec} (persigue a {target_cid}).")

        # Si entra en FIRE, queda DOWN inmediatamente.
        try:
            msgs.extend(self._apply_tentacled_fire_down(to_sec, reason="MOVED_INTO_FIRE"))
        except Exception:
            pass

        return msgs



    def resolve_project_x_monsters(self, acting_pid: PlayerId, chooser: Optional[Callable[[str, List[Choice]], str]] = None) -> List[str]:
        """Ejecuta el comportamiento de Monsters (Project X) al final de RESOLVE."""
        msgs: List[str] = []
        for mid, m in (getattr(self, "monsters", {}) or {}).items():
            kind = _norm(getattr(m, "kind", ""))
            if kind == "CARNIVOROUS":
                msgs.extend(self._carnivorous_act(m, acting_pid, chooser=chooser))
            elif kind == "TENTACLED":
                msgs.extend(self._tentacled_act(m, acting_pid, chooser=chooser))
        return msgs




    def apply_resolve_phase_room_rules(self, acting_pid: PlayerId) -> List[str]:
        """Aplica reglas de habitaciones que disparan en RESOLVE (mapa básico).

        - MAGNETIC_CONTAINMENT: cualquier cubo de influencia sobre un Robot aquí va a Betrayal.
        - PHYSICS_LAB: todo Data en esta habitación se borra.

        Devuelve mensajes para el log/UI.
        """
        msgs: List[str] = []

        # --- Magnetic Containment -> Betrayal (solo Robots) ---
        mc = "MAGNETIC_CONTAINMENT"
        robots_here: List[str] = []
        for cid, ch in (getattr(self, 'characters', {}) or {}).items():
            if str(getattr(ch, 'section', '')).upper() != mc:
                continue
            if ch.is_annihilated() or ch.is_escaped():
                continue
            if _norm(getattr(ch, 'ctype', '')) == 'ROBOT':
                robots_here.append(str(cid).upper())

        if robots_here:
            infl = getattr(self, 'influence', {}) or {}
            for pid, per_char in list(infl.items()):
                moved_total = 0
                per_char = dict(per_char or {})
                for rcid in robots_here:
                    n = int(per_char.get(rcid, 0) or 0)
                    if n > 0:
                        moved_total += n
                        per_char.pop(rcid, None)
                if moved_total > 0:
                    infl[pid] = per_char
                    # Añadir a Betrayal del jugador correspondiente.
                    for p in getattr(self, 'players', []) or []:
                        if getattr(p, 'pid', None) == pid:
                            p.betrayal_cubes = int(getattr(p, 'betrayal_cubes', 0) or 0) + moved_total
                            break
                    msgs.append(f"⚠ MAGNETIC CONTAINMENT: {moved_total} influencia(s) sobre Robot(s) -> BETRAYAL ({pid}).")
            self.influence = infl

        # --- Physics Lab: borra Data en la habitación ---
        pl = "PHYSICS_LAB"
        for cid, ch in (getattr(self, 'characters', {}) or {}).items():
            if str(getattr(ch, 'section', '')).upper() != pl:
                continue
            if ch.is_annihilated() or ch.is_escaped():
                continue
            data = dict(getattr(ch, 'data', {}) or {})
            if not data:
                continue
            removed = sum(int(v or 0) for v in data.values())
            ch.data = {}
            msgs.append(f"🧪 PHYSICS LAB: {cid} pierde todo su Data (x{removed}).")

        return msgs
    # --- Lights helpers ---
    def is_lit(self, sec: SectionId) -> bool:
        """True si la sección está iluminada.

        Por defecto todas lo están; solo guardamos las que están a oscuras.
        """
        su = str(sec).upper()
        return su not in self.unlit_sections

    def seal_default_lighting(self) -> None:
        """Sella el estado de luz "por defecto" (Dark permanente) del setup.

        En Stationfall hay secciones impresas como Dark que no pueden volverse Lit.
        Además, tras un Blackout, al restaurar energía queremos volver a ese
        estado estándar, no al estado inmediatamente anterior.

        Llama a esto una vez después de construir el estado inicial.
        """
        if not getattr(self, "default_unlit_sections", None):
            self.default_unlit_sections = set(getattr(self, "unlit_sections", set()))

    def set_lit(self, sec: SectionId, lit: bool) -> None:
        """Marca una sección como iluminada (lit=True) o a oscuras (lit=False).

        Nota: no es una acción del juego; es un helper de estado para el prototipo.
        """
        su = str(sec).upper()
        if lit:
            # RM 5.1.3: las secciones "Dark" impresas no pueden volverse Lit.
            if su in getattr(self, "default_unlit_sections", set()):
                return
            self.unlit_sections.discard(su)
        else:
            self.unlit_sections.add(su)

    # --- Hazards helpers ---
    def section_has_hazard(self, sec: SectionId) -> bool:
        hs = self.hazards.get(sec, set())
        return bool(hs)

    def has_hazard_kind(self, sec: SectionId, kind: HazardKind) -> bool:
        return _norm(kind) in {_norm(x) for x in self.hazards.get(sec, set())}


    def _apply_tentacled_fire_down(self, sec: SectionId, *, reason: str = "FIRE") -> List[str]:
        """Si hay Tentacled en `sec` y FIRE está presente, lo baja inmediatamente.

        - Inmune a DOWN por otras causas.
        - Si baja a DOWN, vomita inmediatamente el contenido de la Tripa.
        """
        msgs: List[str] = []
        secu = str(sec).upper()
        try:
            if not self.has_hazard_kind(secu, "FIRE"):
                return []
        except Exception:
            return []

        for mid, mon in (getattr(self, "monsters", {}) or {}).items():
            if _norm(getattr(mon, "kind", "")) != "TENTACLED":
                continue
            if str(getattr(mon, "section", "")).upper() != secu:
                continue
            if getattr(mon, "status", "LIVE") != "DOWN":
                mon.status = "DOWN"
                msgs.append(f"🔥 {mon.name} ({mid}) queda DOWN por FIRE en {secu}.")
                try:
                    if hasattr(self, "dump_tentaculous_gut_contents"):
                        msgs.extend(self.dump_tentaculous_gut_contents(secu, reason=reason))
                except Exception:
                    pass
            else:
                msgs.append(f"🔥 {mon.name} ({mid}) está DOWN por FIRE en {secu}.")
        return msgs

    def is_helmeted(self, cid: CharacterId) -> bool:
        """RM 8.1.1: sólo los Humans pueden estar Helmeted.

        - Un Human es Helmeted si posee un Helmet.
        - Un Robot nunca está Helmeted aunque posea un Helmet (RM 8.1.1.1).
        """
        ch = self.characters[cid]

        if "HUMAN" not in _norm(getattr(ch, "ctype", "")):
            return False

        for iid in getattr(ch, "items", []):
            it = self.items.get(iid)
            if it and it.is_helmet():
                return True
        return False

    # --- Outer Space / Airlocks (RM 5.1.7 / 6.4 / 13.12.3) ---
    def is_outer_space(self, sec: SectionId) -> bool:
        return _norm(sec) in ("OUTERSPACE", "OUTER_SPACE")

    def ensure_outer_space_invariants(self) -> None:
        """Mantiene invariantes de Outer Space.

        RM 5.1.7.2 / 6.4:
        - Outer Space siempre tiene ASPHYX.
        - Ese Hazard no se puede quitar (lo reponemos si alguien lo borra).

        Nota: La restricción de "no se puede dañar" está en damage_section().
        """
        # Asegurar nodo en el grafo para listarlo/usar section_items, pero sin conexiones normales.
        self.graph.setdefault(OUTER_SPACE_SECTION, [])

        # Asegurar el Hazard permanente.
        self.hazards.setdefault(OUTER_SPACE_SECTION, set()).add("ASPHYX")

        # Si alguien intentó poner FIRE también, lo eliminamos.
        if self.has_hazard_kind(OUTER_SPACE_SECTION, "FIRE"):
            self.hazards[OUTER_SPACE_SECTION] = {h for h in self.hazards[OUTER_SPACE_SECTION] if _norm(h) != "FIRE"}

    def add_airlock(self, sec: SectionId, to_outer: bool = True, from_outer: bool = True) -> None:
        """Debug/setup: marca una sección como Airlock hacia/desde Outer Space.

        Las flechas del mapa determinan direcciones:
          - to_outer=True  : se puede ir/throw/eject desde esta sección -> Outer Space
          - from_outer=True: se puede ir/throw desde Outer Space -> esta sección
        """
        s = str(sec).upper()
        if not s:
            raise ValueError("Sección inválida")
        if s not in self.graph:
            raise ValueError(f"La sección {s} no existe en el grafo.")
        if self.is_outer_space(s):
            raise ValueError("Outer Space no puede ser un Airlock.")
        self.airlocks[s] = {"to_outer": bool(to_outer), "from_outer": bool(from_outer)}

    def is_airlock_section(self, sec: SectionId) -> bool:
        return str(sec).upper() in getattr(self, "airlocks", {})

    def airlock_allows(self, sec: SectionId, direction: str) -> bool:
        s = str(sec).upper()
        d = str(direction).lower().strip()
        info = getattr(self, "airlocks", {}).get(s)
        if not info:
            return False
        if d not in ("to_outer", "from_outer"):
            return False
        return bool(info.get(d, False))

    def airlock_can_step(self, frm: SectionId, to: SectionId) -> bool:
        """True si el movimiento frm->to está permitido por Airlock (no por corridors)."""
        f = str(frm).upper()
        t = str(to).upper()
        if self.is_outer_space(t) and self.is_airlock_section(f):
            return self.airlock_allows(f, "to_outer")
        if self.is_outer_space(f) and self.is_airlock_section(t):
            return self.airlock_allows(t, "from_outer")
        return False
    def apply_hazard_effects(self) -> List[str]:
        """
        Reference Manual §6 (implementado aquí SOLO lo que es inmediato y ya usas en el demo):

        - 6.1: Any Unhelmeted Humans Colocated with a Hazard become Down.
        - 6.5.2: If Asphyxiation and Fire Hazards are ever Colocated, remove the Fire.
                 (En la práctica, esto lo resolvemos también al añadir Hazards, pero dejamos
                 esta pasada para mantener consistencia).
        """
        msgs: List[str] = []

        # Outer Space: asegurar Hazard permanente (RM 6.4).
        self.ensure_outer_space_invariants()

        # 6.5.2: si por cualquier razón hay FIRE+ASPHYX juntos, FIRE se elimina.
        for sec, hs in list(self.hazards.items()):
            if not hs:
                continue
            kinds = {_norm(x) for x in hs}
            if "FIRE" in kinds and "ASPHYX" in kinds:
                self.hazards[sec] = {x for x in hs if _norm(x) != "FIRE"}
                msgs.append(f"🔥 HAZARD: FIRE removido en {sec} (colocado con ASPHYX)")

        # 6.1: humanos sin casco en sección con Hazard -> DOWN
        for sec, hs in list(self.hazards.items()):
            if not hs:
                continue
            for ch in self.characters.values():
                if ch.is_annihilated() or ch.is_escaped():
                    continue
                if ch.section != sec:
                    continue
                if "HUMAN" not in _norm(ch.ctype):
                    continue
                if self.is_helmeted(ch.cid):
                    continue
                # ADRENALINE (Daredevil): no queda DOWN por Hazards.
                if ch.has_ability(AB.ADRENALINE):
                    continue
                if ch.status != "DOWN":
                    ch.status = "DOWN"
                    msgs.append(f"⚠️  HAZARD: {ch.cid} queda DOWN (unhelmeted en {sec})")

        # Carnivorous Bioexperiment (dossier): cae INMEDIATAMENTE si está en una sección con Hazard.
        for mid, m in list((getattr(self, "monsters", {}) or {}).items()):
            if _norm(getattr(m, "kind", "")) != "CARNIVOROUS":
                continue
            if not getattr(m, "is_live", lambda: False)():
                continue
            msec = str(getattr(m, "section", "")).upper()
            if self.section_has_hazard(msec):
                m.status = "DOWN"
                msgs.append(f"👾 HAZARD: {m.name} ({mid}) queda DOWN por Hazard en {msec}.")

        # cleanup vacíos
        for sec in list(self.hazards.keys()):
            if not self.hazards[sec]:
                self.hazards.pop(sec, None)

        # Outer Space: reponer si se quedó fuera por cleanup.
        self.ensure_outer_space_invariants()

        return msgs

    def add_hazard(self, sec: SectionId, kind: HazardKind) -> None:
        # Normalizamos IDs de sección a mayúsculas para que todo el estado sea consistente.
        sec = str(sec).upper()
        # Outer Space: Hazard permanente (RM 6.4). No se puede cambiar ni quitar.
        if self.is_outer_space(sec):
            k0 = _norm(kind)
            if k0 != "ASPHYX":
                raise ValueError("Outer Space: solo puede tener ASPHYX y es permanente.")
            self.ensure_outer_space_invariants()
            return

        k = _norm(kind)
        if sec not in self.hazards:
            self.hazards[sec] = set()

        # 6.5.1: Fire no puede empezar en una sección con Asphyxiation
        if k == "FIRE" and self.has_hazard_kind(sec, "ASPHYX"):
            raise ValueError("FIRE no puede empezar en una sección con ASPHYX (Hazard).")

        # 6.5.2: si añades ASPHYX donde había FIRE, FIRE se elimina.
        if k == "ASPHYX" and self.has_hazard_kind(sec, "FIRE"):
            self.hazards[sec] = {h for h in self.hazards[sec] if _norm(h) != "FIRE"}

        self.hazards[sec].add(k)

        # 6.5: Fire daña inmediatamente la sección
        if k == "FIRE":
            self.damage_section(sec)
            # Tentacled Monstrosity: FIRE lo baja inmediatamente.
            try:
                self._apply_tentacled_fire_down(sec, reason="FIRE_ADDED")
            except Exception:
                pass

    # --- Abandon Ship ---
    def set_abandon_ship(self, on: bool, *, remove_locks: bool = True) -> bool:
        """Activa/desactiva el estado global Abandon Ship (RM 7.1).

        Efectos al activarse (False -> True):
        - Flip del marcador (representado por `self.abandon_ship = True`)
        - Remove all Locks (self.locks.clear()) si remove_locks=True  (RM 7.1.1)
        - Habilita el lanzamiento de Pods que sólo requieren Abandon Ship
          (se aplica vía `pod_launch_requirement_met`).

        Nota: en reglas, Abandon Ship no se "desactiva"; dejamos `on=False` sólo
        como debug. Desactivarlo NO restaura Locks (para no inventar reglas).
        """
        prev = bool(getattr(self, 'abandon_ship', False))
        self.abandon_ship = bool(on)
        changed = (prev != self.abandon_ship)
        if changed and self.abandon_ship:
            # RM 7.1.1: remove all Locks
            if remove_locks:
                try:
                    self.locks.clear()
                except Exception:
                    pass
        return changed

    # --- Power helpers ---
    def damaged_power_sections_count(self) -> int:
        """Cuántas de tus Power Sections están actualmente dañadas."""
        return len(set(self.power_sections) & set(self.damaged_sections))

    def is_blackout(self) -> bool:
        return str(getattr(self, "power_status", "")) == "Blackout"

    def is_tentaculous_gut(self, sec: SectionId) -> bool:
        return str(sec).upper() == TENTACULOUS_GUT_SECTION

    def dump_tentaculous_gut_contents(self, to_sec: SectionId, reason: str = "") -> List[str]:
        """Vuelca todo lo que está dentro de la Tripa (TENTACULOUS_GUT_SECTION) a `to_sec`.

        Se usa cuando el Tentacled Monstrosity queda DOWN (dossier Project X).
        """
        to_u = str(to_sec).upper()
        gut = TENTACULOUS_GUT_SECTION
        msgs: List[str] = []

        moved_chars: List[CharacterId] = []
        for cid, ch in (getattr(self, "characters", {}) or {}).items():
            if self.is_tentaculous_gut(getattr(ch, "section", "")):
                ch.section = to_u
                moved_chars.append(cid)

        moved_items: List[ItemId] = list((getattr(self, "section_items", {}) or {}).get(gut, []) or [])
        if moved_items:
            self.section_items.setdefault(to_u, [])
            for iid in moved_items:
                self.section_items[to_u].append(iid)
            self.section_items[gut] = []

        if moved_chars or moved_items:
            tail = f" ({reason})" if reason else ""
            msgs.append(f"🐙 Tripa del Tentaculous: libera {len(moved_chars)} Character(s) y {len(moved_items)} Item(s) a {to_u}.{tail}")
        return msgs


    def on_board_sections(self) -> set[SectionId]:
        """Secciones *On Board* (RM 5.1.6).

        Definición práctica en el prototipo:
        - Excluye OUTER SPACE y MESOSPHERE.
        - Excluye Pods que ya no estén en ON_BOARD (p. ej. lanzados a MESO o ANNIHILATED),
          aunque su SectionId siga existiendo en el grafo por implementación.
        """
        # Nota: excluimos también TENTACULOUS_GUT_SECTION para que no aparezca como
        # destino "normal" en efectos que enumeran secciones On Board (p.ej. Stowaway).
        exclude = {OUTER_SPACE_SECTION, "MESO", OUT_OF_GAME_SECTION, TENTACULOUS_GUT_SECTION}
        res: set[SectionId] = set()
        pods: dict = getattr(self, "pods", {}) or {}

        for s in self.graph.keys():
            su = str(s).upper()
            if su in exclude:
                continue

            # Pods: solo cuentan como On Board si su estado indica ON_BOARD.
            ps = pods.get(su)
            if ps is not None:
                loc = str(getattr(ps, "location", "ON_BOARD")).upper()
                if loc != "ON_BOARD":
                    continue

            res.add(su)

        return res


    def recalc_power_status(self) -> None:
        """§7.2: Normal -> Backup (1 Power Section dañada) -> Blackout (2+ dañadas).

        Efectos (RM 7.2.1 / 7.2.2):
        - Backup Power: CAMERAS y JAMMERS se apagan y no pueden encenderse hasta reparar Power.
        - Blackout:
            * Todas las secciones On Board se vuelven Dark.
            * Console y Section Actions On Board se deshabilitan (salvo Timed Launch y Airlock).
            * Humans/Robots ganan BREACH.
            * OFFICER no puede moverse a través de LOCKS.
        - Al salir de Blackout (volver a Backup/Normal):
            * Se restaura el estado estándar de luz del setup (Dark permanente).
            * Se retiran TODOS los LOCKS.
        """
        old_status = str(getattr(self, "power_status", "Normal Power"))

        n = self.damaged_power_sections_count()
        if n <= 0:
            new_status = "Normal Power"
        elif n == 1:
            new_status = "Backup Power"
        else:
            new_status = "Blackout"

        # Transiciones Blackout <-> no Blackout para manejar luz/locks.
        if old_status != "Blackout" and new_status == "Blackout":
            # Guardar estado de luces por debug (NO lo usaremos para restaurar).
            self.blackout_saved_unlit_sections = set(getattr(self, "unlit_sections", set()))
            # Forzar todo On Board a Dark.
            self.unlit_sections = set(self.on_board_sections())
            # En Blackout, se activa Abandon Ship pero NO se retiran LOCKS.
            self.set_abandon_ship(True, remove_locks=False)
            # RM 7.6.1: Blackout libera Project X.
            try:
                self.release_project_x(reason="BLACKOUT")
            except Exception:
                pass

        if old_status == "Blackout" and new_status != "Blackout":
            # Restaurar el estado estándar de luz del setup:
            # - las secciones impresas como Dark permanecen Dark
            # - cualquier iluminación temporal queda anulada
            default_unlit = set(getattr(self, "default_unlit_sections", set()))

            # Backward-compatible: si no se ha sellado el setup aún, caemos al snapshot.
            if not default_unlit and self.blackout_saved_unlit_sections is not None:
                default_unlit = set(self.blackout_saved_unlit_sections)

            self.unlit_sections = default_unlit
            self.blackout_saved_unlit_sections = None

            # RM 7.2.2.4: al volver a Backup (o mejor), se retiran TODOS los LOCKS.
            self.locks = set()

        self.power_status = new_status

        # Durante Backup/Blackout, el manual fuerza CAMERAS/JAMMERS a OFF.
        if new_status != "Normal Power":
            self.jammers_on = False
            self.cameras_on = False


    def damage_section(self, sec: SectionId) -> bool:
        """Marca una sección como dañada.

        Centralizamos aquí el efecto colateral de *dañar* (por cualquier causa),
        para que el estado de Power se actualice siempre que se dañe una sección
        que tenga icono de Power.

        Devuelve True si la sección pasó de "no dañada" a "dañada".
        """
        if not sec:
            raise ValueError("Sección inválida")

        # Normalizar IDs para que "pod1" y "POD1" sean la misma sección.
        sec = str(sec).upper()

        # RM 5.1.7.2: Outer Space no puede ser dañada.
        if self.is_outer_space(sec):
            raise ValueError("Outer Space no puede ser dañada.")

        if sec in self.damaged_sections:
            return False

        self.damaged_sections.add(sec)

        # Solo las Power Sections afectan al estado global de Power.
        if sec in getattr(self, "power_sections", set()):
            self.recalc_power_status()

        # Security Station (mapa básico): si se daña, CAMERAS y JAMMERS pasan a OFF.
        # (La restricción de "no pueden encenderse" se valida en las Actions.)
        if sec == "SECURITY_STATION":
            try:
                self.jammers_on = False
                self.cameras_on = False
            except Exception:
                pass

        # Fuel Cells (mapa básico): si se daña, coloca FIRE aquí y en TANKS.
        if sec == "FUEL_CELLS":
            try:
                self.add_hazard("FUEL_CELLS", "FIRE")
            except Exception:
                pass
            try:
                self.add_hazard("TANKS", "FIRE")
            except Exception:
                pass

        # RM 7.6.1 + mapa básico: Dañar VAULT_X libera Project X y dispara Abandon Ship.
        if sec == "VAULT_X":
            try:
                self.set_abandon_ship(True, remove_locks=True)
            except Exception:
                pass
            try:
                self.release_project_x(reason="VAULT_X_DAMAGED")
            except Exception:
                pass

        # Modificación de mapa (Engineer — Reactor Token):
        # Si REACTOR pasa a DAMAGED (por cualquier causa salvo Bludgeon, que se valida en Sabotage),
        # añade ASPHYX en Reactor y en secciones conectadas por CORRIDOR (no por vents).
        if sec == "REACTOR" and bool(getattr(self, 'engineer_reactor_token', False)):
            try:
                # Colocar en Reactor.
                self.add_hazard("REACTOR", "ASPHYX")
            except Exception:
                pass

            # Colocar en adyacentes por corridor.
            try:
                for nb in (getattr(self, 'graph', {}) or {}).get("REACTOR", []):
                    try:
                        self.add_hazard(nb, "ASPHYX")
                    except Exception:
                        pass
            except Exception:
                pass

        return True


    def repair_section(self, sec: SectionId) -> bool:
        """Marca una sección como Repaired (quita daño).

        En este prototipo es un helper de debug (más adelante vendrá por Abilities como Jury Rig / Disassemble).
        Devuelve True si la sección estaba dañada y ahora está reparada.
        """
        if not sec:
            raise ValueError("Sección inválida")

        if self.is_outer_space(sec):
            raise ValueError("Outer Space no puede ser reparada/dañada.")

        sec = str(sec).upper()
        if sec not in self.damaged_sections:
            return False

        self.damaged_sections.remove(sec)

        # Si afecta a Power, recalcular para manejar transiciones (incl. salir de Blackout).
        if sec in getattr(self, "power_sections", set()):
            self.recalc_power_status()

        return True



    def pod_launch_requirement_met(self, pod_sec: SectionId) -> bool:
        """True si el Pod ha cumplido su launch requirement (RM 13.6 / 13.7 / 13.8).

        En Stationfall, muchos Pods no pueden lanzarse hasta que Abandon Ship se haya
        disparado (RM 7.1.1). En este prototipo:
        - `pod.requires_abandon_ship` modela ese requisito (por defecto True).
        - `pod.launch_requirement_met` queda como flag adicional para requisitos
          más específicos (aún no modelados).

        Nota: el requisito de "Occupied" se comprueba aparte (`pod_is_occupied`).
        """
        pod_sec = str(pod_sec).upper()
        pod = getattr(self, 'pods', {}).get(pod_sec)
        if not pod:
            return False
        base_ok = bool(getattr(pod, 'launch_requirement_met', True))

        # Station Chief: MEDEVAC_POD puede lanzarse sin Abandon Ship,
        # pero requiere que haya al menos un HUMAN DOWN dentro.
        if pod_sec == 'MEDEVAC_POD' and bool(getattr(self, 'station_chief_medevac_pod', False)):
            has_down_human = False
            for ch in (getattr(self, 'characters', None) or {}).values():
                if str(getattr(ch, 'section', '')).upper() != pod_sec:
                    continue
                if bool(getattr(ch, 'annihilated', False)) or bool(getattr(ch, 'escaped', False)):
                    continue
                if _norm(getattr(ch, 'ctype', '')) != 'HUMAN':
                    continue
                if str(getattr(ch, 'status', '')).upper() == 'DOWN':
                    has_down_human = True
                    break
            return base_ok and has_down_human

        needs_abandon = bool(getattr(pod, 'requires_abandon_ship', True))
        if needs_abandon and (not bool(getattr(self, 'abandon_ship', False))):
            return False
        return base_ok

    def pod_is_occupied(self, pod_sec: SectionId) -> bool:
        """True si el Pod está *Occupied* (RM 5.5.2 / 13.7).

        Regla (manual): un Pod está *Occupied* si contiene al menos un
        **Human/Robot/Monster** (Live o Down).

        En el prototipo:
        - Human/Robot se modelan como `Character` con `ctype` HUMAN/ROBOT.
        - Project X Monsters se modelan aparte (`self.monsters`).
        - Los Items sueltos NO hacen que un Pod cuente como Occupied.

        Nota: si el Pod ya fue lanzado, "Occupied" no suele importar para
        la jugabilidad, pero mantenemos el cálculo por coherencia de UI.
        """
        pod_sec = str(pod_sec).upper()
        if pod_sec not in getattr(self, 'pods', {}):
            return False

        # Monsters in-play.
        for m in (getattr(self, 'monsters', None) or {}).values():
            if str(getattr(m, 'section', '')).upper() == pod_sec:
                return True

        # Human/Robot Characters (Live o Down). No contamos otros types.
        for ch in (getattr(self, 'characters', None) or {}).values():
            if str(getattr(ch, 'section', '')).upper() != pod_sec:
                continue
            if bool(getattr(ch, 'annihilated', False)):
                continue
            t = _norm(getattr(ch, 'ctype', ''))
            if t in ('HUMAN', 'ROBOT'):
                return True

        return False
    # --- Pod helpers (RM 5.5 / 5.6) ---
    def is_pod(self, sec: SectionId) -> bool:
        return sec in getattr(self, 'pods', {})

    def add_pod(self, pod_sec: SectionId, attached_to: SectionId, occupancy_limit: Optional[int] = None) -> None:
        """Añade un Pod al grafo y lo conecta bidireccionalmente a UNA sección.

        Nota: no es una acción del juego; es un helper de setup/debug del prototipo.
        """
        if not pod_sec or not attached_to:
            raise ValueError('Pod/sec inválido')
        pod_sec = str(pod_sec).upper()
        attached_to = str(attached_to).upper()

        if pod_sec in self.pods:
            raise ValueError(f'El Pod {pod_sec} ya existe.')
        if attached_to not in self.graph:
            raise ValueError(f'La sección {attached_to} no existe en el grafo.')

        # Crear el nodo del Pod si no existía.
        self.graph.setdefault(pod_sec, [])

        # Un Pod sólo debe tener UNA conexión on-board: attached_to (bidireccional).
        self.graph[pod_sec] = [attached_to]

        # Asegurar conexión inversa (bidireccional).
        if pod_sec not in self.graph.get(attached_to, []):
            self.graph[attached_to].append(pod_sec)

        # Asegurar que attached_to también aparece como vecino del Pod (por si lo sobrescribieron).
        if attached_to not in self.graph.get(pod_sec, []):
            self.graph[pod_sec].append(attached_to)

        self.pods[pod_sec] = PodState(
            sid=pod_sec,
            attached_to=attached_to,
            location='ON_BOARD',
            occupancy_limit=occupancy_limit,
        )

        # Pods siempre sin gravedad (prototipo).
        try:
            self.set_section_gravity(pod_sec, False)
        except Exception:
            try:
                self.zero_g_sections.add(pod_sec)
            except Exception:
                pass

        # UI/validación: los Pods suelen tener Section Actions de Launch.
        # Aquí añadimos Timed Launch para el prototipo (RM 13.6).
        ra = getattr(self, 'room_actions', None)
        if isinstance(ra, dict):
            ra.setdefault(pod_sec, [])
            if 'Timed Launch' not in ra[pod_sec]:
                ra[pod_sec].append('Timed Launch')

    # --- Pod occupancy (RM 5.5.3) ---
    def counts_as_pod_occupant(self, cid: CharacterId) -> bool:
        """True si este Character cuenta como "occupant" en un Pod.

        Regla (RM 5.5.3): ocupan plaza Humanos y Robots; los Monsters también
        ocupan plaza, pero se cuentan aparte (no son Characters en el modelo).
        Otros tipos (Data/Item/otros) pueden estar "dentro" pero no cuentan.
        """
        ch = self.characters.get(cid)
        if not ch:
            return False
        t = _norm(getattr(ch, 'ctype', ''))
        return t in ('HUMAN', 'ROBOT')

    def pod_occupant_count(self, pod_sec: SectionId) -> int:
        """Cuenta ocupantes actualmente en ese Pod (si está ON_BOARD).

        Regla (RM 5.5.3): cuentan Humanos, Robots y Monsters (Live o Down).
        No cuentan Items ni otros tipos de Character (Data/Item/etc.).
        """
        pod_sec = str(pod_sec).upper()
        pod = self.pods.get(pod_sec)
        if not pod or pod.location != 'ON_BOARD':
            return 0
        n = 0
        # Monsters (Project X) también ocupan plaza.
        for m in (getattr(self, 'monsters', None) or {}).values():
            if str(getattr(m, 'section', '')).upper() != pod_sec:
                continue
            # Live o Down (cualquier status en este prototipo cuenta si está dentro).
            n += 1

        for cid, ch in self.characters.items():
            if str(getattr(ch, 'section', '')).upper() != pod_sec:
                continue
            if getattr(ch, 'annihilated', False) or getattr(ch, 'escaped', False):
                continue
            if self.counts_as_pod_occupant(cid):
                n += 1
        return n

    def pod_can_accept(self, pod_sec: SectionId, entering: List[CharacterId]) -> bool:
        """Comprueba si un Pod puede aceptar (entrar) a estos Characters sin exceder el límite."""
        pod_sec = str(pod_sec).upper()
        pod = self.pods.get(pod_sec)
        if not pod or pod.location != 'ON_BOARD':
            return False
        if pod.occupancy_limit is None:
            return True

        cur = self.pod_occupant_count(pod_sec)
        add = 0
        for cid in entering:
            if cid not in self.characters:
                continue
            ch = self.characters[cid]
            # Si ya está en el Pod, no suma.
            if str(getattr(ch, 'section', '')).upper() == pod_sec:
                continue
            if getattr(ch, 'annihilated', False) or getattr(ch, 'escaped', False):
                continue
            if self.counts_as_pod_occupant(cid):
                add += 1
        return (cur + add) <= int(pod.occupancy_limit)

    def _detach_pod_from_board(self, pod_sec: SectionId) -> None:
        """Rompe las conexiones del Pod con la estación (pierde conexión)."""
        pod_sec = str(pod_sec).upper()
        pod = self.pods.get(pod_sec)
        attached = getattr(pod, 'attached_to', None) if pod else None

        # Quitar aristas desde la estación al pod
        if attached and attached in self.graph:
            self.graph[attached] = [x for x in self.graph.get(attached, []) if str(x).upper() != pod_sec]

        # Quitar aristas desde el pod a cualquier sitio (por seguridad, lo dejamos aislado)
        self.graph[pod_sec] = []

        if pod:
            pod.attached_to = None

    def launch_pod(self, pod_sec: SectionId, source: str = 'LAUNCH') -> str:
        """LAUNCH de Pod.

        RM 5.5.4: If a Damaged Pod is Launched, Annihilate the Pod and everything inside.
        RM 5.6: Everything in Mesosphere has Escaped.

        En este prototipo:
        - Characters "dentro" = aquellos cuya section == pod_sec.
        - Si el Pod está dañado (pod_sec in damaged_sections):
            * Pod -> ANNIHILATED
            * Todos dentro -> ANNIHILATED (OUT_OF_GAME_SECTION)
        - Si no:
            * Pod -> MESO
            * Todos dentro -> ESCAPED
        """
        if not pod_sec:
            raise ValueError('Falta pod_sec')
        pod_sec = str(pod_sec).upper()

        if pod_sec not in self.pods:
            raise ValueError(f'{pod_sec} no es un Pod registrado (state.pods).')

        pod = self.pods[pod_sec]
        if pod.location != 'ON_BOARD':
            raise ValueError(f'El Pod {pod_sec} no está ON_BOARD (estado actual: {pod.location}).')

        # Detach del tablero
        self._detach_pod_from_board(pod_sec)

        damaged = pod_sec in getattr(self, 'damaged_sections', set())
        inside = [ch for ch in self.characters.values() if str(getattr(ch, 'section', '')).upper() == pod_sec]

        if damaged:
            pod.location = 'ANNIHILATED'

            # Todo dentro, aniquilado (Character + posesiones)
            for ch in inside:
                self.annihilate_character(ch.cid, reason=f"{source}: POD DAMAGED")            # Items sueltos en el pod: si hay Antimatter, NO se aniquila; detona (RM 7.3.3).
            loose = list(getattr(self, 'section_items', {}).get(pod_sec, []) or [])
            if loose and not bool(getattr(self, 'antimatter_detonated', False)):
                for _iid in loose:
                    _iid_u = str(_iid).upper()
                    it = getattr(self, 'items', {}).get(_iid_u)
                    if it and _norm(getattr(it, 'kind', '')) == 'ANTIMATTER':
                        try:
                            self.detonate_antimatter_now(
                                reason=f"{source}: would be annihilated in damaged pod {pod_sec}",
                                override_section=pod_sec,
                            )
                        except Exception:
                            pass
                        break

            # Ahora sí: el resto de items sueltos salen del juego (OUT_OF_GAME_SECTION)
            if pod_sec in getattr(self, 'section_items', {}):
                self.section_items.setdefault(OUT_OF_GAME_SECTION, []).extend(self.section_items.get(pod_sec, []))
                self.section_items.pop(pod_sec, None)

            base = f'LAUNCH Pod {pod_sec} (DAMAGED) -> ANNIHILATED | dentro={len(inside)}'

        else:
            # Pod sano: llega a Mesosphere
            pod.location = 'MESO'
            for ch in inside:
                if ch.annihilated:
                    continue
                ch.escaped = True
                # Importante: los dejamos en section=pod_sec para reflejar que siguen "en el pod"
                # pero el pod está en Mesosphere y está fuera del juego.

            base = f'LAUNCH Pod {pod_sec} -> MESO (ESCAPED) | dentro={len(inside)}'

        src = str(source).strip()
        if src.upper() == 'DEBUG':
            return 'DEBUG: ' + base
        if src:
            return f'{src}: ' + base
        return base