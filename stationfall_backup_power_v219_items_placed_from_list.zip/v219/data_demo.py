import random

import abilities as AB

from models import (
    GameState,
    PlayerState,
    Character,
    IdentityCard,
    Monster,
    Item,
    OUT_OF_GAME_SECTION,
    OUTER_SPACE_SECTION,
)

from map_modules import apply_map_modules


# --- Post-load UI fixes -------------------------------------------------
#
# Los saves guardan una snapshot completa (pickle). Si corregimos textos
# “estáticos” de cartas (agenda_points) en el código, un save antiguo seguirá
# mostrando el texto viejo. Estas funciones aplican parches *solo de UI*
# (no cambian reglas ni estado jugable).

SECURITY_AGENDA_POINTS = [
    (1, "1 pt por cada Fugitive, Monster o PC de jugador no-Innocent que esté DOWN a bordo en Stationfall"),
    (1, "1 pt por cada Human con Gun o Bludgeon que esté DOWN a bordo en Stationfall"),
    (1, "1 pt si Briefcase NO escapa"),
    (1, "1 pt si Artifact NO escapa"),
    (1, "+1 si Briefcase y Artifact NO escapan"),
]


def apply_post_load_ui_fixes(state: GameState) -> None:
    """Aplica parches de texto/labels a un estado cargado desde save."""
    try:
        ch = (getattr(state, "characters", {}) or {}).get("C19")
        if ch is not None:
            # Solo texto; no toca habilidades/estado.
            ch.agenda_points = list(SECURITY_AGENDA_POINTS)
    except Exception:
        pass


def make_demo_state(num_players: int = 2, seed: int | None = None, player_names: list[str] | None = None) -> GameState:
    """Construye un estado jugable con el mapa de Stationfall.

    OJO: este archivo ya no mete personajes/secciones inventadas "de demo".
    Solo deja un estado estable con el mapa base + los 12 personajes del
    tutorial (Launch Manual).

    El setup *real* lo haremos después, pero aquí ya dejamos un INICIO jugable:

    - Se crean N jugadores (1–6).
    - Se reparten 2 Identity Cards por jugador (PC/BC) de entre el set tutorial.

    Nota: los detalles finos del setup (orden de elección, bots, etc.) los
    implementaremos más adelante.
    """

    if seed is not None:
        random.seed(int(seed))

    # --- Players ---
    if not (1 <= int(num_players) <= 6):
        raise ValueError("num_players debe estar entre 1 y 6 (inclusive)")

    players: list[PlayerState] = []
    names = list(player_names) if player_names else []
    for i in range(int(num_players)):
        pid = f"P{i+1}"
        nm = names[i] if i < len(names) else f"Jugador {i+1}"
        players.append(PlayerState(pid=pid, name=nm, kind="HUMANO", supply_cubes=8, betrayal_cubes=0, bribes=2, legal="Innocent"))


    # --- Identity Cards (set del tutorial) ---
    # Metadata de Bonus Points que viene impresa en la Identity Card (Dossier).
    identity_cards = {
        # Friend
        "C13": IdentityCard(cid="C13", bonus_kind="FRIEND", bonus_icons=2),  # Astrochimp
        "C14": IdentityCard(cid="C14", bonus_kind="FRIEND", bonus_icons=2),  # Counselor
        "C15": IdentityCard(cid="C15", bonus_kind="FRIEND", bonus_icons=2),  # Daredevil
        "C17": IdentityCard(cid="C17", bonus_kind="FRIEND", bonus_icons=2),  # Exile
        "C20": IdentityCard(cid="C20", bonus_kind="FRIEND", bonus_icons=2),  # Stowaway
        "C22": IdentityCard(cid="C22", bonus_kind="FRIEND", bonus_icons=2),  # Troubleshooter
        "C23": IdentityCard(cid="C23", bonus_kind="FRIEND", bonus_icons=2),  # Stranger

        # Grudge
        "C7":  IdentityCard(cid="C7",  bonus_kind="GRUDGE", bonus_icons=2),  # Engineer
        "C16": IdentityCard(cid="C16", bonus_kind="GRUDGE", bonus_icons=2),  # Cyborg
        "C18": IdentityCard(cid="C18", bonus_kind="GRUDGE", bonus_icons=1),  # Medical
        "C19": IdentityCard(cid="C19", bonus_kind="GRUDGE", bonus_icons=3),  # Security
        "C21": IdentityCard(cid="C21", bonus_kind="GRUDGE", bonus_icons=2),  # Station Chief
    }

    # NOTA: el reparto de Identity Cards (2 por jugador) se hace en el pregame
    # mediante un comando (p.ej. `deal`). Aquí sólo dejamos el catálogo
    # `identity_cards` para que el motor sepa puntuar Bonus Points.

    # --- Characters (solo reales; set del tutorial) ---

    # --- ASTROCHIMP ---
    # Setup: KITCHEN
    # Abilities: TUNNEL RAT, LOYAL
    # Reveal Power (Acrobatics): gains ZEROBORN
    # Agenda (SHINY THINGS): 3 pts si Escapes; +2 si Escapes con Briefcase/Artifact/Gun
    c13 = Character(
        cid="C13",
        name="Astrochimp",
        ctype="Human",
        section="KITCHEN",
        status="LIVE",
        item_limit=3,
        abilities={AB.TUNNEL_RAT, AB.LOYAL},
        pc_reveal_abilities={AB.ZEROBORN},
        agenda_points=[
            (3, "SHINY THINGS: 3 pts si Astrochimp ESCAPA"),
            (2, "+2 si ESCAPA con Briefcase"),
            (2, "+2 si ESCAPA con Artifact"),
            (2, "+2 si ESCAPA con Gun"),
        ],
        influence_limit=5,
    )

    # --- COUNSELOR ---
    # Setup: THERAPY_GARDEN (y añade SHRED_ROOM con Data Mine)
    c14 = Character(
        cid="C14",
        name="Counselor",
        ctype="Human",
        section="THERAPY_GARDEN",
        status="LIVE",
        item_limit=3,
        abilities={AB.OFFICER, AB.WORMTONGUE},
        pc_reveal_powers={AB.RECORDED_CONFESSIONAL},
        agenda_points=[
            (2, "CLOAK AND DAGGER: 2 pts si Counselor ESCAPA"),
            (4, "4 pts si Artifact ESCAPA"),
            (2, "2 pts si tienes más Kompromat que cualquier otro jugador en Stationfall"),
            (1, "1 pt si tienes los menos cubos en Betrayal Box en Stationfall"),
        ],
        influence_limit=6,
    )

    # --- DAREDEVIL ---
    # Setup: LOCKER_ROOM (y coloca ROCKET WINGS en PHYSICS_LAB; Launch Manual/Tutorial)
    c15 = Character(
        cid="C15",
        name="Daredevil",
        ctype="Human",
        section="LOCKER_ROOM",
        status="LIVE",
        item_limit=3,
        abilities={AB.PRIDE, AB.ADRENALINE},
        pc_reveal_powers={AB.POINT_BREAK},
        agenda_points=[
            (3, "THRILLSEEKER: 3 pts si Daredevil ESCAPA"),
            (2, "+2 si es el ONLY HUMAN que ESCAPA"),
            (2, "+2 si posee ARTIFACT OR está CONTAMINATED"),
            (1, "1 pt si Project X fue RELEASED"),
        ],
        influence_limit=5,
    )

    # --- CYBORG ---
    c16 = Character(
        cid="C16",
        name="Cyborg",
        ctype="Human and Robot",
        section="CRYO_LAB",
        status="LIVE",
        item_limit=3,
        abilities={AB.INMUNITY, AB.FUGITIVE, AB.UNCANNY},
        pc_reveal_abilities={AB.BRUTAL, AB.SELF_REPAIR},
        agenda_points=[
            (1, "REVENGE: 1 pt por cada OFFICER que esté DOWN en Stationfall"),
            (2, "2 pts si ningún PC Human ESCAPA"),
            (2, "2 pts si no escapa ninguna CONTAMINATION"),
            (2, "2 pts si Project X fue RELEASED"),
        ],
        influence_limit=4,
    )

    # --- ENGINEER ---
    # (activa Engineer Reactor Token via map_modules)
    c7 = Character(
        cid="C7",
        name="Engineer",
        ctype="Human",
        section="ARRAY_CONTROL",
        status="LIVE",
        item_limit=3,
        # Dossier: Officer + Jury Rig (Disassemble es de Drones, no de Engineer)
        abilities={AB.OFFICER, AB.JURY_RIG, AB.INMUNITY},
        pc_reveal_powers={AB.OVERLOAD},
        agenda_points=[
            (3, "3 pts si Antimatter detona ON BOARD antes de Stationfall"),
            (3, "3 pts si no escapa ninguna CONTAMINATION"),
            (2, "2 pts si Artifact NO escapa"),
            (1, "1 pt si terminas INNOCENT"),
        ],
        influence_limit=5,
    )

    # --- EXILE ---
    c17 = Character(
        cid="C17",
        name="Exile",
        ctype="Human",
        section="ARRAY_CONTROL",
        status="LIVE",
        item_limit=3,
        abilities={AB.FAST_TALK, AB.HACKER},
        pc_reveal_abilities={AB.BLOOD_FROM_A_STONE, AB.TRADECRAFT},
        agenda_points=[
            (2, "BACK IN THE GAME: 2 pts si Exile ESCAPA"),
            (2, "+2 por cada KOMPROMAT poseído de personajes que ESCAPAN"),
            (3, "+3 si Exile tiene EVIDENCE y NEWS no tiene EVIDENCE"),
        ],
        influence_limit=6,
    )

    # --- MEDICAL ---
    c18 = Character(
        cid="C18",
        name="Medical",
        ctype="Robot",
        section="AFT_HUB",
        status="LIVE",
        item_limit=3,
        # Dossier: Emergency Response + Helpful
        abilities={AB.HELPFUL, AB.EMERGENCY_RESPONSE_ALPHA, AB.EMERGENCY_RESPONSE_BETA},
        # Dossier: Haywire (gana un Bludgeon)
        pc_reveal_powers={AB.HAYWIRE},
        agenda_points=[
            (2, "2 pts si no hay Humans DOWN a bordo en Stationfall"),
            (1, "1 pt por cada estrella en el Medical Track"),
        ],
        influence_limit=4,
        data={"MEDICAL_TRACK": 0},
    )

    # --- SECURITY ---
    c19 = Character(
        cid="C19",
        name="Security",
        ctype="Robot",
        section="PRINT_SHOP",
        status="LIVE",
        item_limit=3,
        # Dossier: Peacekeeper + Armored
        abilities={AB.PEACEKEEPER, AB.ARMORED},
        # Dossier: Authorized Force (al revelarse, pierde Peacekeeper)
        pc_reveal_powers={AB.AUTHORIZED_FORCE},
        # Dossier: Peace Through Superior Firepower
        agenda_points=list(SECURITY_AGENDA_POINTS),
        influence_limit=4,
        items=["I11"],  # Gun integral
    )

    # --- STATION CHIEF ---
    # (activa Medevac Pod via map_modules)
    c21 = Character(
        cid="C21",
        name="Station Chief",
        ctype="Human",
        section="THERAPY_GARDEN",
        status="LIVE",
        item_limit=3,
        # Dossier: Officer + Pride (Forceful Presence se activa al revelar como PC)
        abilities={AB.OFFICER, AB.PRIDE},
        pc_reveal_abilities={AB.FORCEFUL_PRESENCE},
        pc_reveal_powers=set(),
        # Scoring (según dossier):
        # - 1 pt por cada OTRO Human que ESCAPA
        # - +1 pt adicional por cada NPC con OFFICER que ESCAPA
        # - +2 pts si, en Stationfall, Station Chief está ON BOARD y LIVE
        agenda_points=[
            (1, "1 pt por cada OTRO Human que ESCAPA"),
            (1, "+1 pt por cada NPC con OFFICER que ESCAPA"),
            (2, "+2 pts si en Stationfall Station Chief está ON BOARD y LIVE"),
        ],
        influence_limit=5,
    )

    # --- STOWAWAY ---
    # Empieza fuera del tablero.
    c20 = Character(
        cid="C20",
        name="Stowaway",
        ctype="Human",
        section=OUT_OF_GAME_SECTION,
        status="LIVE",
        item_limit=3,
        # Dossier: Tunnel Rat + Hacker; Reveal Power: Secret Cache (Helmet)
        abilities={AB.TUNNEL_RAT, AB.HACKER},
        pc_reveal_powers={AB.SECRET_CACHE},
        agenda_points=[
            (2, "2 pts si NEWS termina con X-SECRET"),
            (2, "2 pts si NEWS termina con EVIDENCE"),
            (2, "2 pts si Stowaway ESCAPA"),
            (3, "+3 pts si ESCAPA con EVIDENCE y NINGÚN OTRO Character ESCAPA con EVIDENCE"),
        ],
        influence_limit=4,
    )

    # --- TROUBLESHOOTER ---
    # (activa Cargo Claw via map_modules)
    c22 = Character(
        cid="C22",
        name="Troubleshooter",
        ctype="Human",
        section="PRINT_SHOP",
        status="LIVE",
        item_limit=3,
        # Dossier: Tunnel Rat + Jury Rig; Reveal Power: Talk Them Through It
        abilities={AB.TUNNEL_RAT, AB.JURY_RIG},
        pc_reveal_abilities={AB.TALK_THEM_THROUGH_IT},
        agenda_points=[
            (2, "2 pts si Antimatter no está ARMED en Stationfall"),
            (2, "2 pts si Project X nunca fue RELEASED"),
            (2, "2 pts si no hay secciones DAMAGED en Stationfall"),
            (1, "1 pt por cada Robot LIVE en Stationfall"),
        ],
        influence_limit=6,
        items=["I12"],  # Bludgeon
    )

    # --- STRANGER ---
    c23 = Character(
        cid="C23",
        name="Stranger",
        ctype="Human",
        section="NANOFACTORY",
        status="LIVE",
        item_limit=3,
        abilities={AB.UNCANNY},
        pc_reveal_powers={AB.HOMEWORK, AB.ENIGMA},
        agenda_points=[
            (1, "1 point if your Secret Identity is not revealed until Stationfall"),
            (1, "1 point if Possess X-Secret"),
            (2, "2 points if you score Bonus Points"),
            (2, "2 points if Live and Colocated with a Bonus Character of yours at Stationfall"),
        ],
        influence_limit=6,
    )

    characters = {c.cid: c for c in [c7, c13, c14, c15, c16, c17, c18, c19, c20, c21, c22, c23]}

    # --- Graph ---
    graph: dict[str, list[str]] = {}

    def _add_edge(a: str, b: str) -> None:
        a = str(a).upper()
        b = str(b).upper()
        graph.setdefault(a, [])
        graph.setdefault(b, [])
        if b not in graph[a]:
            graph[a].append(b)
        if a not in graph[b]:
            graph[b].append(a)

    # AFT cluster
    # (mantenemos el grafo tal cual venía en v145 para no romper conectividad)
    _add_edge("AFT_AIRLOCKS", "MACHINE_SHOP")
    _add_edge("AFT_AIRLOCKS", "REACTOR")
    _add_edge("MACHINE_SHOP", "AFT_HUB")
    _add_edge("REACTOR", "AFT_HUB")
    _add_edge("AFT_HUB", "THERAPY_GARDEN")
    _add_edge("AFT_HUB", "REC_ROOM")
    _add_edge("AFT_HUB", "FORWARD_HUB")
    _add_edge("AFT_HUB", "ARRAY_CONTROL")
    _add_edge("REC_ROOM", "SECURITY_STATION")
    _add_edge("REC_ROOM", "SUITE")
    _add_edge("SECURITY_STATION", "AFT_EXHAUST")
    _add_edge("AFT_EXHAUST", "STORAGE")
    _add_edge("THERAPY_GARDEN", "STORAGE")
    _add_edge("THERAPY_GARDEN", "QUARTERS")
    _add_edge("QUARTERS", "KITCHEN")
    _add_edge("KITCHEN", "SUITE")

    # Reactor & Magnetic Containment (con Lock)
    _add_edge("REACTOR", "MAGNETIC_CONTAINMENT")

    # Forward cluster
    _add_edge("ARRAY_CONTROL", "FORWARD_HUB")
    _add_edge("FORWARD_HUB", "NANOFACTORY")
    _add_edge("FORWARD_HUB", "BIO_LAB")
    _add_edge("FORWARD_HUB", "TANKS")
    _add_edge("FORWARD_HUB", "PHYSICS_LAB")
    _add_edge("BIO_LAB", "CRYO_LAB")
    _add_edge("BIO_LAB", "CHEM_LAB")
    _add_edge("CRYO_LAB", "NANOFACTORY")
    _add_edge("NANOFACTORY", "MAINFRAME")
    _add_edge("MAINFRAME", "PHYSICS_LAB")
    _add_edge("PHYSICS_LAB", "PRINT_SHOP")
    _add_edge("PRINT_SHOP", "FORWARD_EXHAUST")
    _add_edge("FORWARD_EXHAUST", "CHEM_LAB")

    # Cryo Lab & Vault X (con Lock)
    _add_edge("CRYO_LAB", "VAULT_X")

    # Tanks cluster
    _add_edge("TANKS", "LOCKER_ROOM")
    _add_edge("TANKS", "HYDROPONICS")
    _add_edge("TANKS", "FORWARD_AIRLOCKS")
    _add_edge("TANKS", "FUEL_CELLS")
    _add_edge("TANKS", "STORM_SHELTER")
    _add_edge("FORWARD_AIRLOCKS", "BRIDGE")

    # Off-station areas
    graph.setdefault("MESO", [])
    graph.setdefault(OUTER_SPACE_SECTION, [])

    # --- Monsters (Project X) — pendiente en VAULT_X ---
    m1 = Monster(
        mid="M1",
        name="Tentacled Monstrosity",
        kind="TENTACLED",
        section="VAULT_X",
        status="LIVE",
        abilities={AB.JUGGERNAUT, AB.WARY},
    )
    project_x_pending_monsters = {"M1": m1}
    monsters: dict[str, Monster] = {}

    # --- Items ---
    items = {
        # Setup base del tablero/tutorial
        "I5": Item(iid="I5", name="Briefcase", kind="item"),
        "I6": Item(iid="I6", name="Nanogel", kind="item", charges=2),
        # Segundo Nanogel inicial (para que exista el del LOCKER_ROOM sin quitar el de FORWARD_HUB)
        "I8": Item(iid="I8", name="Nanogel", kind="item", charges=2),
        "I7": Item(iid="I7", name="Antimatter", kind="ANTIMATTER"),
        "I9": Item(iid="I9", name="Artifact", kind="item"),

        "I10": Item(iid="I10", name="Helmet", kind="HELMET"),

        # Items en personaje (integrales / equipamiento fijo)
        "I11": Item(iid="I11", name="Gun", kind="item", integral_bound_to="C19"),
        "I12": Item(iid="I12", name="Bludgeon", kind="item"),
    }

    section_items = {
        "MAGNETIC_CONTAINMENT": ["I7"],
        "PHYSICS_LAB": ["I9"],
        "SUITE": ["I5"],
        # Helmet inicial (Tutorial): en AFT_AIRLOCKS
        "AFT_AIRLOCKS": ["I10"],
        # Un Nanogel inicial (para que exista el flujo de Revive desde el principio)
        "FORWARD_HUB": ["I6"],
        # Nanogel inicial adicional en LOCKER_ROOM (sin quitar el de FORWARD_HUB)
        "LOCKER_ROOM": ["I8"],
    }

    # --- Kompromat Tokens (Tutorial setup) ---
    # Limpia cualquier Kompromat previo de demo (si existiera).
    demo_k = [iid for iid, it in items.items() if str(getattr(it, 'kind', '')).lower() == 'kompromat']
    if demo_k:
        demo_set = {str(x).upper() for x in demo_k}
        for iid in list(demo_set):
            items.pop(iid, None)
        for sec in list(section_items.keys()):
            arr = [x for x in (section_items.get(sec, []) or []) if str(x).upper() not in demo_set]
            if arr:
                section_items[str(sec).upper()] = arr
            else:
                section_items.pop(str(sec).upper(), None)
    for p in players:
        p.kompromat_hand = []

    # 12 Kompromats, uno por cada personaje del set del tutorial.
    # Se colocan en 12 secciones concretas; algunos fijos para test, el resto aleatorio (seedable via make_demo_state(seed=...)).
    komp_sections = [
        'ALCATRAZ', 'MCQUEEN', 'AFT_EXHAUST', 'REC_ROOM', 'BRIDGE',
        'FORWARD_AIRLOCKS', 'STORM_SHELTER', 'LOCKER_ROOM', 'CHEM_LAB',
        'NANOFACTORY', 'KITCHEN', 'THERAPY_GARDEN',
    ]

    # Kompromat placement (PBF tutorial reconstruction + resto aleatorio).
    # Fijamos los que hemos podido inferir del Play-By-Forum y dejamos el resto
    # aleatorio entre las secciones restantes (seedable).
    fixed = {
        'THERAPY_GARDEN': 'C13',       # Astrochimp
        'REC_ROOM': 'C14',             # Counselor
        'NANOFACTORY': 'C23',          # Stranger
        'CHEM_LAB': 'C22',             # Troubleshooter
        'FORWARD_AIRLOCKS': 'C21',     # Station Chief
        'LOCKER_ROOM': 'C15',          # Daredevil
        'ALCATRAZ': 'C7',              # Engineer
    }

    remaining_secs = [s for s in komp_sections if str(s).upper() not in {k.upper() for k in fixed.keys()}]
    all_cids = [str(c.cid).upper() for c in characters.values()]
    fixed_cids = {str(v).upper() for v in fixed.values()}
    remaining_cids = [cid for cid in all_cids if cid not in fixed_cids]

    # Empareja el resto al azar (respetando seed si lo pasas a make_demo_state).
    random.shuffle(remaining_secs)
    random.shuffle(remaining_cids)

    placement = {str(k).upper(): str(v).upper() for k, v in fixed.items()}
    for sec, cid in zip(remaining_secs, remaining_cids):
        placement[str(sec).upper()] = str(cid).upper()

    # IDs nuevos para Kompromat: reservamos un rango alto para no chocar con Items 'reales'.
    max_num = 0
    for kid in items.keys():
        k = str(kid).upper()
        if k.startswith('I') and k[1:].isdigit():
            max_num = max(max_num, int(k[1:]))
    start = max(100, max_num + 1)
    new_ids = [f'I{start + i}' for i in range(len(komp_sections))]

    for iid, sec in zip(new_ids, komp_sections):
        tgt = placement.get(str(sec).upper())
        if not tgt:
            continue
        tgt_name = characters[tgt].name if tgt in characters else str(tgt)
        items[str(iid).upper()] = Item(iid=str(iid).upper(), name=f'Kompromat({tgt_name})', kind='kompromat', kompromat_target=str(tgt).upper())
        section_items.setdefault(str(sec).upper(), []).append(str(iid).upper())



    # --- BOARD ITEMS SETUP (Tutorial / PBF) -----------------------------------
    # Primero dejamos el tablero sólo con Kompromats (y los items que ya empiezan en personajes).
    # Después colocamos EXACTAMENTE los items del listado del usuario (incluyendo pods).
    allowed_character_items = set()
    for ch in characters.values():
        for iid in (getattr(ch, "items", None) or []):
            allowed_character_items.add(str(iid).upper())

    kompromat_items = {
        str(iid).upper()
        for iid, it in items.items()
        if str(getattr(it, "kind", "")).lower() == "kompromat"
    }

    # 1) Limpia items del tablero: en sections/pods quedan sólo Kompromats
    for sec in list(section_items.keys()):
        keep = [iid for iid in (section_items.get(sec, []) or []) if str(iid).upper() in kompromat_items]
        if keep:
            section_items[str(sec).upper()] = keep
        else:
            section_items.pop(str(sec).upper(), None)

    # 2) Elimina del pool de items todo lo que no sea Kompromat o item inicial de personaje
    allowed_items = kompromat_items | allowed_character_items
    for iid in list(items.keys()):
        if str(iid).upper() not in allowed_items:
            items.pop(iid, None)

    # 3) Añade items del tablero según lista (sin tocar los Kompromats)
    def _ensure_item(iid: str, name: str, kind: str, **kwargs) -> str:
        iid_u = str(iid).upper()
        if iid_u not in items:
            items[iid_u] = Item(iid=iid_u, name=name, kind=kind, **kwargs)
        return iid_u

    def _place(sec: str, iid: str):
        sec_u = str(sec).upper()
        section_items.setdefault(sec_u, [])
        cur = [str(x).upper() for x in (section_items.get(sec_u, []) or [])]
        if str(iid).upper() not in cur:
            section_items[sec_u].append(str(iid).upper())

    # Suite: Briefcase
    _place("SUITE", _ensure_item("I5", "Briefcase", "item"))

    # Reactor + Locker Room: Nanogels
    _place("REACTOR", _ensure_item("I6", "Nanogel", "item", charges=2))
    _place("LOCKER_ROOM", _ensure_item("I8", "Nanogel", "item", charges=2))

    # Magnetic Containment: Antimatter
    _place("MAGNETIC_CONTAINMENT", _ensure_item("I7", "Antimatter", "ANTIMATTER"))

    # Helmets (5 copias): Hail Mary, Aft Airlocks, Storm Shelter, Storage, Forward Airlocks
    _place("HAIL_MARY", _ensure_item("I10", "Helmet", "HELMET"))
    _place("AFT_AIRLOCKS", _ensure_item("I13", "Helmet", "HELMET"))
    _place("STORM_SHELTER", _ensure_item("I14", "Helmet", "HELMET"))
    _place("STORAGE", _ensure_item("I15", "Helmet", "HELMET"))
    _place("FORWARD_AIRLOCKS", _ensure_item("I16", "Helmet", "HELMET"))

    # Bludgeons (en tablero): Machine Shop, Storage, Hydroponics
    _place("MACHINE_SHOP", _ensure_item("I17", "Bludgeon", "item"))
    _place("STORAGE", _ensure_item("I18", "Bludgeon", "item"))
    _place("HYDROPONICS", _ensure_item("I19", "Bludgeon", "item"))

    # Physics Lab: Artifact + Rocket Wings (sólo si está Daredevil en el set)
    has_daredevil = any(
        (str(getattr(c, "name", "")).upper() == "DAREDEVIL")
        or (str(getattr(c, "cid", "")).upper() == "C15")
        for c in characters.values()
    )
    if has_daredevil:
        _place("PHYSICS_LAB", _ensure_item("I9", "Artifact", "item"))
        _place("PHYSICS_LAB", _ensure_item("I20", "Rocket Wings", "ROCKET_WINGS"))

    # Influence (empieza limpio; cada jugador coloca cubos en su turno)
    influence = {p.pid: {} for p in players}

    # En Stationfall el Minute track cuenta hacia atrás (13 -> 0).
    state = GameState(
        minute=13,
        players=players,
        characters=characters,
        project_x_pending_monsters=project_x_pending_monsters,
        monsters=monsters,
        graph=graph,
        items=items,
        section_items=section_items,
        influence=influence,
    )

    # Identity Cards (Bonus Points metadata)
    state.identity_cards = dict(identity_cards)

    # --- Propiedades del mapa ---
    # Contamination: BIO_LAB contamina al entrar (salvo que haya FIRE; lo gestionamos en models.py).
    state.contamination_sections = {"BIO_LAB"}

    # Re-entry token (Minute 0): 2/3 STATIONFALL, 1/3 SAFE
    try:
        state.set_reentry_token(random.choice(["STATIONFALL", "STATIONFALL", "SAFE"]))
    except Exception:
        state.reentry_token = random.choice(["STATIONFALL", "STATIONFALL", "SAFE"])
        state.reentry_revealed = False

    # Hazards iniciales
    state.hazards = {
        "MAGNETIC_CONTAINMENT": {"ASPHYX"},
    }

    # Outer Space invariants (ASPHYX permanente).
    if hasattr(state, "ensure_outer_space_invariants"):
        state.ensure_outer_space_invariants()

    # Gravedad
    # (Mantengo esta lista tal cual la veníamos usando; si luego la ajustas con el PDF/board, lo hacemos.)
    zero_g_true = {
        "AFT_AIRLOCKS",
        "MACHINE_SHOP",
        "REACTOR",
        "MAGNETIC_CONTAINMENT",
        "AFT_HUB",
        "ARRAY_CONTROL",
        "FORWARD_HUB",
        "TANKS",
        "LOCKER_ROOM",
        "HYDROPONICS",
        "FORWARD_AIRLOCKS",
        "FUEL_CELLS",
        "STORM_SHELTER",
        "BRIDGE",
        OUTER_SPACE_SECTION,
        "MESO",
    }
    state.zero_g_sections = set(zero_g_true)

    # Luces (Dark impresas)
    state.unlit_sections = {
        "AFT_AIRLOCKS",
        "AFT_EXHAUST",
        "FORWARD_EXHAUST",
        "TANKS",
        "LOCKER_ROOM",
        OUTER_SPACE_SECTION,
        "MCQUEEN",  # Pod McQueen es Dark
    }
    if hasattr(state, "seal_default_lighting"):
        state.seal_default_lighting()
    else:
        state.default_unlit_sections = set(state.unlit_sections)

    # Power sections
    state.power_sections = {"REACTOR", "MAINFRAME", "FUEL_CELLS"}
    if hasattr(state, "recalc_power_status"):
        state.recalc_power_status()

    # Airlocks
    if hasattr(state, "add_airlock"):
        state.add_airlock("AFT_AIRLOCKS", to_outer=True, from_outer=True)
        state.add_airlock("FORWARD_AIRLOCKS", to_outer=True, from_outer=True)
        state.add_airlock("AFT_EXHAUST", to_outer=True, from_outer=False)
        state.add_airlock("FORWARD_EXHAUST", to_outer=True, from_outer=False)

    # Vents
    state.vents = {
        "AFT_AIRLOCKS": ["AFT_HUB"],
        "AFT_HUB": ["AFT_AIRLOCKS", "AFT_EXHAUST"],
        "AFT_EXHAUST": ["AFT_HUB"],
        "KITCHEN": ["REACTOR"],
        "REACTOR": ["KITCHEN"],
        "FORWARD_HUB": ["MAINFRAME", "CHEM_LAB", "FORWARD_EXHAUST"],
        "MAINFRAME": ["FORWARD_HUB"],
        "CHEM_LAB": ["FORWARD_HUB"],
        "FORWARD_EXHAUST": ["FORWARD_HUB"],
    }

    # Locks (corridors)
    try:
        state.add_lock_corridor("REACTOR", "MAGNETIC_CONTAINMENT")
        state.add_lock_corridor("CRYO_LAB", "VAULT_X")
    except Exception:
        state.locks = {
            ("MAGNETIC_CONTAINMENT", "REACTOR") if "MAGNETIC_CONTAINMENT" <= "REACTOR" else ("REACTOR", "MAGNETIC_CONTAINMENT"),
            ("CRYO_LAB", "VAULT_X") if "CRYO_LAB" <= "VAULT_X" else ("VAULT_X", "CRYO_LAB"),
        }

    # Pods básicos (todos conectados a AFT_AIRLOCKS, Timed Launch, requieren Abandon Ship, límite 3)
    if hasattr(state, "add_pod"):
        for pod in ["MCQUEEN", "ALCATRAZ", "HOUDINI", "HAIL_MARY"]:
            state.add_pod(pod, "AFT_AIRLOCKS", occupancy_limit=3)
        # McQueen es Dark
        try:
            state.set_lit("MCQUEEN", False)
        except Exception:
            state.unlit_sections.add("MCQUEEN")

    # --- Acciones impresas por sección (para HUD + validación "según lo impreso") ---
    state.room_actions = {
        # AFT
        "AFT_AIRLOCKS": ["Airlock", "Section Launch"],
        "MACHINE_SHOP": ["Repair"],
        "REACTOR": [],
        "MAGNETIC_CONTAINMENT": ["Eject Antimatter"],
        "AFT_HUB": [],
        "REC_ROOM": [],
        "SECURITY_STATION": [
            "Console: Jammers ON/OFF",
            "Console: Hazard Suppression",
            "Cameras: ON/OFF",
            "Manufacture: EVIDENCE (Data)",
        ],
        "AFT_EXHAUST": ["Airlock"],
        "THERAPY_GARDEN": ["Meditate"],
        "STORAGE": [],
        "QUARTERS": [],
        "KITCHEN": [],
        "SUITE": [],
        "ARRAY_CONTROL": ["Transmit: 1 Data -> Offsite"],

        # Forward
        "FORWARD_HUB": [],
        "BIO_LAB": ["Manufacture: X-SECRET (Data)"],
        "CRYO_LAB": ["Release Project X"],
        "VAULT_X": [],
        "NANOFACTORY": ["Manufacture: NANOGEL (Item)"],
        "MAINFRAME": ["Console: Jammers ON/OFF", "Console: Hazard Suppression"],
        "PHYSICS_LAB": [],
        "PRINT_SHOP": [
            "Manufacture: HELMET (Item)",
            "Manufacture: BLUDGEON (Item)",
            "Manufacture: PISTOL (Item)",
        ],
        "CHEM_LAB": ["Manufacture: BOMB (Item)"],
        "FORWARD_EXHAUST": ["Airlock"],

        # Tanks
        "TANKS": ["Decontaminate"],
        "LOCKER_ROOM": [],
        "HYDROPONICS": [],
        "FORWARD_AIRLOCKS": ["Airlock"],
        "FUEL_CELLS": [],
        "STORM_SHELTER": [],

        # Bridge
        "BRIDGE": ["Bridge Launch", "Abandon Ship", "Self-Destruct", "Release Project X"],

        # Off-board (no es sección real del tablero, pero nos vale como zona de juego)
        "MESO": [],
        OUTER_SPACE_SECTION: [],
    }

    # Pods: que aparezca Timed Launch en HUD
    for pod in ["MCQUEEN", "ALCATRAZ", "HOUDINI", "HAIL_MARY"]:
        state.room_actions.setdefault(pod, [])
        if not any("TIMED LAUNCH" in str(x).upper() for x in state.room_actions[pod]):
            state.room_actions[pod].append("Timed Launch")

    # Módulos opcionales del mapa (dependientes de Characters en juego)
    try:
        state.map_modules_applied = apply_map_modules(state)
    except Exception:
        state.map_modules_applied = []

    return state