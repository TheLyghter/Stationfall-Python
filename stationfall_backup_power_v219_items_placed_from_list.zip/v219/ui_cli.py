from __future__ import annotations

import abilities as AB

from dataclasses import dataclass
from typing import List, Optional
import copy
import re
import shlex

from actions import (
    Reveal,
    SchrodingerReveal,
    ActionError,
    PlaceInfluence,
    RenegotiateTakeBack,
    Activate,
    Move,
    ZeroBornMove,
    MoveDrag,
    ThrowItem,
    PickUp,
    Drop,
    Give,
    Wait,
    Attack,
    Rob,
    Sabotage,
    Revive,
    JuryRig,
    CopyData,
    DeleteData,
    SetJammers,
    SetCameras,
    Manufacture,
    TransmitData,
    TimedLaunch,
    SectionLaunch,
    BridgeLaunch,
    AbandonShip,
    ReleaseProjectX,
    Decontaminate,
    DataMine,
    RocketWingsLaunch,
    Meditate,
    RepairRobot,
    UseKompromat,
    Tradecraft,
    UseBribe,
    SetCharacterStatus,
    TeleportCharacter,
    SetHazard,
    ClearHazard,
    HazardSuppression,
    AirlockMove,
    AirlockMoveDrag,
    AirlockThrow,
    AirlockEjectDown,
    GripPickUp,
    GripDown,
    Breach,
    Wormtongue,
    SelfDestruct,
    EjectAntimatter,
)
from engine import apply_action
from models import GameState, ItemId, OUTER_SPACE_SECTION, Item


# ---------- Helpers de display ----------

def _clone_state(state: GameState) -> GameState:
    if hasattr(state, "clone") and callable(getattr(state, "clone")):
        return state.clone()
    return copy.deepcopy(state)


def _fmt_item_public(state: GameState, iid: str) -> str:
    tok = getattr(state, "items", {}).get(iid)
    if not tok:
        return iid

    # Antimatter (RM 7.3): mostrar armado públicamente
    k = str(getattr(tok, 'kind', '')).upper()
    n = str(getattr(tok, 'name', '')).upper()
    if k == 'ANTIMATTER' or n == 'ANTIMATTER':
        armed = bool(getattr(tok, 'armed', False))
        return f"{iid}:Antimatter" + ("[ARMED]" if armed else "")

    if getattr(tok, "kind", "") == "kompromat":
        return f"{iid}:Kompromat"

    name = getattr(tok, "name", "?")
    integral = bool(getattr(tok, 'integral_bound_to', None))
    charges = getattr(tok, "charges", None)

    if charges is not None and charges != 0:
        if f"({charges})" in str(name):
            return f"{iid}:{name}" + ("[INTEGRAL]" if integral else "")
        return f"{iid}:{name}({charges})" + ("[INTEGRAL]" if integral else "")

    return f"{iid}:{name}" + ("[INTEGRAL]" if integral else "")


def _section_items_public(state: GameState, sec: str) -> List[str]:
    arr = getattr(state, "section_items", {}).get(sec, [])
    return [_fmt_item_public(state, x) for x in arr]


def _inv_public(state: GameState, cid: str) -> List[str]:
    ch = state.characters[cid]
    return [_fmt_item_public(state, x) for x in getattr(ch, "items", [])]


def _influence_on_character_txt(state: GameState, cid: str) -> str:
    """Resumen compacto de Influence sobre un Character (solo >0)."""
    parts: list[str] = []
    try:
        players = getattr(state, 'players', []) or []
        for p in players:
            pid = str(getattr(p, 'pid', '')).strip()
            if not pid:
                continue
            n = 0
            try:
                if hasattr(state, 'influence_of'):
                    n = int(state.influence_of(pid, cid))
                else:
                    n = int((getattr(state, 'influence', {}) or {}).get(pid, {}).get(cid, 0))
            except Exception:
                n = 0
            if n > 0:
                try:
                    nm = p.display_name()
                except Exception:
                    nm = pid
                parts.append(f"{nm}:{n}")
    except Exception:
        pass
    return ",".join(parts)


def _reveal_kit_txt(state: GameState, ch: Any) -> str:
    """Devuelve un resumen de Reveal (abilities/powers/items) para UI."""
    parts: list[str] = []
    try:
        # Habilidades que se ganan al Reveal (impresas en la carta)
        grants = sorted([str(a) for a in (getattr(ch, 'pc_reveal_abilities', set()) or set())])
        if grants:
            # Marcamos ✓ si ya están activas en abilities (típicamente tras Reveal normal).
            have = set([str(a) for a in (getattr(ch, 'abilities', set()) or set())])
            tagged = []
            for a in grants:
                tagged.append(a + ('✓' if a in have else ''))
            parts.append('GRANT:' + ",".join(tagged))

        # Reveal Powers (one-shot) que se resuelven al Reveal
        pows = sorted([str(p) for p in (getattr(ch, 'pc_reveal_powers', set()) or set())])
        if pows:
            res = getattr(ch, 'pc_reveal_power_resolution', {})
            if not isinstance(res, dict):
                res = {}
            tagged = []
            for p in pows:
                st = str(res.get(str(p).upper(), '')).upper() if res else ''
                if st == 'ACTIVATED':
                    tagged.append(p + '✓')
                elif st == 'SKIPPED':
                    tagged.append(p + '×')
                else:
                    tagged.append(p)
            parts.append('POWER:' + ",".join(tagged))

        # Item grants (si se usan en algún personaje)
        ig = getattr(ch, 'pc_reveal_item_grants', []) or []
        if ig:
            names = []
            for g in ig:
                try:
                    names.append(str(getattr(g, 'name', '') or '').strip() or str(g))
                except Exception:
                    continue
            if names:
                parts.append('ITEM:' + ",".join(names))
    except Exception:
        pass

    return " | ".join(parts)


def _hazards_txt(state: GameState, sec: str) -> str:
    hs = getattr(state, "hazards", {}).get(sec, set())
    if not hs:
        return "-"
    return ",".join(sorted([str(x) for x in hs]))


def print_state(state: GameState) -> None:
    cp = state.current_player()

    print("\n" + "=" * 70)
    print(f"MINUTE: {state.minute} | Turno de: {cp.display_name()} ({cp.kind})")
    print("=" * 70)

    print("\n--- JUGADORES (público) ---")
    print("  Jugador        Legal     Bribes  TM   Kmp  Reveal   BC     Supply  Betrayal  Conspirators")
    print("  ------------------------------------------------------------------------------------")
    for p in state.players:
        p_name = p.display_name()
        kmp_n = len(getattr(p, "kompromat_hand", []))
        tm_total = int(getattr(p, 'time_markers_total', 3))
        tm_avail = state.time_markers_available(p.pid) if hasattr(state, 'time_markers_available') else tm_total
        tm_txt = f"{tm_avail}/{tm_total}"
        consp = state.conspirators_of(p.pid) if hasattr(state, "conspirators_of") else []
        consp_txt = "[" + ",".join(consp) + "]" if consp else "[]"
        rev = getattr(p, "revealed_character", None) or "-"

        # BC es secreta salvo que se haya hecho pública (p.ej. Stranger: HOMEWORK).
        bc_txt = "-"
        try:
            if bool(getattr(p, 'bonus_character_public', False)):
                bc = getattr(p, 'bonus_character', None)
                if bc:
                    bc_txt = str(bc).upper()
        except Exception:
            bc_txt = "-"

        print(
            f"  {p_name:<12} {p.legal:<8} {p.bribes:>6} {tm_txt:>4} {kmp_n:>4} {rev:>7} {bc_txt:>6} "
            f"{p.supply_cubes:>6} {p.betrayal_cubes:>9}  {consp_txt}"
        )

    print("\n--- TURNO (jugador actual) ---")
    # Identidades (PC/BC) son SECRETAS. Usa el comando `myid` para verlas.
    print("  Identidades: (secretas) usa 'myid' para verlas.")
    print(f"  Influence target este turno: {getattr(cp, 'turn_influence_target', None)}")
    print(f"  Renegotiated este turno: {getattr(cp, 'turn_renegotiated', False)}")
    print(f"  Bribe intentado este turno: {getattr(cp, 'turn_bribe_attempted', False)}")
    print(f"  Kompromat intentado este turno: {getattr(cp, 'turn_kompromat_attempted', False)}")
    print(f"  Activado (turno actual): {getattr(state, 'active_character_id', None)}")
    print(f"  Acciones: {getattr(state, 'action_points_used', 0)}/{getattr(state, 'action_points_total', 0)}")
    print(f"  Free Pick/Drop usado: {getattr(state, 'free_pickdrop_used', False)}")

    print("\n--- ESTADOS GLOBALES ---")
    damaged = getattr(state, "damaged_sections", set())
    print(f"  Secciones dañadas: {sorted(list(damaged)) if damaged else '(ninguna)'}")
    print(f"  Jammers: {'ON' if getattr(state, 'jammers_on', False) else 'OFF'}")
    print(f"  Cameras: {'ON' if getattr(state, 'cameras_on', False) else 'OFF'}")
    print(f"  Abandon Ship: {'ON' if getattr(state, 'abandon_ship', False) else 'OFF'}")
    sf_on = bool(getattr(state, 'stationfall_triggered', False))
    sf_reason = getattr(state, 'stationfall_reason', None)
    sf_min = getattr(state, 'stationfall_minute', None)
    extra_sf = ''
    if sf_reason: extra_sf += f' | reason={sf_reason}'
    if sf_min is not None: extra_sf += f' | minute={sf_min}'
    print(f"  Stationfall: {'ON' if sf_on else 'OFF'}{extra_sf}")

    # Re-entry token (Minute 0)
    rev = bool(getattr(state, 'reentry_revealed', False))
    tok = str(getattr(state, 'reentry_token', 'STATIONFALL')).upper() if rev else "(oculto)"
    print(f"  Re-entry token: {'REVEALED' if rev else 'HIDDEN'} | {tok}")

    # Antimatter (RM 7.3): info pública
    aid = None
    for iid, it in getattr(state, 'items', {}).items():
        if str(getattr(it, 'kind', '')).upper() == 'ANTIMATTER' or str(getattr(it, 'name', '')).upper() == 'ANTIMATTER':
            aid = str(iid).upper()
            break
    if aid:
        it = state.items.get(aid)
        armed = bool(getattr(it, 'armed', False)) if it else False
        loc = '?'
        try:
            if hasattr(state, 'item_location'):
                lt, lv = state.item_location(aid)
                loc = f"{lt}:{lv}"
        except Exception:
            pass
        due = None
        for tm in getattr(state, 'time_markers', []):
            if str(getattr(tm, 'kind', '')).upper() == 'ANTIMATTER':
                due = getattr(tm, 'due_minute', None)
                break
        det = 'YES' if bool(getattr(state, 'antimatter_detonated', False)) else 'NO'
        due_txt = str(due) if due is not None else '-'
        det_sec = getattr(state, 'antimatter_detonation_section', None)
        det_reason = getattr(state, 'antimatter_detonation_reason', None)
        extra = ''
        if det_sec:
            extra += f" | det_sec={det_sec}"
        if det_reason:
            extra += f" | det_reason={det_reason}"
        print(f"  Antimatter: {'ARMED' if armed else 'SAFE'} | loc={loc} | detonate_minute={due_txt} | detonated={det}{extra}")

    pods = getattr(state, 'pods', {})
    if pods:
        parts = []
        for psid, pod in sorted(pods.items()):
            loc = getattr(pod, 'location', '?')
            att = getattr(pod, 'attached_to', None)
            lim = getattr(pod, 'occupancy_limit', None)
            dmg = ('DAMAGED' if psid in getattr(state, 'damaged_sections', set()) else 'OK')
            occ = None
            try:
                if hasattr(state, 'pod_is_occupied'):
                    occ = bool(state.pod_is_occupied(psid))
            except Exception:
                occ = None
            extra = f'lim={lim}' if lim is not None else 'lim=?'
            att_txt = att if att else '-'
            occ_txt = ('occ=Y' if occ is True else ('occ=N' if occ is False else 'occ=?'))
            parts.append(f'{psid}({loc},{dmg},{occ_txt},att={att_txt},{extra})')
        print('  Pods: ' + '; '.join(parts))

    # Time Markers visibles (RM 15.7): info pública.
    tms = getattr(state, 'time_markers', [])
    if tms:
        parts = []
        for tm in sorted(tms, key=lambda x: int(getattr(x, 'mid', 0))):
            dm = getattr(tm, 'due_minute', None)
            tail = f"min{tm.placed_minute}" + (f"->min{int(dm)}" if dm is not None else "")
            parts.append(f"{tm.mid}:{tm.owner}:{tm.kind}@{tm.target}({tail})")
        print('  Time Markers: ' + '; '.join(parts))

    # Offsites (RM 9.6 / 13.2 / 16.3): Data transmitida/entregada a NEWS/AUTHORITIES.
    offsites = getattr(state, 'offsites_data', None)
    if isinstance(offsites, dict):
        print("\n--- OFFSITES (Data) ---")
        for off in ("AUTHORITIES", "NEWS"):
            d = offsites.get(off, {}) if isinstance(offsites.get(off, {}), dict) else {}
            if not d:
                print(f"  {off}: (vacío)")
                continue
            parts = []
            for k in sorted(d.keys()):
                try:
                    n = int(d.get(k, 0))
                except Exception:
                    n = 0
                if n > 0:
                    parts.append(f"{k} x{n}")
            txt = ", ".join(parts) if parts else "(vacío)"
            print(f"  {off}: {txt}")


    # Power (sin consecuencias aún): 3 estados según cuántas Power Sections estén dañadas.
    pwr_status = getattr(state, "power_status", None)
    pwr_secs = sorted(list(getattr(state, "power_sections", set())))
    if pwr_status is not None and pwr_secs:
        try:
            damaged_pwr = state.damaged_power_sections_count()
        except Exception:
            damaged_pwr = len(set(getattr(state, "damaged_sections", set())) & set(pwr_secs))
        print(f"  Power Status: {pwr_status} | Power Sections: {pwr_secs} | dañadas={damaged_pwr}/{len(pwr_secs)}")
        if str(pwr_status) == 'Blackout':
            print("  ⚡ BLACKOUT: todas las secciones On Board están DARK; Console/Section Actions deshabilitadas salvo TIMED LAUNCH y AIRLOCK; Humans/Robots tienen BREACH; OFFICER no pasa LOCKS.")


    unlit = sorted(list(getattr(state, 'unlit_sections', set())))
    if unlit:
        print(f"  Secciones sin luz: {unlit}")

    print("\n--- PERSONAJES ---")
    for cid, ch in state.characters.items():
        tags = []
        if getattr(ch, "pc_owner", None):
            tags.append(f"PC:{ch.pc_owner}")
        # Discos de activación (si hay alguno sobre este Character)
        discs = []
        if hasattr(state, "activation_discs_on"):
            discs = state.activation_discs_on(cid)
        else:
            discs = [p.pid for p in state.players if getattr(p, "activation_disc", None) == cid]
        if discs:
            tags.append("DISC:" + ",".join(discs))
        if getattr(ch, "annihilated", False):
            tags.append("ANNIHILATED")
        if getattr(ch, "escaped", False) and not getattr(ch, "annihilated", False):
            tags.append("ESCAPED")
        if getattr(ch, 'contaminated', False):
            tags.append('CONTAMINATED')
        if getattr(ch, "status", "LIVE") != "LIVE":
            tags.append(ch.status)

        # Influence público: muestra solo jugadores con >0.
        infl_txt = _influence_on_character_txt(state, cid)
        if infl_txt:
            tags.append(f"INFL:{infl_txt}")

        inv = _inv_public(state, cid)
        inv_txt = inv if inv else ["(ninguno)"]

        extra = ""
        data = getattr(ch, "data", {})
        if data:
            extra += " data={" + ", ".join(sorted([str(k) for k in data.keys()])) + "}"

        # Reveal kit (aunque no esté activado todavía), para tomar mejores decisiones.
        rk = _reveal_kit_txt(state, ch)
        if rk:
            extra += " reveal={" + rk + "}"
        abilities = ch.effective_abilities() if hasattr(ch, "effective_abilities") else getattr(ch, "abilities", set())
        if abilities:
            extra += " abilities=[" + ", ".join(sorted([str(a) for a in abilities])) + "]"
        if getattr(ch, "bribe_tokens", []):
            extra += f" bribes_on={ch.bribe_tokens}"
        if getattr(ch, "kompromat_marks", 0):
            extra += f" komp_marks={ch.kompromat_marks}"

        agenda = getattr(ch, "agenda_points", [])
        if agenda:
            lines = []
            for pts, cond in agenda:
                try:
                    ptxt = f"{int(pts)}"
                except Exception:
                    ptxt = str(pts)
                lines.append(f"{ptxt}pt: {cond}")
            extra += " agenda=[" + "; ".join(lines) + "]"
            extra += f" infl_lim={getattr(ch, 'influence_limit', 5)}"

        status_txt = ", ".join(tags) if tags else "LIVE"
        print(f"  {cid}: {ch.name} ({ch.ctype}) | sec={ch.section} | {status_txt} | items={inv_txt}{extra}")
    print("\n--- MONSTERS (Project X) ---")
    monsters = getattr(state, "monsters", {}) or {}
    if not monsters:
        print("  (ninguno)")
    else:
        for mid, m in monsters.items():
            ab = ",".join(sorted(getattr(m, "abilities", set()))) if getattr(m, "abilities", None) else ""
            st = getattr(m, "status", "LIVE")
            print(f"  {mid:>3} | {m.name:<28} | {m.section:<18} | {st:<4} | {ab}")


    print("\n--- ITEMS + HAZARDS POR SECCIÓN ---")
    for sec in sorted(set(state.graph.keys()) | set(getattr(state, "hazards", {}).keys()) | set(getattr(state, "unlit_sections", set()))):
        items = _section_items_public(state, sec)
        hz = _hazards_txt(state, sec)
        lights_off = sec in getattr(state, 'unlit_sections', set())
        lights_txt = ' | lights=OFF' if lights_off else ''
        power_txt = ' | power=SUPPLY' if sec in getattr(state, 'power_sections', set()) else ''
        grav_on = True
        try:
            if hasattr(state, 'section_has_gravity'):
                grav_on = bool(state.section_has_gravity(sec))
        except Exception:
            grav_on = True
        grav_txt = f" | gravity={'ON' if grav_on else 'OFF'}"
        print(f"  {sec}: items={items if items else ['(ninguno)']} | hazards={hz}{lights_txt}{power_txt}{grav_txt}")

    print("\n--- ACCIONES DE SECCIÓN / CONSOLA (por sección) ---")
    ra_map = getattr(state, "room_actions", None)
    for sec in sorted(state.graph.keys()):
        if ra_map is None or sec not in ra_map:
            print(f"  {sec}: (no definido)")
        else:
            ra = ra_map.get(sec, [])
            print(f"  {sec}: {ra if ra else ['(ninguna)']}")

    print("\n--- MAPA ---")
    vents = getattr(state, "vents", {})
    all_secs = sorted(set(state.graph.keys()) | set(vents.keys()))
    for sec in all_secs:
        neigh = state.graph.get(sec, [])
        v = vents.get(sec, [])

        # Corridors normales (pueden estar LOCKED)
        neigh_txt = []
        for nb in neigh:
            lbl = str(nb)
            if hasattr(state, "is_locked_corridor") and state.is_locked_corridor(sec, nb):
                lbl += " 🔒"
            neigh_txt.append(lbl)

        extra = f" | vents={v}" if v else ""

        # Airlocks: mostrar direcciones si aplica.
        air = ""
        if hasattr(state, "airlocks") and str(sec).upper() in getattr(state, "airlocks", {}):
            info = state.airlocks.get(str(sec).upper(), {})
            t = "1" if info.get("to_outer", False) else "0"
            f = "1" if info.get("from_outer", False) else "0"
            air = f" | airlock(to={t},from={f})"

        print(f"  {sec}: {neigh_txt}{extra}{air}")

    print("-" * 70)


def _print_hud(state: GameState) -> None:
    cp = state.current_player()
    act = getattr(state, "active_character_id", None)
    apu = getattr(state, "action_points_used", 0)
    apt = getattr(state, "action_points_total", 0)
    free_used = getattr(state, "free_pickdrop_used", False)

    komp_n = len(getattr(cp, "kompromat_hand", []))
    komp_try = "sí" if getattr(cp, "turn_kompromat_attempted", False) else "no"
    bribe_try = "sí" if getattr(cp, "turn_bribe_attempted", False) else "no"

    hud = (
        f"HUD | Activado: {act or '(ninguno)'} | Acciones: {apu}/{apt} | "
        f"FreeUsed: {free_used} | Komp: {komp_n} (intentado:{komp_try}) | Bribe intentado: {bribe_try} | "
        f"Jammers: {'ON' if getattr(state, 'jammers_on', False) else 'OFF'} | Cameras: {'ON' if getattr(state, 'cameras_on', False) else 'OFF'} | "
        f"AbandonShip: {'ON' if getattr(state, 'abandon_ship', False) else 'OFF'}"
    )

    if act:
        ch = state.characters[act]
        sec_items = _section_items_public(state, ch.section)
        inv = _inv_public(state, act)
        hz = _hazards_txt(state, ch.section)
        lights_txt = " lights=OFF" if ch.section in getattr(state, "unlit_sections", set()) else ""
        hud += f" | Sección: {ch.section}{lights_txt} items={sec_items if sec_items else ['(ninguno)']} hazards={hz} | Inv: {inv if inv else ['(ninguno)']}"
    # MEDICAL marker (público en su carta): mostrar contador y estrellas siempre que exista Medical en la partida.
    try:
        med_id = None
        for cid, ch2 in getattr(state, 'characters', {}).items():
            if str(getattr(ch2, 'name', '')).strip().upper() == 'MEDICAL':
                med_id = cid
                break
        if med_id is not None and hasattr(state, 'get_character_counter'):
            mk = int(state.get_character_counter(med_id, 'MEDICAL_MARKER', 0) or 0)
            if mk < 0: mk = 0
            if mk > 11: mk = 11
            stars = sum(1 for t in (1, 2, 3, 4, 6, 8, 11) if mk >= t)
            hud += f" | MedicalMarker:{mk} (stars:{stars})"
    except Exception:
        pass
    
    print(hud)


def _print_help() -> None:
    print("\nComandos:")
    print("  help")
    print("  state")
    print("  save [name]                 (guarda un snapshot exacto; por defecto en ./saves/quicksave.sfsave)")
    print("  saves                       (lista saves en ./saves)")
    print("  undo")
    print("  reveal                      (pregunta Normal vs Schrödinger)")
    print("  influence <CID> [n]")
    print("  renegotiate <CID> [n]")
    print("  activate <CID>")
    print("  move <SEC>")
    print("  zeromove <SEC>              (opcional: forzar ZEROBORN; ya puedes usar move normal a 0G y consumirá el free pick/drop)")
    print("  movedrag <SEC> <DOWNCID>")
    print("  breach <SEC>                (BREACH: retira 1 LOCK adyacente en Blackout)")
    print("  wormtongue <HUMANCID> [PID]  (WORMTONGUE: mueve 1 cube de un Human COLOCATED a Betrayal)")
    print("  throw <IID|NAME> <SEC> [boom]    (solo corredor normal; no VENTS/LOCKS)")
    print("  airlock move <SEC|OUTER_SPACE>")
    print("  airlock movedrag <SEC|OUTER_SPACE> <DOWNCID>")
    print("  airlock throw <IID|NAME> <SEC|OUTER_SPACE>")
    print("  airlock eject <DOWNCID>")

    print("  grip pickup <IID|NAME>")
    print("  grip down <CID>")
    print("  pickup <IID|NAME>")
    print("  drop <IID|NAME> [boom]")
    print("  give <IID|NAME> <CID>       (GIVE: das un Item a un Character COLOCATED; no puede rechazarse)")
    print("  wait")
    print("  attack <CID|MID>        (requiere Gun o Bludgeon)")
    print("  rob <victimCID> <IID|NAME|TYPE>")
    print("  sabotage                    (requiere Gun o Bludgeon)")
    print("  revive <CID|MID>             (requiere NANOGEL en inventario)")
    print("  juryrig [section|CID]        (JURY RIG: repara sección dañada o Robot DOWN COLOCATED)")
    print("  copydata <TYPE> <toCID>      (Jammers ON: requiere COLOCATED)")
    print("  delete <TYPE>                (PC only)")
    print("  jammers on|off               (CONSOLE ACTION; con HACKER: si te queda el slot free, se usa auto; con Jammers OFF: remoto)")
    print("  suppress <SEC>               (CONSOLE ACTION; con HACKER: si te queda el slot free, se usa auto; con Jammers OFF: remoto)")
    print("  cameras on|off               (SECURITY STATION: acción CAMERAS)")
    print("  manufacture data <TYPE> | manufacture item <NAME>")
    print("  transmit <TYPE> <OFFSITE>    (Section Action: OFFSITE=AUTHORITIES|NEWS)")
    print("  timedlaunch                  (Section Action: Timed Launch, RM 13.6)")
    print("  sectionlaunch <PODSEC>       (Section Action: Section Launch, RM 13.7)")
    print("  bridgelaunch                 (Section Action: Bridge Launch, RM 13.8 | OFFICER only)")
    print("  abandon                      (Section Action: Abandon Ship, RM 13.1 | OFFICER only)")
    print("  selfdestruct                (Section Action: Self-Destruct | BRIDGE | OFFICER only)")
    print("  releasepx                   (Section Action: Release Project X, RM 13.3 | OFFICER only)")
    print("  ejectantimatter             (Section Action: Eject Antimatter | MAGNETIC_CONTAINMENT)")
    print("  decontaminate [CID]          (Section Action: Decontaminate, RM 13.4)")
    print("  datamine <IID|NAME|SEC>      (Section Action: Data Mine | SHRED_ROOM | +1 Kompromat desde cualquier sección On Board)")
    print("  rwlaunch                    (Section Action: Rocket Wings Launch | OUTER_SPACE | requiere Rocket Wings; Humans requieren Helmet)")
    print("  meditate                    (Section Action: Meditate | THERAPY_GARDEN | PC only)")
    print("  msrepair <ROBOTCID>          (Section Action: Repair Robot, RM 13.11 | Machine Shop)")
    print("  myid")
    print("  mykomp")
    print("  peekx                      (X-SECRET: mira la carta de Project X; requiere tu disco en ese Character)")
    print("  tradecraft <KID|NAME> <KID|NAME> <KID|NAME_USED> (EXILE: descarta 2 Kompromat y recupera 1 Kompromat usado sobre NPC)")
    print("  komp <KID|NAME> <acción...>")
    print("  bribe <CID> <acción...>")
    print("")
    print("DEBUG:")
    print("  status <CID> live|down")
    print("  escape <CID> on|off")
    print("  annihilate <CID> on|off")
    print("  damage <SEC>")
    print("  repair <SEC>")
    print("  abandonship on|off|toggle")
    print("  tp <CID> <SEC>               (teleport debug)")
    print("  spawnitem <SEC> <ITEM> [charges]  (debug: spawnea un Item en una sección; no gasta acciones)")
    print("  hazard add <SEC> fire|asphyx")
    print("  hazard clear <SEC> [fire|asphyx]")
    print("  pod add <PODSEC> <SEC> [limit]")
    print("  pod launch <PODSEC>")
    print("  airlock add <SEC> [to_outer 0/1] [from_outer 0/1]")
    print("  reentry                     (status del token Minute 0)")
    print("  reentry reveal               (revela el token)")
    print("  reentry set safe|stationfall (setea el token y lo oculta)")
    print("  end")


# ---------- CLI ----------

@dataclass
class CLI:
    state: GameState
    undo_stack: List[GameState] = None

    def __post_init__(self) -> None:
        if self.undo_stack is None:
            self.undo_stack = []

    # --- Resolución de referencias a Characters ---
    def _cid(self, ref: str) -> str:
        """Resolve a Character reference (id C# or name) into a CharacterId."""
        try:
            return self.state.resolve_character_ref(ref, allow_monster=False)
        except Exception:
            # Mensaje corto y útil (sin listar todo el catálogo, que es enorme)
            raise ActionError(
                f"No reconozco el Character '{ref}'. Usa su id (C#) o su nombre exacto (p.ej. Counselor, Station_Chief)."
            )

    def _cid_or_mid(self, ref: str) -> str:
        """Resolve to CharacterId or MonsterId (M#), for comandos como attack/revive."""
        try:
            return self.state.resolve_character_ref(ref, allow_monster=True)
        except Exception:
            raise ActionError(
                f"No reconozco el objetivo '{ref}'. Usa un Character (C# o nombre) o un Monster id (M#)."
            )

    # --- Resolución de referencias a Items ---
    def _active_cid(self) -> str:
        act = str(getattr(self.state, "active_character_id", "") or "").upper()
        if not act:
            raise ActionError("No hay Character activado. Usa: activate <CID> (o nombre).")
        return act

    def _iid(self, ref: str, *, candidates: Optional[List[str]] = None) -> str:
        """Resolve an Item reference (I# or name) into an ItemId.

        If `candidates` is provided, restricts resolution to those ItemIds.
        """
        try:
            return self.state.resolve_item_ref(ref, candidates=candidates)
        except Exception:
            # Mensaje breve: el usuario suele querer escribir el nombre "natural".
            raise ActionError(
                f"No reconozco el Item '{ref}'. Usa su id (I#) o su nombre (p.ej. Bludgeon, Helmet, Nanogel)."
            )




    # --- Resolución de referencias a Secciones ---
    def _sec(self, ref: str) -> str:
        """Resolve a section reference into a canonical SectionId.

        Acepta ids canónicos (AFT_HUB), pero también nombres "naturales"
        sin guiones/espacios/underscores (Afthub, Aft Hub, aft-hub).
        """
        raw = str(ref or "").strip()
        if not raw:
            raise ActionError("Sección inválida.")

        up = raw.upper()

        # Alias comunes
        if up in ("OS", "OUTERSPACE", "OUTER_SPACE"):
            return OUTER_SPACE_SECTION

        # Candidatos = nodos del grafo + pods (por si acaso)
        ids = set((getattr(self.state, "graph", {}) or {}).keys())
        ids |= set((getattr(self.state, "pods", {}) or {}).keys())

        # Match directo
        if up in ids:
            return up

        want = re.sub(r"[^A-Z0-9]", "", up)

        # Match por normalización (quita _ espacios etc)
        matches = [sid for sid in ids if re.sub(r"[^A-Z0-9]", "", str(sid).upper()) == want]

        if len(matches) == 1:
            return str(matches[0]).upper()
        if len(matches) > 1:
            # No debería pasar, pero mejor mensaje que fallar silenciosamente.
            raise ActionError(f"Sección ambigua: '{raw}' -> {sorted(matches)}")

        raise ActionError(f"Sección desconocida: '{raw}'. Prueba con el id exacto (p.ej. AFT_HUB).")


    # --- Helpers: Kompromat + Data Mine ---
    def _kompromat_on_board_candidates(self) -> List[str]:
        """Lista de Kompromats que están en secciones ON BOARD (no en inventarios, no offboard)."""
        cand: List[str] = []
        secs = getattr(self.state, 'section_items', {}) or {}
        items = getattr(self.state, 'items', {}) or {}
        for _sec, arr in secs.items():
            for _iid in (arr or []):
                iid_u = str(_iid).upper()
                it = items.get(iid_u)
                if it and str(getattr(it, 'kind', '')).lower() == 'kompromat':
                    cand.append(iid_u)
        return cand

    def _kompromat_in_section(self, sec: str) -> List[str]:
        """Devuelve Kompromats presentes en una sección concreta (ON BOARD)."""
        sec_u = str(sec).upper()
        secs = getattr(self.state, 'section_items', {}) or {}
        items = getattr(self.state, 'items', {}) or {}
        out: List[str] = []
        for _iid in (secs.get(sec_u) or []):
            iid_u = str(_iid).upper()
            it = items.get(iid_u)
            if it and str(getattr(it, 'kind', '')).lower() == 'kompromat':
                out.append(iid_u)
        return out

    @staticmethod
    def _iid_sort_key(iid: str) -> tuple:
        m = re.match(r"^I(\d+)$", str(iid).upper().strip())
        if m:
            return (0, int(m.group(1)))
        return (1, str(iid))

    def _resolve_datamine_target(self, ref: str) -> str:
        """Resuelve el argumento de `datamine`.

        Acepta:
        - IID (I105)
        - nombre de Kompromat (si hubiera)
        - SECCIÓN (kitchen / AFT HUB / controlarray...), en cuyo caso roba el Kompromat que esté allí.
        """
        raw = str(ref or '').strip()
        if not raw:
            raise ActionError("Uso: datamine <IID|NAME|SEC>")

        cand_all = self._kompromat_on_board_candidates()

        # Si parece un IID, intentamos resolverlo como item.
        if re.match(r"^I\d+$", raw.strip().upper()):
            return self._iid(raw, candidates=cand_all)

        # 1) Si es una sección válida, intenta coger el Kompromat de esa sección.
        sec: Optional[str] = None
        try:
            sec = self._sec(raw)
        except ActionError:
            # No era una sección reconocida: seguimos con fallback a item ref.
            sec = None

        if sec is not None:
            komp_here = self._kompromat_in_section(sec)
            if not komp_here:
                # Si el usuario pidió explícitamente una sección, este es el comportamiento deseado.
                raise ActionError(f"No hay Kompromat en {sec}.")
            komp_here = sorted(komp_here, key=self._iid_sort_key)
            return komp_here[0]

        # 2) Fallback: resolver como item ref dentro de los Kompromats disponibles.
        return self._iid(raw, candidates=cand_all)

    def _kid_used_npc(self, ref: str) -> str:
        """Resuelve un Kompromat entre los *usados sobre NPC* (state.used_npc_kompromat).

        Nota: esos tokens pueden NO estar en state.items (se guardan en un dict aparte),
        así que no podemos delegar siempre en resolve_item_ref.

        Acepta:
        - id canónico (I#)
        - nombre del objetivo (p.ej. "Station Chief")
        """

        raw = str(ref or '').strip()
        if not raw:
            raise ActionError('Falta referencia a Kompromat usado.')

        used = getattr(self.state, 'used_npc_kompromat', {}) or {}
        if not used:
            raise ActionError('No hay Kompromat usados sobre NPC disponibles.')

        up = raw.upper()
        if re.match(r'^I\d+$', up):
            if up in used:
                return up
            raise ActionError(f"Ese Kompromat usado no existe: {up}")

        def _norm_local(s: str) -> str:
            return re.sub(r'[^A-Z0-9]', '', str(s).upper())

        want = _norm_local(raw)
        chars = getattr(self.state, 'characters', {}) or {}

        matches: list[str] = []
        for kid, tok in used.items():
            kid_u = str(kid).upper()
            nm = _norm_local(getattr(tok, 'name', ''))

            # Match directo por nombre del token
            if nm == want or nm.startswith(want):
                matches.append(kid_u)
                continue

            # Match por objetivo del Kompromat (lo que más se usa)
            tgt = getattr(tok, 'kompromat_target', None)
            if tgt:
                tgt_u = str(tgt).upper()
                if tgt_u in chars:
                    tnm = _norm_local(getattr(chars[tgt_u], 'name', ''))
                    if tnm == want:
                        matches.append(kid_u)
                        continue

            # Match tipo "KOMPROMAT<target>"
            if nm.startswith('KOMPROMAT') and nm.endswith(want):
                matches.append(kid_u)
                continue

        if not matches:
            raise ActionError(
                f"No reconozco el Kompromat usado '{raw}'. Usa su id (I#) o el nombre del objetivo (p.ej. Station Chief)."
            )

        def _sort_key(iid: str) -> int:
            s = str(iid).upper()
            if s.startswith('I') and s[1:].isdigit():
                return int(s[1:])
            return 10_000_000

        return sorted(set(matches), key=_sort_key)[0]

    def _consume_iid_prefix(self, tokens: List[str], start_idx: int, *, candidates: List[str], min_remaining: int = 0) -> tuple[str, List[str]]:
        """Consume un nombre/id de Item que puede ocupar varios tokens.

        Estrategia: intenta el match MÁS largo posible desde start_idx dentro de `candidates`.

        Ej: give Rocket Wings Station Chief
            -> (I..., ["Station","Chief"])
        """

        if start_idx >= len(tokens):
            raise ActionError("Falta referencia a Item.")

        last_end = len(tokens) - int(min_remaining)
        for end in range(last_end, start_idx, -1):
            cand = " ".join(tokens[start_idx:end]).strip()
            if not cand:
                continue
            try:
                iid = self.state.resolve_item_ref(cand, candidates=candidates)
            except Exception:
                continue
            rest = tokens[end:]
            if len(rest) >= min_remaining:
                return (iid, rest)

        cand = " ".join(tokens[start_idx:]).strip()
        raise ActionError(
            f"No reconozco el Item '{cand}'. Usa I# o su nombre (si tiene espacios, ponlo entre comillas)."
        )

    def _consume_cid_prefix(self, tokens: List[str], start_idx: int, *, min_remaining: int = 0) -> tuple[str, List[str]]:
        """Consume un nombre/id de Character que puede ocupar varios tokens.

        Ej: bribe Station Chief attack Counselor
        tokens = ["bribe","Station","Chief","attack","Counselor"]
          -> ("C...", ["attack","Counselor"])

        Estrategia: intenta el match MÁS largo posible desde start_idx.
        """

        if start_idx >= len(tokens):
            raise ActionError("Falta referencia a Character.")

        last_end = len(tokens) - int(min_remaining)
        for end in range(last_end, start_idx, -1):
            cand = " ".join(tokens[start_idx:end]).strip()
            if not cand:
                continue
            try:
                cid = self.state.resolve_character_ref(cand, allow_monster=False)
            except Exception:
                continue
            rest = tokens[end:]
            if len(rest) >= min_remaining:
                return (cid, rest)

        # No match
        cand = " ".join(tokens[start_idx:]).strip()
        raise ActionError(
            f"No reconozco el Character '{cand}'. Usa su id (C#) o su nombre (p.ej. Station_Chief), o ponlo entre comillas."
        )

    def _push_undo(self) -> None:
        self.undo_stack.append(_clone_state(self.state))

    def _undo(self) -> bool:
        if not self.undo_stack:
            print("Nada que deshacer.")
            return False
        self.state = self.undo_stack.pop()
        print("↩️  Undo.")
        return True

    def _parse_subaction(self, tokens: List[str], *, actor_cid: Optional[str] = None) -> object:
        if not tokens:
            raise ActionError("Falta acción.")
        cmd = tokens[0].lower()

        # Para subacciones que manipulan Items (pickup/drop/give/throw...),
        # necesitamos saber el actor. Por defecto usamos el Character activo;
        # pero en "bribe" el actor real es el Character sobornado.
        actor = None
        if actor_cid is not None:
            actor = str(actor_cid).upper()

        if cmd == "move":
            if len(tokens) != 2:
                raise ActionError("Uso: move <SEC>")
            return Move(to_section=self._sec(tokens[1]))

        if cmd == "movedrag":
            if len(tokens) < 3:
                raise ActionError("Uso: movedrag <SEC> <DOWNCID>")
            drag_ref = " ".join(tokens[2:]).strip()
            return MoveDrag(to_section=self._sec(tokens[1]), drag_character=self._cid(drag_ref))

        if cmd == "breach":
            if len(tokens) != 2:
                raise ActionError("Uso: breach <SEC>")
            return Breach(to_section=self._sec(tokens[1]))

        if cmd == "grip":
            if len(tokens) < 2:
                raise ActionError("Uso: grip pickup <IID|NAME> | grip down <CID>")
            sub = tokens[1].lower()
            if sub in ("pickup", "pick", "p"):
                if len(tokens) < 3:
                    raise ActionError("Uso: grip pickup <IID|NAME>")
                item_ref = " ".join(tokens[2:]).strip()
                # GRIP PICK UP toma el item desde OUTER SPACE.
                cand = list((getattr(self.state, 'section_items', {}) or {}).get(OUTER_SPACE_SECTION, []) or [])
                iid = self._iid(item_ref, candidates=cand)
                return GripPickUp(item=iid)
            if sub in ("down", "d"):
                if len(tokens) < 3:
                    raise ActionError("Uso: grip down <CID>")
                tgt_ref = " ".join(tokens[2:]).strip()
                return GripDown(target_character=self._cid(tgt_ref))
            raise ActionError("Uso: grip pickup <IID|NAME> | grip down <CID>")

        if cmd in ("grippickup", "grip_pickup"):
            if len(tokens) < 2:
                raise ActionError("Uso: grippickup <IID|NAME>")
            item_ref = " ".join(tokens[1:]).strip()
            cand = list((getattr(self.state, 'section_items', {}) or {}).get(OUTER_SPACE_SECTION, []) or [])
            iid = self._iid(item_ref, candidates=cand)
            return GripPickUp(item=iid)

        if cmd in ("gripdown", "grip_down"):
            if len(tokens) < 2:
                raise ActionError("Uso: gripdown <CID>")
            tgt_ref = " ".join(tokens[1:]).strip()
            return GripDown(target_character=self._cid(tgt_ref))

        if cmd in ("wormtongue", "worm", "wt"):
            if len(tokens) < 2:
                raise ActionError("Uso: wormtongue <HUMANCID> [PID]")
            pid = None
            import re as _re
            if len(tokens) >= 3 and _re.match(r"^P\d+$", str(tokens[-1]).upper()):
                pid = str(tokens[-1]).upper()
                tgt_ref = " ".join(tokens[1:-1]).strip()
            else:
                tgt_ref = " ".join(tokens[1:]).strip()
            return Wormtongue(target_character=self._cid(tgt_ref), cube_owner=pid)


        if cmd == "throw":
            # Permite: throw <IID|NAME...> <SEC> [boom]
            if len(tokens) < 3:
                raise ActionError("Uso: throw <IID|NAME> <SEC> [boom]")

            # Determinar flag y destino
            det = False
            tail = [t for t in tokens[1:] if str(t).strip()]
            flag = str(tail[-1]).strip().lower() if tail else ""
            boom_words = {"boom", "explode", "detonate", "x", "y", "yes", "si", "sí", "1"}
            if flag in boom_words and len(tail) >= 3:
                det = True
                to_section = self._sec(str(tail[-2]))
                item_ref = " ".join([str(x) for x in tail[:-2]]).strip()
            else:
                to_section = self._sec(str(tail[-1]))
                item_ref = " ".join([str(x) for x in tail[:-1]]).strip()

            if not item_ref:
                raise ActionError("Uso: throw <IID|NAME> <SEC> [boom]")

            act = actor or self._active_cid()
            inv = list((getattr(self.state, 'characters', {}) or {}).get(act).items) if act in (getattr(self.state, 'characters', {}) or {}) else []
            iid = self._iid(item_ref, candidates=inv)
            return ThrowItem(item=iid, to_section=to_section, detonate=bool(det))

        if cmd == "pickup":
            if len(tokens) < 2:
                raise ActionError("Uso: pickup <IID|NAME>")
            act = actor or self._active_cid()
            ch = (getattr(self.state, 'characters', {}) or {}).get(act)
            if not ch:
                raise ActionError("No hay Character activo válido.")
            sec = str(getattr(ch, 'section', '')).upper()
            cand = list((getattr(self.state, 'section_items', {}) or {}).get(sec, []) or [])
            item_ref = " ".join(tokens[1:]).strip()
            iid = self._iid(item_ref, candidates=cand)
            return PickUp(item=iid)

        if cmd == "drop":
            # Permite: drop <IID|NAME...> [boom]
            if len(tokens) < 2:
                raise ActionError("Uso: drop <IID|NAME> [boom]")

            det = False
            boom_words = {"boom", "explode", "detonate", "x", "y", "yes", "si", "sí", "1"}
            maybe_flag = str(tokens[-1]).strip().lower()
            if maybe_flag in boom_words and len(tokens) >= 3:
                det = True
                item_ref = " ".join(tokens[1:-1]).strip()
            else:
                item_ref = " ".join(tokens[1:]).strip()

            act = actor or self._active_cid()
            inv = list((getattr(self.state, 'characters', {}) or {}).get(act).items) if act in (getattr(self.state, 'characters', {}) or {}) else []
            iid = self._iid(item_ref, candidates=inv)
            return Drop(item=iid, detonate=bool(det))

        if cmd == "give":
            # Uso: give <IID|NAME...> <CID...> | give <IID|NAME...> to <CID...>
            if len(tokens) < 3:
                raise ActionError("Uso: give <IID|NAME> <CID>")

            act = actor or self._active_cid()
            inv = list((getattr(self.state, 'characters', {}) or {}).get(act).items) if act in (getattr(self.state, 'characters', {}) or {}) else []

            # Si hay "to/a", separamos explícitamente.
            lower = [str(t).lower() for t in tokens]
            if "to" in lower[1:] or "a" in lower[1:]:
                try:
                    i_to = lower.index("to", 1)
                except ValueError:
                    i_to = lower.index("a", 1)
                item_ref = " ".join(tokens[1:i_to]).strip()
                tgt_ref = " ".join(tokens[i_to+1:]).strip()
                if not item_ref or not tgt_ref:
                    raise ActionError("Uso: give <IID|NAME> <CID>")
                iid = self._iid(item_ref, candidates=inv)
                return Give(item=iid, to_character=self._cid(tgt_ref))

            # Sin "to": usa match más largo posible para el item.
            iid, rest = self._consume_iid_prefix(tokens, 1, candidates=inv, min_remaining=1)
            tgt_ref = " ".join(rest).strip()
            return Give(item=iid, to_character=self._cid(tgt_ref))

        if cmd == "attack":
            if len(tokens) < 2:
                raise ActionError("Uso: attack <CID|MID> [gun|bludgeon]")
            weap = None
            tail = [t.strip() for t in tokens[1:] if t.strip()]
            if tail:
                last = tail[-1].lower()
                if last in ("gun", "g", "bludgeon", "blud", "b"):
                    weap = ("GUN" if last in ("gun", "g") else "BLUDGEON")
                    tail = tail[:-1]
            if not tail:
                raise ActionError("Uso: attack <CID|MID> [gun|bludgeon]")
            tgt_ref = " ".join(tail).strip()
            return Attack(target_id=self._cid_or_mid(tgt_ref), weapon=weap)

        

        if cmd == "rob":
            if len(tokens) < 3:
                raise ActionError("Uso: rob <victimCID> <IID|NAME|TYPE>")

            # victim puede ser nombre con espacios; lo resolvemos por prefijo.
            victim, rest = self._consume_cid_prefix(tokens, 1, min_remaining=1)
            what_raw = " ".join(rest).strip()
            what_up = what_raw.upper()

            # Heurística:
            # - I<dígitos> => item id
            # - si no, intentamos resolver como nombre de item en inventario de la víctima
            # - si falla, lo tratamos como TYPE de Data.
            if re.match(r"^I\d+$", what_up):
                return Rob(victim=victim, item=what_up)
            try:
                vch = (getattr(self.state, 'characters', {}) or {}).get(victim)
                vcand = list(getattr(vch, 'items', []) or []) if vch else []
                iid = self.state.resolve_item_ref(what_raw, candidates=vcand)
                return Rob(victim=victim, item=iid)
            except Exception:
                return Rob(victim=victim, data_type=what_up)

        if cmd == "sabotage":
            return Sabotage()

        if cmd == "revive":
            if len(tokens) < 2:
                raise ActionError("Uso: revive <CID|MID>")
            tgt_ref = " ".join(tokens[1:]).strip()
            return Revive(target_character=self._cid_or_mid(tgt_ref))


        if cmd in ("juryrig", "jury"):
            if len(tokens) == 1:
                return JuryRig()
            if len(tokens) != 2:
                raise ActionError("Uso: juryrig [section|CID]")
            arg = tokens[1].strip().lower()
            if arg in ("section", "sec", "room"):
                return JuryRig(target_section=True)
            tgt_ref = " ".join(tokens[1:]).strip()
            return JuryRig(target_cid=self._cid(tgt_ref))

        if cmd == "copydata":
            if len(tokens) < 3:
                raise ActionError("Uso: copydata <TYPE> <toCID>")
            to_ref = " ".join(tokens[2:]).strip()
            return CopyData(data_type=tokens[1].upper(), to_character=self._cid(to_ref))

        if cmd == "delete":
            if len(tokens) != 2:
                raise ActionError("Uso: delete <TYPE>")
            return DeleteData(data_type=tokens[1].upper())

        if cmd == "jammers":
            if len(tokens) not in (2,3) or tokens[1].lower() not in ("on", "off"):
                raise ActionError("Uso: jammers on|off [free]")
            use_free = False
            if len(tokens) == 3:
                tag = tokens[2].strip().lower()
                use_free = tag in ("free", "f", "hack", "h")
                if not use_free:
                    raise ActionError("Uso: jammers on|off [free]")
            return SetJammers(on=(tokens[1].lower() == "on"), use_free_slot=use_free)

        if cmd == "cameras":
            if len(tokens) != 2 or tokens[1].lower() not in ("on", "off"):
                raise ActionError("Uso: cameras on|off")
            return SetCameras(on=(tokens[1].lower() == "on"))

        if cmd == "manufacture":
            if len(tokens) < 3:
                raise ActionError("Uso: manufacture data <TYPE> | manufacture item <NAME>")
            kind = tokens[1].lower()
            spec = " ".join(tokens[2:]).strip()
            return Manufacture(kind=kind, spec=spec)
        if cmd == "transmit":
            if len(tokens) != 3:
                raise ActionError("Uso: transmit <TYPE> <AUTHORITIES|NEWS>")
            dtype = tokens[1].upper()
            off_raw = tokens[2].upper()
            if off_raw in ("A", "AUTH", "AUTHORITY", "AUTHORITIES"):
                off = "AUTHORITIES"
            elif off_raw in ("N", "NEWS"):
                off = "NEWS"
            else:
                raise ActionError("Offsite inválido. Usa AUTHORITIES o NEWS.")
            return TransmitData(data_type=dtype, offsite=off)

        if cmd == "timedlaunch":
            if len(tokens) != 1:
                raise ActionError("Uso: timedlaunch (debes estar dentro del Pod; sin argumentos).")
            return TimedLaunch()

        if cmd == "sectionlaunch":
            if len(tokens) != 2:
                raise ActionError("Uso: sectionlaunch <PODSEC>")
            return SectionLaunch(pod_section=self._sec(tokens[1]))

        if cmd == "bridgelaunch":
            if len(tokens) != 1:
                raise ActionError("Uso: bridgelaunch")
            return BridgeLaunch()

        if cmd in ("abandon", "abandonship", "abandon_ship"):
            if len(tokens) != 1:
                raise ActionError("Uso: abandon")
            return AbandonShip()

        if cmd in ("selfdestruct", "self-destruct", "sd"):
            if len(tokens) != 1:
                raise ActionError("Uso: selfdestruct")
            return SelfDestruct()

        if cmd in ("releasepx", "releasex", "release", "release_project_x"):
            if len(tokens) != 1:
                raise ActionError("Uso: releasepx")
            return ReleaseProjectX()

        if cmd in ("ejectantimatter", "eject-antimatter", "ejectam", "eject_am"):
            if len(tokens) != 1:
                raise ActionError("Uso: ejectantimatter")
            return EjectAntimatter()

        if cmd == "suppress":
            if len(tokens) not in (2, 3):
                raise ActionError("Uso: suppress <SEC> [free]")
            use_free = False
            if len(tokens) == 3:
                if tokens[2].lower() not in ("free", "f", "hack", "h"):
                    raise ActionError("Uso: suppress <SEC> [free]")
                use_free = True
            return HazardSuppression(target_section=self._sec(tokens[1]), use_free_slot=use_free)

        if cmd in ("decontaminate", "decon"):
            if len(tokens) == 1:
                return Decontaminate()
            if len(tokens) != 2:
                raise ActionError("Uso: decontaminate [CID|MID]")
            tgt_ref = " ".join(tokens[1:]).strip()
            return Decontaminate(target_character=self._cid_or_mid(tgt_ref))

        if cmd in ("rwlaunch", "rocketlaunch", "rocketwings", "wingslaunch", "rw"):
            if len(tokens) != 1:
                raise ActionError("Uso: rwlaunch")
            return RocketWingsLaunch()

        if cmd in ("meditate", "med"):
            if len(tokens) != 1:
                raise ActionError("Uso: meditate")
            return Meditate()

        if cmd in ("msrepair", "machinerepair", "repairbot", "machineshop"):
            if len(tokens) < 2:
                raise ActionError("Uso: msrepair <ROBOTCID>")
            tgt_ref = " ".join(tokens[1:]).strip()
            return RepairRobot(target_character=self._cid(tgt_ref))

        if cmd in ("wait", "w"):
            if len(tokens) != 1:
                raise ActionError("Uso: wait")
            return Wait()

        if cmd in ("zeromove", "zeroborn", "zmove"):
            if len(tokens) != 2:
                raise ActionError("Uso: zeromove <SEC>")
            return ZeroBornMove(to_section=self._sec(tokens[1]))

        if cmd == "airlock":
            if len(tokens) < 2:
                raise ActionError(
                    "Uso: airlock move <SEC|OUTER_SPACE> | airlock movedrag <SEC|OUTER_SPACE> <DOWNCID> | airlock throw <IID|NAME> <SEC|OUTER_SPACE> | airlock eject <DOWNCID>"
                )
            sub = tokens[1].lower()
            if sub == "move":
                if len(tokens) != 3:
                    raise ActionError("Uso: airlock move <SEC|OUTER_SPACE>")
                return AirlockMove(to_section=self._sec(tokens[2]))
            if sub == "movedrag":
                if len(tokens) < 4:
                    raise ActionError("Uso: airlock movedrag <SEC|OUTER_SPACE> <DOWNCID>")
                drag_ref = " ".join(tokens[3:]).strip()
                return AirlockMoveDrag(to_section=self._sec(tokens[2]), drag_character=self._cid(drag_ref))
            if sub == "throw":
                if len(tokens) < 4:
                    raise ActionError("Uso: airlock throw <IID|NAME> <SEC|OUTER_SPACE>")
                to_sec = self._sec(tokens[-1])
                item_ref = " ".join(tokens[2:-1]).strip()
                act = actor or self._active_cid()
                inv = list((getattr(self.state, 'characters', {}) or {}).get(act).items) if act in (getattr(self.state, 'characters', {}) or {}) else []
                iid = self._iid(item_ref, candidates=inv)
                return AirlockThrow(item=iid, to_section=to_sec)
            if sub == "eject":
                if len(tokens) < 3:
                    raise ActionError("Uso: airlock eject <DOWNCID>")
                tgt_ref = " ".join(tokens[2:]).strip()
                return AirlockEjectDown(target_character=self._cid(tgt_ref))
            raise ActionError("Uso: airlock move|movedrag|throw|eject ...")


        # Section Action: Data Mine (SHRED_ROOM) — permitido como subacción
        # para Bribe/Kompromat (RM 15.5.4 / 15.5.5: "perform one Action").
        if cmd in ("datamine", "data-mine", "mine", "dm"):
            if len(tokens) < 2:
                raise ActionError("Uso: datamine <IID|NAME|SEC>")
            ref = " ".join(tokens[1:]).strip()
            iid = self._resolve_datamine_target(ref)
            return DataMine(item=iid)

        raise ActionError(f"Acción no reconocida: {cmd}")

    def _maybe_ask_consent_for_komp(self, state: GameState, token: ItemId) -> Optional[bool]:
        cp = state.current_player()
        tok = getattr(state, "items", {}).get(token)
        if not tok or getattr(tok, "kind", "") != "kompromat" or not getattr(tok, "kompromat_target", None):
            return None
        tgt = tok.kompromat_target
        owner = state.pc_owner_pid(tgt) if hasattr(state, "pc_owner_pid") else None
        if owner is None or owner == cp.pid:
            return True
        print(f"\n>>> Pasa el móvil a: {owner} (decide Kompromat sobre tu PC)")
        ans = input("¿Consientes? (y/n): ").strip().lower()
        return ans.startswith("y")

    def _maybe_ask_consent_for_bribe(self, state: GameState, tgt: str) -> Optional[bool]:
        cp = state.current_player()
        owner = state.pc_owner_pid(tgt) if hasattr(state, "pc_owner_pid") else None
        if owner is None or owner == cp.pid:
            return True
        print(f"\n>>> Pasa el móvil a: {owner} (decide Bribe sobre tu PC)")
        ans = input("¿Consientes? (y/n): ").strip().lower()
        return ans.startswith("y")

    def _resolve_phase(self) -> None:
        """Fase RESOLVE (RM 15.7).

        - Se ejecuta al final de cada turno.
        - Si hay varios Time Markers del jugador actual que resuelven,
          puede elegir el orden.
        """
        if bool(getattr(self.state, 'stationfall_triggered', False)):
            return

        cp = self.state.current_player()
        if not hasattr(self.state, 'time_markers_due_for_player') or not hasattr(self.state, 'resolve_time_marker'):
            return

        due = list(self.state.time_markers_due_for_player(cp.pid))

        if due:
            print("\n--- RESOLVE (Time Markers) ---")

        while due:
            if len(due) == 1:
                tm = due.pop(0)
                msg = self.state.resolve_time_marker(int(getattr(tm, 'mid', 0)))
                print("⏳ " + msg)
                if bool(getattr(self.state, 'stationfall_triggered', False)):
                    return
                continue


            print("Time Markers a resolver (elige orden):")
            for i, tm in enumerate(due, start=1):
                print(f"  {i}. id={tm.mid} {tm.kind}@{tm.target} (colocado en minute {tm.placed_minute})")
            ans = input("Resolve # (1..n, Enter=1): ").strip()
            idx = 0
            if ans:
                try:
                    idx = int(ans) - 1
                except ValueError:
                    idx = 0
            if idx < 0 or idx >= len(due):
                idx = 0
            tm = due.pop(idx)
            msg = self.state.resolve_time_marker(int(getattr(tm, 'mid', 0)))
            print("⏳ " + msg)
            if bool(getattr(self.state, 'stationfall_triggered', False)):
                return

        # Reglas de habitaciones en RESOLVE (mapa básico).
        if hasattr(self.state, 'apply_resolve_phase_room_rules'):
            msgs = list(self.state.apply_resolve_phase_room_rules(cp.pid))
            for m in msgs:
                print(str(m))

        # RM 15.7.3: si hay Monster(s) en juego, actúan después de resolver otros eventos.
        if hasattr(self.state, 'resolve_project_x_monsters'):
            def _chooser(prompt: str, choices: List[tuple]) -> str:
                print("\n" + str(prompt))
                for i, (_val, label) in enumerate(choices, start=1):
                    print(f"  {i}. {label}")
                ans = input("Elige # (Enter=1): ").strip()
                idx = 0
                if ans:
                    try:
                        idx = int(ans) - 1
                    except ValueError:
                        idx = 0
                if idx < 0 or idx >= len(choices):
                    idx = 0
                return str(choices[idx][0]).upper()

            msgs = list(self.state.resolve_project_x_monsters(cp.pid, chooser=_chooser))
            for m in msgs:
                print(str(m))

    def _resolve_pending_free_drops(self) -> None:
        """Resuelve drops gratuitos que requieren elección del jugador activo.

        Por ahora se usa para Contamination: si al contaminarte no tienes slots libres,
        el jugador activo elige qué Item se cae (gratis).
        """
        q = getattr(self.state, 'pending_free_drop_queue', None)
        if not q:
            return

        while getattr(self.state, 'pending_free_drop_queue', None):
            req = self.state.pending_free_drop_queue.pop(0)
            cid = str(req.get('cid', '')).upper()
            reason = str(req.get('reason', '')).upper()
            ch = getattr(self.state, 'characters', {}).get(cid)
            if ch is None:
                continue

            items = list(getattr(ch, 'items', []) or [])
            if not items:
                continue

            sec = str(getattr(ch, 'section', '')).upper()
            if reason == 'CONTAMINATION':
                banner = "☣ CONTAMINATION"
            elif reason == 'REVEAL_POWER_ITEM':
                banner = "🎁 REVEAL POWER (Item Limit)"
            else:
                banner = "🆓 FREE DROP"
            print("\n" + banner)
            print(f"{cid}:{getattr(ch, 'name', cid)} está sin slots libres. ¿Qué item quieres dropear en {sec}?")
            for i, iid in enumerate(items, start=1):
                it = getattr(self.state, 'items', {}).get(iid)
                nm = getattr(it, 'name', iid) if it else iid
                print(f"  {i}. {iid} — {nm}")
            ans = input("Elige # (Enter=1): ").strip()
            idx = 0
            if ans:
                try:
                    idx = int(ans) - 1
                except ValueError:
                    idx = 0
            if idx < 0 or idx >= len(items):
                idx = 0

            iid = items[idx]
            it = getattr(self.state, 'items', {}).get(iid)
            nm = getattr(it, 'name', iid) if it else iid

            # Drop gratis (sin acción) en la misma sección.
            try:
                ch.items.remove(iid)
            except Exception:
                continue
            self.state.section_items.setdefault(sec, []).append(iid)
            print(f"🆓 DROP: {cid} deja {iid} ({nm}) en {sec}.")
    def _resolve_pending_reveal_powers(self) -> None:
        """Resuelve Reveal Powers de un solo uso que requieren elección inmediata.

        Se encolan en `pending_reveal_power_queue` al hacer Reveal como PC.
        """
        q = getattr(self.state, 'pending_reveal_power_queue', None)
        if not q:
            return

        def _mark_resolution(pcid: str, power: str, status: str) -> None:
            """Guarda la resolución de un Reveal Power para UI (ACTIVATED/SKIPPED)."""
            try:
                pcid_u = str(pcid).upper()
                ch = getattr(self.state, 'characters', {}).get(pcid_u)
                if ch is None:
                    return
                d = getattr(ch, 'pc_reveal_power_resolution', None)
                if not isinstance(d, dict):
                    try:
                        ch.pc_reveal_power_resolution = {}
                    except Exception:
                        return
                    d = getattr(ch, 'pc_reveal_power_resolution', {})
                d[str(power).upper()] = str(status).upper()
            except Exception:
                pass

        while getattr(self.state, 'pending_reveal_power_queue', None):
            req = self.state.pending_reveal_power_queue.pop(0)
            power = str(req.get('power', '')).upper()

            # --- Engineer: OVERLOAD ---
            if power == AB.OVERLOAD:
                revealing_pid = str(req.get('revealing_pid', '')).strip()
                pcid = str(req.get('pcid', '')).upper()
                targets = [str(x).upper() for x in (req.get('targets', []) or [])]

                # Validación: el objetivo debe seguir siendo una Section On Board.
                try:
                    onb = set(self.state.on_board_sections()) if hasattr(self.state, 'on_board_sections') else set()
                except Exception:
                    onb = set()

                valid = []
                for sec in targets:
                    su = str(sec).upper()
                    if not su:
                        continue
                    if onb and su not in onb:
                        continue
                    if hasattr(self.state, 'is_outer_space') and self.state.is_outer_space(su):
                        continue
                    if su in ('MESO', 'OUT_OF_GAME'):
                        continue
                    valid.append(su)

                valid = sorted(set(valid))
                if not valid:
                    continue

                print("\n⚡  REVEAL POWER: Overload")
                for i, sec in enumerate(valid, start=1):
                    tag = ''
                    try:
                        if sec in getattr(self.state, 'damaged_sections', set()):
                            tag = ' [DAMAGED]'
                    except Exception:
                        pass
                    print(f"  {i}. {sec}{tag}")

                ans = input("Elige # (Enter=0): ").strip()
                if ans.lower() in ('', '0', 'n', 'no', 'skip', 'saltar'):
                    print("⏭️  Reveal Power: omitido.")
                    _mark_resolution(pcid, AB.OVERLOAD, 'SKIPPED')
                    continue

                try:
                    idx2 = int(ans) - 1
                except ValueError:
                    idx2 = -1
                if idx2 < 0 or idx2 >= len(valid):
                    print("Opción inválida. Reveal Power omitido.")
                    _mark_resolution(pcid, AB.OVERLOAD, 'SKIPPED')
                    continue

                chosen_sec = valid[idx2]
                try:
                    msg2 = self.state.apply_overload(revealing_pid, chosen_sec)
                except Exception as e:
                    msg2 = f"REVEAL POWER: error al aplicar Overload ({e})"
                print("⚡  " + str(msg2))
                _mark_resolution(pcid, AB.OVERLOAD, 'ACTIVATED')
                continue

            # --- Stowaway: SECRET_CACHE ---
            if power == AB.SECRET_CACHE:
                revealing_pid = str(req.get('revealing_pid', '')).strip()
                pcid = str(req.get('pcid', '')).upper()
                targets = [str(x).upper() for x in (req.get('targets', []) or [])]

                valid = []
                for cid in targets:
                    ch = getattr(self.state, 'characters', {}).get(cid)
                    if ch is None:
                        continue
                    if bool(getattr(ch, 'annihilated', False)) or bool(getattr(ch, 'escaped', False)):
                        continue
                    valid.append(cid)

                valid = sorted(set(valid))
                if not valid:
                    continue

                print("\n🧰  REVEAL POWER: Secret Cache")
                print("Elige quién gana 1 Helmet (0=omitir):")
                for i, cid in enumerate(valid, start=1):
                    ch = self.state.characters.get(cid)
                    nm = getattr(ch, 'name', cid) if ch else cid
                    tag = ""
                    if cid == pcid:
                        tag = " [STOWAWAY]"
                    print(f"  {i}. {cid}:{nm}{tag}")

                ans = input("Elige # (Enter=1): ").strip()
                if ans.lower() in ('0', 'n', 'no', 'skip', 'saltar'):
                    print("⏭️  Reveal Power: omitido.")
                    _mark_resolution(pcid, AB.SECRET_CACHE, 'SKIPPED')
                    continue

                if ans == '':
                    idx2 = 0
                else:
                    try:
                        idx2 = int(ans) - 1
                    except ValueError:
                        idx2 = -1

                if idx2 < 0 or idx2 >= len(valid):
                    print("Opción inválida. Reveal Power omitido.")
                    _mark_resolution(pcid, AB.SECRET_CACHE, 'SKIPPED')
                    continue

                chosen = valid[idx2]
                try:
                    msg2 = self.state.apply_secret_cache(revealing_pid, chosen)
                except Exception as e:
                    msg2 = f"REVEAL POWER: error al aplicar Secret Cache ({e})"
                print("🧰  " + str(msg2))
                # Si el Helmet excede Item Limit, se encola un free drop; resolver ahora.
                self._resolve_pending_free_drops()
                _mark_resolution(pcid, AB.SECRET_CACHE, 'ACTIVATED')
                continue

            # --- Stranger: HOMEWORK ---
            if power == AB.HOMEWORK:
                revealing_pid = str(req.get('revealing_pid', '')).strip()
                pcid = str(req.get('pcid', '')).upper()
                bcid = str(req.get('bcid', '')).upper()

                bc_ch = getattr(self.state, 'characters', {}).get(bcid)
                if not bcid or bc_ch is None:
                    _mark_resolution(pcid, AB.HOMEWORK, 'SKIPPED')
                    continue
                if bool(getattr(bc_ch, 'annihilated', False)) or bool(getattr(bc_ch, 'escaped', False)) or (not bc_ch.is_live()):
                    # Si el BC ya no puede actuar, omitimos sin preguntar.
                    _mark_resolution(pcid, AB.HOMEWORK, 'SKIPPED')
                    continue

                nm = getattr(bc_ch, 'name', bcid)
                print()
                print("🌀  REVEAL POWER: Homework")
                print(f"Stranger permite revelar tu BC y hacer 1 accion con ese BC: {bcid}:{nm}")
                ans = input("¿Usar Homework? (s/N): ").strip().lower()
                if ans in ('s', 'si', 'y', 'yes', '1'):
                    # Al aceptar, el jugador revela públicamente su BC.
                    try:
                        pst = self.state.player_by_id(revealing_pid)
                        setattr(pst, 'bonus_character_public', True)
                    except Exception:
                        pass
                    # Marcar que la PROXIMA accion del turno se ejecuta con el BC como actor.
                    setattr(self.state, 'homework_actor', bcid)
                    setattr(self.state, 'homework_pid', revealing_pid)
                    print(f"✅ Homework activo: tu proxima accion se hara con {bcid}:{nm} (sin activar).")
                    print("   Escribe ahora el comando de una accion normal (move/pick/drop/attack/...);")
                    print("   tras esa accion, continuaras el turno con normalidad.")
                    _mark_resolution(pcid, AB.HOMEWORK, 'ACTIVATED')
                else:
                    print("⏭️  Reveal Power: omitido.")
                    _mark_resolution(pcid, AB.HOMEWORK, 'SKIPPED')
                continue

            # --- Counselor: RECORDED_CONFESSIONAL ---
            if power != AB.RECORDED_CONFESSIONAL:
                continue

            revealing_pid = str(req.get('revealing_pid', '')).strip()
            pcid = str(req.get('pcid', '')).upper()
            sec = str(req.get('section', '')).upper()
            targets = [str(x).upper() for x in (req.get('targets', []) or [])]

            ch_pc = getattr(self.state, 'characters', {}).get(pcid)
            if ch_pc is None:
                continue

            valid = []
            for cid in targets:
                ch = getattr(self.state, 'characters', {}).get(cid)
                if ch is None:
                    continue
                if 'HUMAN' not in str(getattr(ch, 'ctype', '')).upper():
                    continue
                if bool(getattr(ch, 'annihilated', False)) or bool(getattr(ch, 'escaped', False)):
                    continue
                try:
                    if not self.state.colocated(pcid, cid):
                        continue
                except Exception:
                    continue
                valid.append(cid)

            valid = sorted(set(valid))
            if not valid:
                continue

            print("\n🎙️  REVEAL POWER: Recorded Confessional")
            print(f"Elige un Humano colocated con {pcid}:{getattr(ch_pc, 'name', pcid)} en {sec} (0=omitir):")
            for i, cid in enumerate(valid, start=1):
                ch = self.state.characters.get(cid)
                nm = getattr(ch, 'name', cid) if ch else cid
                st = str(getattr(ch, 'status', '')).upper() if ch else ''
                tag = f" [{st}]" if st else ''
                print(f"  {i}. {cid}:{nm}{tag}")

            ans = input("Elige # (Enter=0): ").strip()
            if ans.lower() in ('', '0', 'n', 'no', 'skip', 'saltar'):
                print("⏭️  Reveal Power: omitido.")
                _mark_resolution(pcid, AB.RECORDED_CONFESSIONAL, 'SKIPPED')
                continue

            try:
                idx = int(ans) - 1
            except ValueError:
                idx = -1
            if idx < 0 or idx >= len(valid):
                print("Opción inválida. Reveal Power omitido.")
                _mark_resolution(pcid, AB.RECORDED_CONFESSIONAL, 'SKIPPED')
                continue

            chosen = valid[idx]
            try:
                msg = self.state.apply_recorded_confessional(revealing_pid, chosen)
            except Exception as e:
                msg = f"REVEAL POWER: error al aplicar ({e})"
            print("🎙️  " + str(msg))
            _mark_resolution(pcid, AB.RECORDED_CONFESSIONAL, 'ACTIVATED')


    def _resolve_pending_activation_powers(self) -> None:
        """Resuelve powers que ocurren al inicio de una Activation.

        Implementado:
          - Station Chief: FORCEFUL_PRESENCE (Free Basic Action con un NPC)
        """
        q = getattr(self.state, 'pending_activation_power_queue', None)
        if not q:
            return

        while getattr(self.state, 'pending_activation_power_queue', None):
            req = self.state.pending_activation_power_queue.pop(0)
            power = str(req.get('power') or '').strip()

            handlers = {
                AB.FORCEFUL_PRESENCE: self._ui_activation_power_forceful_presence,
            }

            handler = handlers.get(power)
            if handler is None:
                continue

            try:
                handler(req)
            except Exception:
                # No rompemos el loop de UI si un power falla.
                continue


    def _ui_activation_power_forceful_presence(self, req: dict) -> None:
        """Station Chief (reveal-tag): Forceful Presence."""

        source = str(req.get('source') or getattr(self.state, 'active_character_id', '') or '').upper()
        if not source or source not in getattr(self.state, 'characters', {}):
            return

        src_ch = self.state.characters[source]
        if (not src_ch.is_live()) or bool(getattr(src_ch, 'escaped', False)) or bool(getattr(src_ch, 'annihilated', False)):
            return

        # Candidatos: NPC colocated con el Station Chief, o NPC con OFFICER en cualquier sección.
        candidates = []  # list[(cid, label)]
        for cid, ch in getattr(self.state, 'characters', {}).items():
            cid_u = str(cid).upper()
            if cid_u == source:
                continue
            if getattr(ch, 'pc_owner', None) is not None:
                continue  # ya es PC
            if bool(getattr(ch, 'escaped', False)) or bool(getattr(ch, 'annihilated', False)):
                continue
            if not ch.is_live():
                continue

            coloc = False
            try:
                coloc = bool(self.state.colocated(source, cid_u)) if hasattr(self.state, 'colocated') else (str(getattr(ch, 'section', '')).upper() == str(getattr(src_ch, 'section', '')).upper())
            except Exception:
                coloc = (str(getattr(ch, 'section', '')).upper() == str(getattr(src_ch, 'section', '')).upper())

            off = False
            try:
                off = bool(ch.has_ability(AB.OFFICER))
            except Exception:
                off = False

            if not (coloc or off):
                continue

            nm = getattr(ch, 'name', cid_u)
            sec = str(getattr(ch, 'section', '')).upper()
            tags = []
            if coloc:
                tags.append('COLOCATED')
            if off:
                tags.append('OFFICER')
            tag_txt = (" [" + ",".join(tags) + "]") if tags else ""
            candidates.append((cid_u, f"{cid_u}:{nm}@{sec}{tag_txt}"))

        candidates = sorted(candidates, key=lambda x: x[0])
        if not candidates:
            return        # Nombre desde el diccionario de habilidades (si está disponible).
        defn = getattr(AB, 'ABILITY_DEFS', {}).get(AB.FORCEFUL_PRESENCE)
        power_name = getattr(defn, 'label', '') or 'FORCEFUL PRESENCE'

        print(f"\n🧲  ACTIVATION POWER: {power_name}")
        print("Elige 1 NPC para 1 Basic Action gratis (0=omitir):")
        for i, (_, lbl) in enumerate(candidates, start=1):
            print(f"  {i}. {lbl}")

        ans = input("Elige # (Enter=0): ").strip()
        if ans.lower() in ('', '0', 'n', 'no', 'skip', 'saltar'):
            print("⏭️  Activation Power: omitido.")
            return

        try:
            idx = int(ans) - 1
        except ValueError:
            idx = -1
        if idx < 0 or idx >= len(candidates):
            print("Opción inválida. Activation Power omitido.")
            return

        chosen = candidates[idx][0]
        setattr(self.state, 'forceful_presence_actor', chosen)
        print(f"✅  {power_name} preparado: próxima Basic Action usa {chosen} y no consume acciones.")


    def play_one_turn(self) -> None:
        # Normalmente el turno empieza aquí, pero si venimos de un LOAD guardado
        # en mitad de un turno, NO debemos resetear los flags del turno.
        if not bool(getattr(self.state, 'turn_in_progress', False)):
            self.state.start_player_turn()
        else:
            # Aun así, mantenemos flags de UI sincronizados.
            try:
                self.state.refresh_exhausted_flags()
            except Exception:
                pass
        print_state(self.state)
        _print_hud(self.state)

        while True:
            # Si Stationfall se activó durante una acción/resolve, el juego termina inmediatamente (RM 16.1).
            if bool(getattr(self.state, 'stationfall_triggered', False)):
                print("\n💥 STATIONFALL se ha activado: el juego termina inmediatamente.")
                break

            cp = self.state.current_player()
            text = input(f"{cp.display_name()}> ").strip()
            if not text:
                continue

            low = text.lower()

            if low == "undo":
                self._undo()
                print_state(self.state)
                _print_hud(self.state)
                continue

            if low == "help":
                _print_help()
                _print_hud(self.state)
                continue

            if low == "state":
                print_state(self.state)
                _print_hud(self.state)
                continue

            if low == "myid":
                print(f"\nTus Identity Cards (solo tu) [{cp.display_name()}]:")

                # Mano de Identity Cards (sin elegir PC/BC todavia)
                hand = list(getattr(cp, "identity_hand", []) or [])
                if hand:
                    print("  En mano (2):")
                    cards = getattr(self.state, "identity_cards", {}) or {}
                    for i, cid in enumerate(hand, 1):
                        nm = self.state.characters[cid].name if cid in self.state.characters else "?"
                        card = cards.get(str(cid).upper())
                        if card is not None:
                            bk = str(getattr(card, "bonus_kind", "-") or "-").upper()
                            bi = int(getattr(card, "bonus_icons", 0) or 0)
                            print(f"    {i}. {cid} ({nm}) | {bk} x{bi}")
                        else:
                            print(f"    {i}. {cid} ({nm})")
                else:
                    # Si ya has elegido PC/BC, la mano puede estar vacia a proposito.
                    si_tmp = getattr(cp, 'secret_identity', None)
                    bc_tmp = getattr(cp, 'bonus_character', None)
                    if si_tmp or bc_tmp or bool(getattr(self.state, 'identities_chosen', False)):
                        print('  En mano: (ya elegidas)')
                    else:
                        print("  En mano: (aun no se han repartido)\n  Usa el comando de setup 'deal'.")

                # Si ya estan elegidas (todavia no lo hacemos en setup, pero lo dejamos listo)
                si = getattr(cp, "secret_identity", None)
                bc = getattr(cp, "bonus_character", None)
                if si or bc:
                    print("\n  Elegidas:")
                    if si:
                        nm = self.state.characters[si].name if si in self.state.characters else "?"
                        rev = getattr(cp, "revealed_character", None)
                        extra_rev = f" | REVEALED={rev}" if rev else ""
                        print(f"    PC (Principal): {si} ({nm}){extra_rev}")
                    else:
                        print("    PC (Principal): (no asignada)")

                    if bc:
                        nm = self.state.characters[bc].name if bc in self.state.characters else "?"
                        bk = getattr(cp, "bonus_kind", None) or "-"
                        bi = int(getattr(cp, "bonus_icons", 0) or 0)
                        try:
                            cards = getattr(self.state, "identity_cards", {}) or {}
                            card = cards.get(str(bc).upper()) if bc else None
                            if card is not None:
                                bk = str(getattr(card, "bonus_kind", bk) or bk).upper()
                                bi = int(getattr(card, "bonus_icons", bi) or bi)
                        except Exception:
                            pass
                        bd = bool(getattr(cp, "bonus_points_disabled", False))
                        extra = " | BONUS DISABLED" if bd else ""
                        print(f"    BC (Secundaria): {bc} ({nm}) | {bk} x{bi}{extra}")
                    else:
                        print("    BC (Secundaria): (no asignada)")

                _print_hud(self.state)
                continue

            if low == "mykomp":
                print(f"\n🕵️  Tu Kompromat (detalle, solo tú) [{cp.display_name()}]:")
                hand = getattr(cp, "kompromat_hand", [])
                if not hand:
                    print("  (ninguno)")
                else:
                    for i, kid in enumerate(hand, 1):
                        tok = getattr(self.state, "items", {}).get(kid)
                        tgt = getattr(tok, "kompromat_target", None) if tok else None
                        tgt_name = self.state.characters[tgt].name if tgt and tgt in self.state.characters else "?"
                        print(f"  {i}. {kid} -> {tgt}:{tgt_name}")
                used = getattr(self.state, "used_npc_kompromat", {}) or {}
                print("\n📎 Kompromat usados sobre NPC (descartados):")
                if not used:
                    print("  (ninguno)")
                else:
                    for i, kid in enumerate(sorted(used.keys()), 1):
                        tok = used.get(kid)
                        tgt = getattr(tok, "kompromat_target", None) if tok else None
                        tgt_name = self.state.characters[tgt].name if tgt and tgt in self.state.characters else "?"
                        print(f"  {i}. {kid} -> {tgt}:{tgt_name}")

                _print_hud(self.state)
                continue

            if low in ("peekx", "peek-x", "peek_x"):
                # X-SECRET: "peek Project X card" (RM 9.4.1)
                disc_cid = getattr(cp, "activation_disc", None)
                if not disc_cid:
                    print("❌ PEEKX: necesitas tu disco de activación sobre un Character con X-SECRET (si has hecho WAIT, el disco no está).")
                    _print_hud(self.state)
                    continue

                disc_cid = str(disc_cid).upper()
                chx = self.state.characters.get(disc_cid)
                if chx is None or bool(getattr(chx, "annihilated", False)):
                    print("❌ PEEKX: tu disco está en un Character inválido.")
                    _print_hud(self.state)
                    continue

                # ¿Tiene X-SECRET?
                data = getattr(chx, "data", {}) or {}
                def _norm_dt(s: str) -> str:
                    return re.sub(r"[^A-Z0-9]", "", str(s).upper())
                has_x = any(_norm_dt(k) == "XSECRET" and int(v or 0) > 0 for k, v in data.items())
                if not has_x:
                    print(f"❌ PEEKX: tu disco está en {disc_cid} pero ese Character no tiene X-SECRET.")
                    _print_hud(self.state)
                    continue

                pending = getattr(self.state, "project_x_pending_monsters", {}) or {}
                released = getattr(self.state, "monsters", {}) or {}

                if pending:
                    mons = [pending[k] for k in sorted(pending.keys())]
                    if len(mons) == 1:
                        m = mons[0]
                        print(f"🔎 PEEKX [{cp.display_name()}] (disco en {disc_cid}): Project X = {m.name} (kind={m.kind}, id={m.mid}) [PENDING]")
                    else:
                        names = ", ".join([f"{m.name}({m.mid})" for m in mons])
                        print(f"🔎 PEEKX [{cp.display_name()}] (disco en {disc_cid}): Project X pendientes = {names}")
                elif released:
                    mons = [released[k] for k in sorted(released.keys())]
                    if len(mons) == 1:
                        m = mons[0]
                        print(f"🔎 PEEKX [{cp.display_name()}] (disco en {disc_cid}): Project X ya liberado = {m.name} (kind={m.kind}, id={m.mid})")
                    else:
                        names = ", ".join([f"{m.name}({m.mid})" for m in mons])
                        print(f"🔎 PEEKX [{cp.display_name()}] (disco en {disc_cid}): Monsters en juego = {names}")
                else:
                    print(f"🔎 PEEKX [{cp.display_name()}] (disco en {disc_cid}): No hay Project X configurado en esta partida.")

                _print_hud(self.state)
                continue

            if low.startswith("save"):
                # Guardado de partida (snapshot exacto). No consume acciones ni afecta al turno.
                parts = shlex.split(text)
                if parts and parts[0].lower() == "save":
                    name = parts[1] if len(parts) > 1 else None
                    try:
                        from save_load import save_game
                        path = save_game(self, name=name)
                        print(f"💾 Guardado: {path}")
                    except Exception as e:
                        print(f"❌ SAVE: no se pudo guardar: {e}")
                    _print_hud(self.state)
                    continue

            if low in ("saves", "listsaves"):
                try:
                    from save_load import list_saves
                    arr = list_saves()
                    if not arr:
                        print("(No hay saves en ./saves)")
                    else:
                        print("\nSaves disponibles:")
                        for p in arr:
                            print(f"  - {p}")
                        print("")
                except Exception as e:
                    print(f"❌ SAVES: error listando saves: {e}")
                _print_hud(self.state)
                continue




            if low == "end":
                # Guardar snapshot para permitir UNDO tras terminar el turno (incluye RESOLVE)
                self._push_undo()
                break

            # Permite nombres con espacios si se escriben entre comillas.
            # Ej: attack "Station Chief"  |  tp "Station Chief" BRIDGE
            tokens = shlex.split(text)
            cmd = tokens[0].lower()

            # alias simpático
            if cmd == "copy":
                cmd = "copydata"

            try:
                self._push_undo()

                # ---------- DEBUG ----------
                if cmd == "status":
                    if len(tokens) != 3:
                        raise ActionError("Uso: status <CID> live|down")
                    cid = self._cid(tokens[1])
                    st = tokens[2].upper()
                    msg = apply_action(self.state, SetCharacterStatus(character=cid, status=st))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "escape":
                    if len(tokens) != 3 or tokens[2].lower() not in ("on", "off"):
                        raise ActionError("Uso: escape <CID> on|off")
                    cid = self._cid(tokens[1])
                    on = tokens[2].lower() == "on"
                    msg = apply_action(self.state, SetCharacterStatus(character=cid, escaped=on))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "annihilate":
                    if len(tokens) != 3 or tokens[2].lower() not in ("on", "off"):
                        raise ActionError("Uso: annihilate <CID> on|off")
                    cid = self._cid(tokens[1])
                    on = tokens[2].lower() == "on"
                    msg = apply_action(self.state, SetCharacterStatus(character=cid, annihilated=on))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue


                if cmd == "damage":
                    if len(tokens) != 2:
                        raise ActionError("Uso: damage <SEC>")
                    sec = self._sec(tokens[1])
                    try:
                        changed = self.state.damage_section(sec)
                    except Exception as e:
                        raise ActionError(str(e))
                    msg = f"DEBUG: DAMAGE {sec}" if changed else f"DEBUG: DAMAGE {sec} (ya estaba dañada)"
                    self.state.turn_log.append(msg)
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "repair":
                    if len(tokens) != 2:
                        raise ActionError("Uso: repair <SEC>")
                    sec = self._sec(tokens[1])
                    try:
                        changed = self.state.repair_section(sec)
                    except Exception as e:
                        raise ActionError(str(e))
                    msg = f"DEBUG: REPAIR {sec}" if changed else f"DEBUG: REPAIR {sec} (ya estaba reparada)"
                    self.state.turn_log.append(msg)
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "abandonship":
                    # DEBUG: control directo del estado global Abandon Ship.
                    if len(tokens) == 1:
                        cur = 'ON' if getattr(self.state, 'abandon_ship', False) else 'OFF'
                        print(f"ℹ️  Abandon Ship: {cur}")
                        _print_hud(self.state)
                        continue
                    if len(tokens) != 2 or tokens[1].lower() not in ("on", "off", "toggle"):
                        raise ActionError("Uso: abandonship on|off|toggle")
                    arg = tokens[1].lower()
                    if arg == "toggle":
                        new_val = not bool(getattr(self.state, 'abandon_ship', False))
                    else:
                        new_val = (arg == "on")
                    try:
                        changed = self.state.set_abandon_ship(new_val) if hasattr(self.state, 'set_abandon_ship') else False
                        self.state.abandon_ship = bool(new_val)
                    except Exception as e:
                        raise ActionError(str(e))
                    msg = f"DEBUG: ABANDON SHIP {'ON' if new_val else 'OFF'}" + ("" if changed else "")
                    self.state.turn_log.append(msg)
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "reentry":
                    # DEBUG: controlar/revelar el token de Minute 0.
                    if len(tokens) == 1:
                        rev = bool(getattr(self.state, 'reentry_revealed', False))
                        tok = str(getattr(self.state, 'reentry_token', 'STATIONFALL')).upper() if rev else "?"
                        st = "REVEALED" if rev else "HIDDEN"
                        print(f"ℹ️  Re-entry token: {st} | value={tok}")
                        _print_hud(self.state)
                        continue
                    if len(tokens) == 2 and tokens[1].lower() == "reveal":
                        try:
                            tok = self.state.reveal_reentry_token() if hasattr(self.state, 'reveal_reentry_token') else str(getattr(self.state, 'reentry_token', 'STATIONFALL')).upper()
                            self.state.reentry_revealed = True
                        except Exception as e:
                            raise ActionError(str(e))
                        msg = f"DEBUG: REENTRY revealed -> {tok}"
                        self.state.turn_log.append(msg)
                        print("✅ " + msg)
                        _print_hud(self.state)
                        continue
                    if len(tokens) == 3 and tokens[1].lower() == "set":
                        val = tokens[2].upper()
                        try:
                            if hasattr(self.state, 'set_reentry_token'):
                                self.state.set_reentry_token(val)
                            else:
                                if val not in ("SAFE", "STATIONFALL"):
                                    raise ValueError("usa SAFE o STATIONFALL")
                                self.state.reentry_token = val
                                self.state.reentry_revealed = False
                        except Exception as e:
                            raise ActionError(str(e))
                        msg = f"DEBUG: REENTRY set -> {val} (hidden)"
                        self.state.turn_log.append(msg)
                        print("✅ " + msg)
                        _print_hud(self.state)
                        continue
                    raise ActionError("Uso: reentry | reentry reveal | reentry set safe|stationfall")

                if cmd in ("tp", "teleport"):
                    if len(tokens) < 3:
                        raise ActionError("Uso: tp <CID> <SEC>")

                    # Permite secciones sin '_' y también con espacios (sin comillas),
                    # y personajes con nombre con espacios.
                    args = tokens[1:]
                    cid = None
                    sec = None
                    cid_ref = None
                    sec_ref = None
                    # Consumimos el sufijo más largo como sección.
                    for split in range(len(args) - 1, 0, -1):
                        cid_cand = " ".join(args[:split]).strip()
                        sec_cand = " ".join(args[split:]).strip()
                        try:
                            cid_try = self._cid(cid_cand)
                            sec_try = self._sec(sec_cand)
                        except Exception:
                            continue
                        cid, sec = cid_try, sec_try
                        cid_ref, sec_ref = cid_cand, sec_cand
                        break

                    if cid is None or sec is None:
                        raise ActionError("Uso: tp <CID> <SEC> (SEC admite sin '_' y también con espacios)")

                    msg = apply_action(self.state, TeleportCharacter(character=cid, to_section=sec))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd in ("spawnitem", "spawn", "additem"):
                    # DEBUG: crear un item nuevo y colocarlo en una sección.
                    # Útil para continuar una simulación sin rehacer todo el setup.
                    if len(tokens) < 3:
                        raise ActionError("Uso: spawnitem <SEC> <ITEM> [charges]")

                    # Permite secciones con espacios SIN comillas, consumiendo el prefijo más largo.
                    args = tokens[1:]
                    sec = None
                    rest = None
                    for split in range(len(args) - 1, 0, -1):
                        sec_cand = " ".join(args[:split]).strip()
                        try:
                            sec = self._sec(sec_cand)
                        except Exception:
                            continue
                        rest = args[split:]
                        break
                    if sec is None or rest is None or not rest:
                        raise ActionError("Uso: spawnitem <SEC> <ITEM> [charges] (si SEC tiene espacios, también sirve sin comillas)")

                    # Permite opcionalmente un número final como 'charges'
                    charges_override = None
                    if len(rest) >= 2 and str(rest[-1]).isdigit():
                        charges_override = int(rest[-1])
                        rest = rest[:-1]

                    item_raw = " ".join(rest).strip()
                    if not item_raw:
                        raise ActionError("Uso: spawnitem <SEC> <ITEM> [charges]")

                    def _norm_local(s: str) -> str:
                        return re.sub(r"[^A-Z0-9]", "", str(s).upper())

                    want = _norm_local(item_raw)

                    # Tabla mínima de items del prototipo.
                    # (Si algún día hace falta más, ampliamos aquí sin tocar el sistema de guardado.)
                    table = {
                        "HELMET": ("Helmet", "HELMET", 0),
                        "NANOGEL": ("Nanogel", "NANOGEL", 2),
                        "GUN": ("Gun", "GUN", 0),
                        "PISTOL": ("Gun", "GUN", 0),
                        "BLUDGEON": ("Bludgeon", "BLUDGEON", 0),
                        "BRIEFCASE": ("Briefcase", "BRIEFCASE", 0),
                        "ROCKETWINGS": ("Rocket Wings", "ROCKET_WINGS", 0),
                        "ARTIFACT": ("Artifact", "ARTIFACT", 0),
                        "ANTIMATTER": ("Antimatter", "ANTIMATTER", 0),
                        "BOMB": ("Bomb", "BOMB", 0),
                    }

                    # Kompromat (opcional): requiere objetivo.
                    if want in ("KOMPROMAT", "KOMP"):
                        raise ActionError("spawnitem Kompromat: aún no (por ahora usa Helmet/Nanogel/Gun/etc.).")

                    # Aliases simples
                    if want == "ROCKET" or want == "WINGS" or want == "ROCKETWING":
                        want = "ROCKETWINGS"

                    if want not in table:
                        known = ", ".join(sorted(table.keys()))
                        raise ActionError(f"Item desconocido: '{item_raw}'. Implementados: {known}.")

                    name, kind, default_ch = table[want]
                    charges = default_ch if charges_override is None else charges_override

                    # Nuevo id
                    if hasattr(self.state, 'mint_item_id') and callable(getattr(self.state, 'mint_item_id')):
                        new_iid = self.state.mint_item_id()
                    else:
                        # Fallback (no debería hacer falta)
                        import re as _re
                        existing = [str(x).upper() for x in getattr(self.state, 'items', {}).keys()]
                        mx = 0
                        for iid in existing:
                            m = _re.match(r"^I(\d+)$", iid)
                            if m:
                                try:
                                    mx = max(mx, int(m.group(1)))
                                except Exception:
                                    pass
                        new_iid = f"I{mx + 1}"

                    # Crear y colocar
                    self.state.items[new_iid] = Item(iid=new_iid, name=name, kind=kind, charges=int(charges or 0))
                    self.state.section_items.setdefault(sec, []).append(new_iid)

                    extra = f"({charges})" if int(charges or 0) else ""
                    msg = f"DEBUG: SPAWN ITEM {new_iid}:{name}{extra} -> {sec}"
                    try:
                        self.state.turn_log.append(msg)
                    except Exception:
                        pass

                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "hazard":
                    if len(tokens) < 3:
                        raise ActionError("Uso: hazard add|clear ...")
                    sub = tokens[1].lower()
                    if sub == "add":
                        if len(tokens) != 4:
                            raise ActionError("Uso: hazard add <SEC> fire|asphyx")
                        msg = apply_action(self.state, SetHazard(section=self._sec(tokens[2]), kind=tokens[3].upper()))
                        print("✅ " + msg)
                        _print_hud(self.state)
                        continue
                    if sub == "clear":
                        if len(tokens) not in (3, 4):
                            raise ActionError("Uso: hazard clear <SEC> [fire|asphyx]")
                        kind = tokens[3].upper() if len(tokens) == 4 else None
                        msg = apply_action(self.state, ClearHazard(section=self._sec(tokens[2]), kind=kind))
                        print("✅ " + msg)
                        _print_hud(self.state)
                        continue
                    raise ActionError("Uso: hazard add|clear ...")

                if cmd == "pod":
                    if len(tokens) < 3:
                        raise ActionError("Uso: pod add <PODSEC> <SEC> [limit] | pod launch <PODSEC>")
                    sub = tokens[1].lower()
                    if sub == "add":
                        if len(tokens) not in (4, 5):
                            raise ActionError("Uso: pod add <PODSEC> <SEC> [limit]")
                        podsec = tokens[2].upper()
                        sec = tokens[3].upper()
                        lim = int(tokens[4]) if len(tokens) == 5 else None
                        try:
                            self.state.add_pod(podsec, sec, occupancy_limit=lim)
                        except Exception as e:
                            raise ActionError(str(e))
                        msg = f"DEBUG: POD add {podsec} <-> {sec} (limit={lim if lim is not None else '?'})"
                        # log + print
                        self.state.turn_log.append(msg)
                        print("✅ " + msg)
                        _print_hud(self.state)
                        continue

                    if sub == "launch":
                        if len(tokens) != 3:
                            raise ActionError("Uso: pod launch <PODSEC>")
                        podsec = tokens[2].upper()
                        try:
                            msg = self.state.launch_pod(podsec)
                        except Exception as e:
                            raise ActionError(str(e))
                        self.state.turn_log.append(msg)
                        print("✅ " + msg)
                        _print_hud(self.state)
                        continue

                    raise ActionError("Uso: pod add|launch ...")

                if cmd == "airlock":
                    if len(tokens) < 2:
                        raise ActionError(
                            "Uso: airlock move <SEC|OUTER_SPACE> | airlock movedrag <SEC|OUTER_SPACE> <DOWNCID> | "
                            "airlock throw <IID|NAME> <SEC|OUTER_SPACE> | airlock eject <DOWNCID> | airlock add <SEC> [to_outer 0/1] [from_outer 0/1]"
                        )
                    sub = tokens[1].lower()

                    # --- DEBUG/setup ---
                    if sub == "add":
                        if len(tokens) not in (3, 5):
                            raise ActionError("Uso: airlock add <SEC> [to_outer 0/1] [from_outer 0/1]")
                        sec = tokens[2].upper()
                        to_outer = True
                        from_outer = True
                        if len(tokens) == 5:
                            to_outer = bool(int(tokens[3]))
                            from_outer = bool(int(tokens[4]))
                        try:
                            self.state.add_airlock(sec, to_outer=to_outer, from_outer=from_outer)
                        except Exception as e:
                            raise ActionError(str(e))
                        msg = f"DEBUG: AIRLOCK add {sec} (to_outer={1 if to_outer else 0}, from_outer={1 if from_outer else 0})"
                        self.state.turn_log.append(msg)
                        print("✅ " + msg)
                        _print_hud(self.state)
                        continue

                    # --- Section Action ---
                    if sub == "move":
                        if len(tokens) != 3:
                            raise ActionError("Uso: airlock move <SEC|OUTER_SPACE>")
                        msg = apply_action(self.state, AirlockMove(to_section=self._sec(tokens[2])))
                        print("✅ " + msg)
                        _print_hud(self.state)
                        continue

                    if sub == "movedrag":
                        if len(tokens) < 4:
                            raise ActionError("Uso: airlock movedrag <SEC|OUTER_SPACE> <DOWNCID>")
                        drag_ref = " ".join(tokens[3:]).strip()
                        msg = apply_action(
                            self.state,
                            AirlockMoveDrag(to_section=self._sec(tokens[2]), drag_character=self._cid(drag_ref)),
                        )
                        print("✅ " + msg)
                        _print_hud(self.state)
                        continue

                    if sub == "throw":
                        if len(tokens) < 4:
                            raise ActionError("Uso: airlock throw <IID|NAME> <SEC|OUTER_SPACE>")
                        to_sec = str(tokens[-1]).upper()
                        item_ref = " ".join(tokens[2:-1]).strip()
                        act = self._active_cid()
                        inv = list((getattr(self.state, 'characters', {}) or {}).get(act).items) if act in (getattr(self.state, 'characters', {}) or {}) else []
                        iid = self._iid(item_ref, candidates=inv)
                        msg = apply_action(self.state, AirlockThrow(item=iid, to_section=to_sec))
                        print("✅ " + msg)
                        _print_hud(self.state)
                        continue

                    if sub == "eject":
                        if len(tokens) < 3:
                            raise ActionError("Uso: airlock eject <DOWNCID>")
                        tgt_ref = " ".join(tokens[2:]).strip()
                        msg = apply_action(self.state, AirlockEjectDown(target_character=self._cid(tgt_ref)))
                        print("✅ " + msg)
                        _print_hud(self.state)
                        continue

                    raise ActionError("Uso: airlock move|movedrag|throw|eject|add ...")

                # ---------- CARGO CLAW (GRIP) ----------
                if cmd in ("grip", "grippickup", "grip_pickup", "gripdown", "grip_down"):
                    # Section Actions: Grip Pick Up / Grip Down
                    if cmd in ("grippickup", "grip_pickup"):
                        if len(tokens) < 2:
                            raise ActionError("Uso: grippickup <IID|NAME>")
                        item_ref = " ".join(tokens[1:]).strip()
                        cand = list((getattr(self.state, 'section_items', {}) or {}).get(OUTER_SPACE_SECTION, []) or [])
                        iid = self._iid(item_ref, candidates=cand)
                        msg = apply_action(self.state, GripPickUp(item=iid))
                    elif cmd in ("gripdown", "grip_down"):
                        if len(tokens) < 2:
                            raise ActionError("Uso: gripdown <CID>")
                        tgt_ref = " ".join(tokens[1:]).strip()
                        msg = apply_action(self.state, GripDown(target_character=self._cid(tgt_ref)))
                    else:
                        if len(tokens) < 3:
                            raise ActionError("Uso: grip pickup <IID|NAME> | grip down <CID>")
                        sub = tokens[1].lower()
                        if sub in ("pickup", "pick", "p"):
                            if len(tokens) < 3:
                                raise ActionError("Uso: grip pickup <IID|NAME>")
                            item_ref = " ".join(tokens[2:]).strip()
                            cand = list((getattr(self.state, 'section_items', {}) or {}).get(OUTER_SPACE_SECTION, []) or [])
                            iid = self._iid(item_ref, candidates=cand)
                            msg = apply_action(self.state, GripPickUp(item=iid))
                        elif sub in ("down", "d"):
                            if len(tokens) < 3:
                                raise ActionError("Uso: grip down <CID>")
                            tgt_ref = " ".join(tokens[2:]).strip()
                            msg = apply_action(self.state, GripDown(target_character=self._cid(tgt_ref)))
                        else:
                            raise ActionError("Uso: grip pickup <IID|NAME> | grip down <CID>")

                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                # ---------- CONSOLA ----------
                if cmd == "suppress":
                    if len(tokens) not in (2, 3):
                        raise ActionError("Uso: suppress <SEC> [free]")
                    use_free = False
                    if len(tokens) == 3:
                        if tokens[2].lower() not in ("free", "f", "hack", "h"):
                            raise ActionError("Uso: suppress <SEC> [free]")
                        use_free = True
                    msg = apply_action(self.state, HazardSuppression(target_section=self._sec(tokens[1]), use_free_slot=use_free))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                # ---------- JUEGO ----------
                if cmd == "reveal":
                    cp = self.state.current_player()
                    bc = getattr(cp, 'bonus_character', None)
                    bd = bool(getattr(cp, 'bonus_points_disabled', False))
                    print("Elige tipo de Reveal:")
                    print("  1) Normal (revelas tu PC / Secret Identity)")
                    if bc and (not bd):
                        print("  2) Schrödinger (tu Bonus Character pasa a ser tu PC; pierdes tu PC; Bonus Points desactivados)")
                    else:
                        print("  2) Schrödinger (NO disponible: no tienes BC asignado o ya están desactivados)")
                    ans = input("Reveal # (Enter=1): ").strip().lower()
                    if ans in ("", "1", "n", "normal"):
                        msg = apply_action(self.state, Reveal())
                    elif ans in ("2", "s", "sch", "schrodinger", "schrödinger"):
                        msg = apply_action(self.state, SchrodingerReveal())
                    else:
                        raise ActionError("Opción inválida. Usa 1 (Normal) o 2 (Schrödinger).")
                    print("✅ " + msg)
                    # Reveal Powers que dan Items pueden forzar un DROP inmediato (RM 4.5.3.1).
                    self._resolve_pending_free_drops()
                    self._resolve_pending_reveal_powers()
                    _print_hud(self.state)
                    continue

                if cmd == "influence":
                    if len(tokens) < 2:
                        raise ActionError("Uso: influence <CID> [n]")

                    # influence <cid...> [n]
                    n = None
                    cid_ref_tokens = tokens[1:]
                    if len(tokens) >= 3:
                        try:
                            n = int(tokens[-1])
                            cid_ref_tokens = tokens[1:-1]
                        except Exception:
                            n = None
                            cid_ref_tokens = tokens[1:]

                    cid_ref = " ".join(cid_ref_tokens).strip()
                    cid = self._cid(cid_ref)

                    if n is None:
                        # UX: para LOYAL, si no indicas cantidad, colocamos el mínimo legal (total_prev+1).
                        n = 1
                        try:
                            ch = self.state.characters.get(cid)
                            if ch and ch.has_ability(AB.LOYAL):
                                total_prev = 0
                                for p in self.state.players:
                                    total_prev += self.state.influence_of(p.pid, cid)
                                n = total_prev + 1
                        except Exception:
                            pass
                    msg = apply_action(self.state, PlaceInfluence(target=cid, amount=n))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "renegotiate":
                    # RM 15.6: siempre recoge tu Activation Disc; opcionalmente devuelve 1 cube desde un Character
                    if len(tokens) == 1:
                        msg = apply_action(self.state, RenegotiateTakeBack())
                    elif len(tokens) >= 2:
                        # renegotiate <cid...> [1]
                        n = None
                        cid_ref_tokens = tokens[1:]
                        if len(tokens) >= 3:
                            try:
                                n = int(tokens[-1])
                                cid_ref_tokens = tokens[1:-1]
                            except Exception:
                                n = None
                                cid_ref_tokens = tokens[1:]
                        if n is not None and n != 1:
                            raise ActionError("Renegotiate (RM 15.6.2) solo permite devolver 1 cube.")
                        cid_ref = " ".join(cid_ref_tokens).strip()
                        cid = self._cid(cid_ref)
                        msg = apply_action(self.state, RenegotiateTakeBack(from_character=cid))
                    else:
                        raise ActionError("Uso: renegotiate [CID]  (CID opcional para devolver 1 cube)")
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "activate":
                    if len(tokens) < 2:
                        raise ActionError("Uso: activate <CID>")
                    cid_ref = " ".join(tokens[1:]).strip()
                    cid = self._cid(cid_ref)
                    msg = apply_action(self.state, Activate(character=cid))
                    print("✅ " + msg)
                    self._resolve_pending_activation_powers()
                    _print_hud(self.state)
                    continue

                if cmd in ("skipfp", "fp0"):
                    setattr(self.state, 'forceful_presence_actor', None)
                    print("⏭️  Forceful Presence cancelado.")
                    _print_hud(self.state)
                    continue

                if cmd == "move":
                    if len(tokens) != 2:
                        raise ActionError("Uso: move <SEC>")
                    msg = apply_action(self.state, Move(to_section=self._sec(tokens[1])))
                    print("✅ " + msg)
                    self._resolve_pending_free_drops()
                    _print_hud(self.state)
                    continue

                if cmd in ("zeromove", "zeroborn", "zmove"):
                    if len(tokens) != 2:
                        raise ActionError("Uso: zeromove <SEC>")
                    msg = apply_action(self.state, ZeroBornMove(to_section=self._sec(tokens[1])))
                    print("✅ " + msg)
                    self._resolve_pending_free_drops()
                    _print_hud(self.state)
                    continue


                if cmd == "movedrag":
                    if len(tokens) < 3:
                        raise ActionError("Uso: movedrag <SEC> <DOWNCID>")
                    drag_ref = " ".join(tokens[2:]).strip()
                    msg = apply_action(self.state, MoveDrag(to_section=self._sec(tokens[1]), drag_character=self._cid(drag_ref)))
                    print("✅ " + msg)
                    self._resolve_pending_free_drops()
                    _print_hud(self.state)
                    continue

                if cmd == "breach":
                    if len(tokens) != 2:
                        raise ActionError("Uso: breach <SEC>")
                    msg = apply_action(self.state, Breach(to_section=self._sec(tokens[1])))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd in ("wormtongue", "worm", "wt"):
                    if len(tokens) < 2:
                        raise ActionError("Uso: wormtongue <HUMANCID> [PID]")
                    pid = None
                    import re as _re
                    if len(tokens) >= 3 and _re.match(r"^P\d+$", str(tokens[-1]).upper()):
                        pid = str(tokens[-1]).upper()
                        tgt_ref = " ".join(tokens[1:-1]).strip()
                    else:
                        tgt_ref = " ".join(tokens[1:]).strip()
                    tgt = self._cid(tgt_ref)
                    msg = apply_action(self.state, Wormtongue(target_character=tgt, cube_owner=pid))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue


                if cmd == "throw":
                    # Permite: throw <IID|NAME...> <SEC> [boom|safe]
                    if len(tokens) < 3:
                        raise ActionError("Uso: throw <IID|NAME> <SEC> [boom]")

                    boom_words = {"boom", "explode", "detonate", "x", "y", "yes", "si", "sí", "1"}
                    safe_words = {"no", "n", "0", "safe"}

                    flag = str(tokens[-1]).strip().lower()
                    det = None
                    if flag in boom_words or flag in safe_words:
                        if len(tokens) < 4:
                            raise ActionError("Uso: throw <IID|NAME> <SEC> [boom]")
                        to = str(tokens[-2]).upper()
                        item_ref = " ".join(tokens[1:-2]).strip()
                        det = (flag in boom_words)
                    else:
                        to = str(tokens[-1]).upper()
                        item_ref = " ".join(tokens[1:-1]).strip()

                    if not item_ref:
                        raise ActionError("Uso: throw <IID|NAME> <SEC> [boom]")

                    act = self._active_cid()
                    inv = list((getattr(self.state, 'characters', {}) or {}).get(act).items) if act in (getattr(self.state, 'characters', {}) or {}) else []
                    iid = self._iid(item_ref, candidates=inv)

                    if det is None:
                        tok = getattr(self.state, 'items', {}).get(iid)
                        if tok and getattr(tok, 'is_bomb', None) and tok.is_bomb():
                            ans = input("¿Detonar la Bomb al caer? (y/N): ").strip().lower()
                            det = ans in ("y", "yes", "s", "si", "sí", "1")
                        else:
                            det = False

                    msg = apply_action(self.state, ThrowItem(item=iid, to_section=to, detonate=bool(det)))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "pickup":
                    if len(tokens) < 2:
                        raise ActionError("Uso: pickup <IID|NAME>")
                    act = self._active_cid()
                    ch = (getattr(self.state, 'characters', {}) or {}).get(act)
                    if not ch:
                        raise ActionError("No hay Character activo válido.")
                    sec = str(getattr(ch, 'section', '')).upper()
                    cand = list((getattr(self.state, 'section_items', {}) or {}).get(sec, []) or [])
                    item_ref = " ".join(tokens[1:]).strip()
                    iid = self._iid(item_ref, candidates=cand)
                    msg = apply_action(self.state, PickUp(item=iid))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "drop":
                    # Permite: drop <IID|NAME...> [boom]
                    if len(tokens) < 2:
                        raise ActionError("Uso: drop <IID|NAME> [boom]")

                    boom_words = {"boom", "explode", "detonate", "x", "y", "yes", "si", "sí", "1"}
                    safe_words = {"no", "n", "0", "safe"}

                    maybe_flag = str(tokens[-1]).strip().lower()
                    has_flag = (maybe_flag in boom_words) or (maybe_flag in safe_words)
                    item_ref = " ".join(tokens[1:-1]).strip() if (has_flag and len(tokens) >= 3) else " ".join(tokens[1:]).strip()

                    act = self._active_cid()
                    inv = list((getattr(self.state, 'characters', {}) or {}).get(act).items) if act in (getattr(self.state, 'characters', {}) or {}) else []
                    iid = self._iid(item_ref, candidates=inv)

                    det = None
                    if has_flag:
                        if maybe_flag in safe_words:
                            det = False
                        else:
                            det = maybe_flag in boom_words
                    if det is None:
                        tok = getattr(self.state, 'items', {}).get(iid)
                        if tok and getattr(tok, 'is_bomb', None) and tok.is_bomb():
                            ans = input("¿Detonar la Bomb al caer? (y/N): ").strip().lower()
                            det = ans in ("y", "yes", "s", "si", "sí", "1")
                        else:
                            det = False
                    msg = apply_action(self.state, Drop(item=iid, detonate=bool(det)))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "give":
                    # Uso: give <IID|NAME...> <CID...> | give <IID|NAME...> to <CID...>
                    if len(tokens) < 3:
                        raise ActionError("Uso: give <IID|NAME> <CID>")

                    act = self._active_cid()
                    inv = list((getattr(self.state, 'characters', {}) or {}).get(act).items) if act in (getattr(self.state, 'characters', {}) or {}) else []

                    lower = [str(t).lower() for t in tokens]
                    if "to" in lower[1:] or "a" in lower[1:]:
                        try:
                            i_to = lower.index("to", 1)
                        except ValueError:
                            i_to = lower.index("a", 1)
                        item_ref = " ".join(tokens[1:i_to]).strip()
                        tgt_ref = " ".join(tokens[i_to+1:]).strip()
                        if not item_ref or not tgt_ref:
                            raise ActionError("Uso: give <IID|NAME> <CID>")
                        iid = self._iid(item_ref, candidates=inv)
                        tgt = self._cid(tgt_ref)
                        msg = apply_action(self.state, Give(item=iid, to_character=tgt))
                    else:
                        iid, rest = self._consume_iid_prefix(tokens, 1, candidates=inv, min_remaining=1)
                        tgt_ref = " ".join(rest).strip()
                        tgt = self._cid(tgt_ref)
                        msg = apply_action(self.state, Give(item=iid, to_character=tgt))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "wait":
                    msg = apply_action(self.state, Wait())
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "attack":
                    if len(tokens) < 2:
                        raise ActionError("Uso: attack <CID|MID> [gun|bludgeon]")
                    weap = None
                    tail = [t.strip() for t in tokens[1:] if t.strip()]
                    if tail:
                        last = tail[-1].lower()
                        if last in ("gun", "g", "bludgeon", "blud", "b"):
                            weap = ("GUN" if last in ("gun", "g") else "BLUDGEON")
                            tail = tail[:-1]
                    if not tail:
                        raise ActionError("Uso: attack <CID|MID> [gun|bludgeon]")
                    tgt_ref = " ".join(tail).strip()
                    msg = apply_action(self.state, Attack(target_id=self._cid_or_mid(tgt_ref), weapon=weap))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                

                if cmd == "rob":
                    if len(tokens) < 3:
                        raise ActionError("Uso: rob <victimCID> <IID|NAME|TYPE>")

                    victim, rest = self._consume_cid_prefix(tokens, 1, min_remaining=1)
                    what_raw = " ".join(rest).strip()
                    what_up = what_raw.upper()

                    # Heurística:
                    # - I<dígitos> => item id
                    # - si no, intentamos resolver como nombre de item en inventario de la víctima
                    # - si falla, lo tratamos como TYPE de Data.
                    if re.match(r"^I\d+$", what_up):
                        msg = apply_action(self.state, Rob(victim=victim, item=what_up))
                    else:
                        try:
                            vch = (getattr(self.state, 'characters', {}) or {}).get(victim)
                            vcand = list(getattr(vch, 'items', []) or []) if vch else []
                            iid = self.state.resolve_item_ref(what_raw, candidates=vcand)
                            msg = apply_action(self.state, Rob(victim=victim, item=iid))
                        except Exception:
                            msg = apply_action(self.state, Rob(victim=victim, data_type=what_up))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue


                if cmd == "sabotage":
                    msg = apply_action(self.state, Sabotage())
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "revive":
                    if len(tokens) < 2:
                        raise ActionError("Uso: revive <CID|MID>")
                    tgt_ref = " ".join(tokens[1:]).strip()
                    msg = apply_action(self.state, Revive(target_character=self._cid_or_mid(tgt_ref)))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "copydata":
                    if len(tokens) < 3:
                        raise ActionError("Uso: copydata <TYPE> <toCID>")
                    to_ref = " ".join(tokens[2:]).strip()
                    act = CopyData(data_type=tokens[1].upper(), to_character=self._cid(to_ref))
                    msg = apply_action(self.state, act)
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "delete":
                    if len(tokens) != 2:
                        raise ActionError("Uso: delete <TYPE>")
                    msg = apply_action(self.state, DeleteData(data_type=tokens[1].upper()))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "jammers":
                    if len(tokens) not in (2, 3) or tokens[1].lower() not in ("on", "off"):
                        raise ActionError("Uso: jammers on|off [free]")
                    use_free = False
                    if len(tokens) == 3:
                        if tokens[2].lower() not in ("free", "f", "hack", "h"):
                            raise ActionError("Uso: jammers on|off [free]")
                        use_free = True
                    msg = apply_action(self.state, SetJammers(on=(tokens[1].lower() == "on"), use_free_slot=use_free))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "cameras":
                    if len(tokens) != 2 or tokens[1].lower() not in ("on", "off"):
                        raise ActionError("Uso: cameras on|off")
                    msg = apply_action(self.state, SetCameras(on=(tokens[1].lower() == "on")))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "manufacture":
                    if len(tokens) < 3:
                        raise ActionError("Uso: manufacture data <TYPE> | manufacture item <NAME>")
                    kind = tokens[1].lower()
                    spec = " ".join(tokens[2:]).strip()
                    msg = apply_action(self.state, Manufacture(kind=kind, spec=spec))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue
                if cmd == "transmit":
                    if len(tokens) != 3:
                        raise ActionError("Uso: transmit <TYPE> <AUTHORITIES|NEWS>")
                    dtype = tokens[1].upper()
                    off_raw = tokens[2].upper()
                    if off_raw in ("A", "AUTH", "AUTHORITY", "AUTHORITIES"):
                        off = "AUTHORITIES"
                    elif off_raw in ("N", "NEWS"):
                        off = "NEWS"
                    else:
                        raise ActionError("Offsite inválido. Usa AUTHORITIES o NEWS.")
                    msg = apply_action(self.state, TransmitData(data_type=dtype, offsite=off))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "timedlaunch":
                    if len(tokens) != 1:
                        raise ActionError("Uso: timedlaunch (debes estar dentro del Pod; sin argumentos).")
                    msg = apply_action(self.state, TimedLaunch())
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue


                if cmd == "sectionlaunch":
                    if len(tokens) != 2:
                        raise ActionError("Uso: sectionlaunch <PODSEC>")
                    msg = apply_action(self.state, SectionLaunch(pod_section=self._sec(tokens[1])))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "bridgelaunch":
                    if len(tokens) != 1:
                        raise ActionError("Uso: bridgelaunch")
                    msg = apply_action(self.state, BridgeLaunch())
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "abandon":
                    if len(tokens) != 1:
                        raise ActionError("Uso: abandon")
                    msg = apply_action(self.state, AbandonShip())
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd in ("selfdestruct", "self-destruct", "sd"):
                    if len(tokens) != 1:
                        raise ActionError("Uso: selfdestruct")
                    msg = apply_action(self.state, SelfDestruct())
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd in ("ejectantimatter", "eject-antimatter", "eject", "ejectam"):
                    if len(tokens) != 1:
                        raise ActionError("Uso: ejectantimatter")
                    msg = apply_action(self.state, EjectAntimatter())
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue


                if cmd in ("releasepx", "releasex", "release"):
                    if len(tokens) != 1:
                        raise ActionError("Uso: releasepx")
                    msg = apply_action(self.state, ReleaseProjectX())
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd in ("decontaminate", "decon"):
                    if len(tokens) < 1:
                        raise ActionError("Uso: decontaminate <CID> (o sin CID para ti mismo)")
                    if len(tokens) == 1:
                        tgt = None
                    else:
                        tgt_ref = " ".join(tokens[1:]).strip()
                        tgt = self._cid(tgt_ref)
                    msg = apply_action(self.state, Decontaminate(target_character=tgt))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd in ("datamine", "data-mine", "mine", "dm"):
                    if len(tokens) < 2:
                        raise ActionError("Uso: datamine <IID|NAME|SEC>")
                    ref = " ".join(tokens[1:]).strip()
                    iid = self._resolve_datamine_target(ref)
                    msg = apply_action(self.state, DataMine(item=iid))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd in ("rwlaunch", "rocketlaunch", "rocketwings", "wingslaunch", "rw"):
                    if len(tokens) != 1:
                        raise ActionError("Uso: rwlaunch")
                    msg = apply_action(self.state, RocketWingsLaunch())
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd in ("meditate", "med"):
                    if len(tokens) != 1:
                        raise ActionError("Uso: meditate")
                    msg = apply_action(self.state, Meditate())
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd in ("msrepair", "machinerepair", "repairbot", "machineshop"):
                    if len(tokens) < 2:
                        raise ActionError("Uso: msrepair <ROBOTCID>")
                    tgt_ref = " ".join(tokens[1:]).strip()
                    tgt = self._cid(tgt_ref)
                    msg = apply_action(self.state, RepairRobot(target_character=tgt))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd in ("tradecraft", "tc"):
                    if len(tokens) < 4:
                        raise ActionError("Uso: tradecraft <KID|NAME> <KID|NAME> <KID|NAME_USED>")

                    cp = self.state.current_player()
                    hand = list(getattr(cp, "kompromat_hand", []) or [])
                    if len(hand) < 2:
                        raise ActionError("TRADECRAFT: necesitas al menos 2 Kompromat en la mano.")

                    # Parseo flexible: cada referencia puede ser ID o nombre (incluye nombres con espacios).
                    kid1, rest = self._consume_iid_prefix(tokens, 1, candidates=hand, min_remaining=2)
                    hand2 = [k for k in hand if str(k).upper() != str(kid1).upper()]

                    # Segundo descarte: consumimos desde el resto.
                    tmp = ["_"] + rest
                    kid2, rest2 = self._consume_iid_prefix(tmp, 1, candidates=hand2, min_remaining=1)

                    take_ref = " ".join(rest2).strip()
                    kid_take = self._kid_used_npc(take_ref)

                    msg = apply_action(self.state, Tradecraft(discard_a=kid1, discard_b=kid2, take=kid_take))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "komp":
                    if len(tokens) < 3:
                        raise ActionError("Uso: komp <KID|NAME> <acción...>")

                    cp = self.state.current_player()
                    hand = list(getattr(cp, "kompromat_hand", []) or [])

                    # El Kompromat puede referirse por ID (I#) o por objetivo (p.ej. "Station Chief").
                    token, rest = self._consume_iid_prefix(tokens, 1, candidates=hand, min_remaining=1)

                    if getattr(cp, "turn_kompromat_attempted", False):
                        raise ActionError("Ya has intentado usar Kompromat este turno.")

                    if token not in hand:
                        raise ActionError("No tienes ese Kompromat.")

                    # Para parsear la acción, el actor real es el target del Kompromat
                    # (no tu Character activo actual).
                    tgt = None
                    try:
                        tok = (getattr(self.state, 'items', {}) or {}).get(token)
                        if tok is not None:
                            tgt = getattr(tok, 'kompromat_target', None)
                    except Exception:
                        tgt = None

                    sub = self._parse_subaction(rest, actor_cid=tgt)

                    consent = self._maybe_ask_consent_for_komp(self.state, token)
                    msg = apply_action(self.state, UseKompromat(token=token, subaction=sub, consent=consent))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                if cmd == "bribe":
                    if len(tokens) < 3:
                        raise ActionError("Uso: bribe <CID> <acción...>")
                    tgt, rest = self._consume_cid_prefix(tokens, 1, min_remaining=1)
                    # La subacción se ejecuta con el Character sobornado como actor.
                    sub = self._parse_subaction(rest, actor_cid=tgt)

                    if getattr(self.state.current_player(), "turn_bribe_attempted", False):
                        raise ActionError("Ya has intentado usar Bribe este turno.")

                    consent = self._maybe_ask_consent_for_bribe(self.state, tgt)
                    msg = apply_action(self.state, UseBribe(target_character=tgt, subaction=sub, consent=consent))
                    print("✅ " + msg)
                    _print_hud(self.state)
                    continue

                raise ActionError("Comando no reconocido. Escribe 'help'.")

            except (ActionError, ValueError) as e:
                if self.undo_stack:
                    self.undo_stack.pop()
                print(f"Esa acción no se puede: {e}")
                _print_hud(self.state)

        # Si el juego ha terminado (Stationfall), NO resolvemos Time Markers ni Monsters.
        # RM 16.1: en Stationfall no se cambian estados Live/Down salvo que se especifique.
        if bool(getattr(self.state, 'stationfall_triggered', False)):
            self.state.end_player_turn()
            return

        # --- RESOLVE phase (RM 15.7) ---
        try:
            self._resolve_phase()
        except Exception as e:
            print(f"(RESOLVE) Error: {e}")

        self.state.end_player_turn()


    def run_stationfall(self) -> None:
        """Ejecuta Stationfall (RM 16) y muestra resultados."""
        st = self.state
        if not bool(getattr(st, 'stationfall_triggered', False)):
            print("(Stationfall) No está activado.")
            return
        if bool(getattr(st, 'stationfall_processed', False)):
            print("(Stationfall) Ya estaba procesado.")
            return

        print("\n====================")
        print("💥 STATIONFALL")
        print("====================")

        def _sf_phase(title: str) -> None:
            bar = "=" * 60
            print("\n" + bar)
            print(f" {title} ".center(60, "="))
            print(bar + "\n")
        reason = getattr(st, 'stationfall_reason', None)
        minute = getattr(st, 'stationfall_minute', None)
        if reason:
            print(f"Reason: {reason}")
        if minute is not None:
            print(f"Minute: {minute}")

        _sf_phase("REVEAL")

        # 16.2 Reveal (sin Reveal Powers) - interactivo por jugador para permitir Schrödinger Reveal
        saved_idx = getattr(st, 'current_player_index', 0)
        saved_active = getattr(st, 'active_character_id', None)

        # Limpieza mínima para que Reveal.validate no se bloquee por estado del último turno
        st.active_character_id = None
        for _p in getattr(st, 'players', []):
            try:
                _p.turn_influence_target = None
                _p.turn_renegotiated = False
            except Exception:
                pass

        # Permite acciones internas durante Stationfall y suprime Reveal Powers
        st.stationfall_mode = True

        try:
            for i, p in enumerate(st.players):
                if getattr(p, 'revealed_character', None) is not None:
                    continue
                if not getattr(p, 'secret_identity', None) and not getattr(p, 'bonus_character', None):
                    continue

                st.current_player_index = i
                cp = st.current_player()
                print(f"\n👁️  Stationfall: {cp.display_name()} debe revelar ahora (RM 16.2).")

                while getattr(cp, 'revealed_character', None) is None:
                    text = input(f"[SF {cp.display_name()} REVEAL]> ").strip()
                    if not text:
                        continue
                    low = text.lower()

                    if low in ("help", "h", "?"):
                        print("Opciones: reveal | schro | myid | help")
                        continue

                    if low == "myid":
                        print(f"\n🪪 Tus Identity Cards (solo tú) [{cp.display_name()}]:")
                        si = getattr(cp, 'secret_identity', None)
                        if not si:
                            print("  PC (Principal): (no asignada)")
                        else:
                            nm = st.characters[si].name if si in st.characters else "?"
                            rev = getattr(cp, 'revealed_character', None)
                            extra_rev = f" | REVEALED={rev}" if rev else ""
                            print(f"  PC (Principal): {si} ({nm}){extra_rev}")

                        bc = getattr(cp, 'bonus_character', None)
                        if not bc:
                            print("  BC (Secundaria): (no asignada)")
                        else:
                            nm = st.characters[bc].name if bc in st.characters else "?"
                            bk = getattr(cp, 'bonus_kind', None) or '-'
                            bi = int(getattr(cp, 'bonus_icons', 0) or 0)
                            try:
                                cards = getattr(st, 'identity_cards', {}) or {}
                                card = cards.get(str(bc).upper()) if bc else None
                                if card is not None:
                                    bk = str(getattr(card, 'bonus_kind', bk) or bk).upper()
                                    bi = int(getattr(card, 'bonus_icons', bi) or bi)
                            except Exception:
                                pass
                            bd = bool(getattr(cp, 'bonus_points_disabled', False))
                            extra = " | BONUS DISABLED" if bd else ""
                            print(f"  BC (Secundaria): {bc} ({nm}) | {bk} x{bi}{extra}")
                        continue

                    try:
                        if low in ("reveal", "r"):
                            msg = apply_action(st, Reveal())
                            print("👁️  " + str(msg))
                        elif low in ("schro", "schrodinger", "s"):
                            msg = apply_action(st, SchrodingerReveal())
                            print("👁️  " + str(msg))
                        else:
                            print("Comando inválido. Usa: reveal | schro | myid | help")
                    except Exception as e:
                        print(f"(Stationfall Reveal) {e}")

                    # refresca cp por si cambió
                    cp = st.current_player()

        finally:
            st.stationfall_mode = False
            st.current_player_index = saved_idx
            st.active_character_id = saved_active

        # Stationfall: aplicar efectos especiales (p.ej. Daredevil: POINT BREAK si se reveló antes de Stationfall)
        try:
            if hasattr(st, 'stationfall_apply_pc_stationfall_powers'):
                msgs = st.stationfall_apply_pc_stationfall_powers() or []
                for m in msgs:
                    print('⚡ ' + str(m))
        except Exception as e:
            print(f"(Stationfall Powers) Error: {e}")

        _sf_phase("DELIVER")

        # 16.3 Deliver Data
        try:
            print("\n--- Deliver Data (Escaped PCs) ---")
            for p in st.players:
                pid = p.pid
                cid = p.revealed_character or p.secret_identity
                if not cid or cid not in st.characters:
                    continue
                # Solo Escaped PCs (Live o Down)
                try:
                    escaped = st.stationfall_counts_as_escaped(cid) if hasattr(st, 'stationfall_counts_as_escaped') else bool(getattr(st.characters[cid], 'escaped', False))
                except Exception:
                    escaped = bool(getattr(st.characters[cid], 'escaped', False))
                if not escaped:
                    continue
                ch = st.characters[cid]
                data = dict(getattr(ch, 'data', {}) or {})
                if not data:
                    continue

                print(f"\n{pid}: PC={cid} ({ch.name}) puede entregar Data: {data}")
                for dtype, cnt in list(data.items()):
                    # RM 9.2: un Character solo puede Poseer 1 copia por tipo.
                    # En Stationfall (RM 16.3.1), Deliver coloca DUPLICADOS en Offsites
                    # sin quitar la Data del PC. Por simplicidad, tratamos cnt>0 como 'posee'.
                    try:
                        cnti = int(cnt)
                    except Exception:
                        cnti = 0
                    if cnti <= 0:
                        continue

                    ans = input(
                        f"  {pid} → '{dtype}': 0=ninguno | a=Authorities | n=News | b=Both (Enter=0): "
                    ).strip().lower()

                    send_auth = False
                    send_news = False
                    if ans in ("a", "auth", "authorities", "1"):
                        send_auth = True
                    elif ans in ("n", "news", "2"):
                        send_news = True
                    elif ans in ("b", "both", "an", "na", "a+n", "n+a", "3"):
                        send_auth = True
                        send_news = True

                    if send_auth and hasattr(st, 'stationfall_record_delivery'):
                        msg = st.stationfall_record_delivery(pid, 'AUTHORITIES', dtype, 1)
                        if msg:
                            print("  ✅ " + msg)
                    if send_news and hasattr(st, 'stationfall_record_delivery'):
                        msg = st.stationfall_record_delivery(pid, 'NEWS', dtype, 1)
                        if msg:
                            print("  ✅ " + msg)
        except Exception as e:
            print(f"(Stationfall Deliver Data) Error: {e}")

        _sf_phase("SCORE")


        # 16.4 Scoring + Winner
        try:
            print("\n--- Scoring ---")

            scores = {}
            detail = {}
            if hasattr(st, 'stationfall_compute_scores_detailed'):
                scores, detail = st.stationfall_compute_scores_detailed()
            else:
                scores = st.stationfall_compute_scores() if hasattr(st, 'stationfall_compute_scores') else {}

            # Resumen rápido (en orden de turno)
            for p in st.players:
                pid = p.pid
                pname = p.display_name() if hasattr(p, 'display_name') else (getattr(p, 'name', None) or str(pid))
                legal = getattr(p, 'legal', 'Innocent')
                sc = int(scores.get(pid, 0) or 0)

                extra = ""
                if str(legal).lower() == 'guilty':
                    try:
                        n_ev = int(getattr(st, 'stationfall_deliveries', {}).get(pid, {}).get('AUTHORITIES', {}).get('EVIDENCE', 0))
                    except Exception:
                        n_ev = 0
                    if n_ev > 0:
                        extra = " (eligible 10.2.3)"

                print(f"  {pname}: {sc} pts | legal={legal}{extra}")

            # Desglose (si está disponible)
            if detail:
                print("\n--- Desglose por jugador ---")

                def _fmt_line(ln: dict) -> str:
                    status = ln.get('status', '')
                    desc = ln.get('desc', '')
                    earned = int(ln.get('earned', 0) or 0)
                    base = ln.get('base_pts', None)
                    mult = ln.get('mult', None)
                    if (base is not None) and (mult is not None):
                        return f"    {status} +{earned} | ({int(base)}×{int(mult)}) {desc}"
                    if base is not None:
                        return f"    {status} +{earned} | ({int(base)}) {desc}"
                    return f"    {status} +{earned} | {desc}"

                for p in st.players:
                    pid = p.pid
                    info = detail.get(pid)
                    if not info:
                        continue

                    pname = info.get('player', str(pid))
                    legal = info.get('legal', getattr(p, 'legal', 'Innocent'))

                    pc = info.get('pc', {}) or {}
                    pc_cid = pc.get('cid', '')
                    pc_name = pc.get('name', '')

                    bc = info.get('bc')
                    bc_txt = ""
                    if bc:
                        bc_txt = f" | BC: {bc.get('cid','')} ({bc.get('name','')}) {bc.get('kind','')}×{bc.get('icons',0)}"

                    print(f"\n{pname} | legal={legal} | PC: {pc_cid} ({pc_name}){bc_txt}")

                    # Agenda
                    print("  Agenda:")
                    for ln in (info.get('agenda', []) or []):
                        print(_fmt_line(ln))
                    print(f"    = Agenda total: {int(info.get('agenda_total', 0) or 0)}")

                    # Bonus character
                    if bc:
                        stt = '✅' if bool(bc.get('met')) else '❌'
                        earned = int(bc.get('earned', 0) or 0)
                        reason = bc.get('reason', '')
                        print(f"  Bonus Character: {stt} +{earned} | {bc.get('cid','')} ({bc.get('name','')}) {bc.get('kind','')}×{bc.get('icons',0)} | {reason}")
                    else:
                        print("  Bonus Character: (ninguno)")

                    # Otros
                    other = info.get('other', {}) or {}
                    unused = int(other.get('unused_bribe', 0) or 0)
                    print(f"  Otros: {'✅' if unused else '❌'} +{unused} | bribe sin usar")

                    brpc = (other.get('bribes_on_pc', {}) or {})
                    cnt = int(brpc.get('count', 0) or 0)
                    if cnt > 0:
                        src = brpc.get('from', []) or []
                        src_txt = ", ".join([str(s) for s in src if s])
                        tail = f" (de: {src_txt})" if src_txt else ""
                        print(f"         ✅ +{cnt} | bribes en tu PC{tail}")
                    else:
                        print("         +0 | bribes en tu PC")

                    # Influence
                    inf = info.get('influence', {}) or {}
                    placed = int(inf.get('placed_influence', 0) or 0)
                    betrayal = int(inf.get('betrayal', 0) or 0)
                    outside = int(inf.get('outside_pool', 0) or 0)
                    lim = int(inf.get('limit', 0) or 0)
                    pen = int(inf.get('penalty', 0) or 0)
                    if pen > 0:
                        print(f"  Influence: placed={placed} + betrayal={betrayal} => outside={outside} > limit={lim} => -{pen}")
                    else:
                        print(f"  Influence: placed={placed} + betrayal={betrayal} => outside={outside} / limit={lim} => 0")

                    # Total
                    print(f"  TOTAL: {int(info.get('total', 0) or 0)}")

            winners = st.stationfall_determine_winners() if hasattr(st, 'stationfall_determine_winners') else []
            print("\n--- Winner ---")
            if not winners:
                print("  (Sin ganador: todos Guilty o sin jugadores elegibles)")
            else:
                # Convertimos pids a nombres
                win_names = []
                for wpid in winners:
                    wp = st.player_by_id(wpid) if hasattr(st, 'player_by_id') else None
                    win_names.append(wp.display_name() if wp and hasattr(wp, 'display_name') else str(wpid))

                if len(win_names) == 1:
                    print(f"  🏆 GANADOR: {win_names[0]} — ENHORABUENA")
                    print("  La estación cae… y el informe final ya tiene nombre.")
                else:
                    print("  🏆 GANADORES (empate): " + ", ".join(win_names) + " — ENHORABUENA")
                    print("  La estación cae… y hay más de un nombre en el informe final.")
        except Exception as e:
            print(f"(Stationfall Scoring) Error: {e}")

        st.stationfall_processed = True