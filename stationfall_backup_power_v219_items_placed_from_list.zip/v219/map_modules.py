from __future__ import annotations

from dataclasses import dataclass
from typing import Callable, List

from models import GameState, Item, OUTER_SPACE_SECTION, TENTACULOUS_GUT_SECTION


@dataclass
class MapModule:
    """Cambios opcionales de mapa activados por la presencia de un Character.

    Estructura pensada para ir añadiendo módulos: "X solo existe si Y está en juego".
    """

    key: str
    condition: Callable[[GameState], bool]
    apply: Callable[[GameState], None]


def _has_character(state: GameState, cid: str, name: str | None = None) -> bool:
    cid_u = str(cid).upper()
    if cid_u in getattr(state, "characters", {}):
        return True
    if name:
        n_u = str(name).strip().upper()
        for ch in getattr(state, "characters", {}).values():
            if str(getattr(ch, "name", "")).strip().upper() == n_u:
                return True
    return False


def _has_monster_kind(state: GameState, kind: str) -> bool:
    """True si existe un Monster (pendiente o ya en mapa) con ese kind."""
    want = str(kind).strip().upper()
    pending = getattr(state, 'project_x_pending_monsters', None)
    if isinstance(pending, dict):
        pending_iter = pending.values()
    else:
        pending_iter = pending or []
    for m in pending_iter:
        if str(getattr(m, 'kind', '')).strip().upper() == want:
            return True
    for m in (getattr(state, 'monsters', None) or {}).values():
        if str(getattr(m, 'kind', '')).strip().upper() == want:
            return True
    return False


def _ensure_bidirectional_edge(graph: dict, a: str, b: str) -> None:
    a = str(a).upper()
    b = str(b).upper()
    graph.setdefault(a, [])
    graph.setdefault(b, [])
    if b not in graph[a]:
        graph[a].append(b)
    if a not in graph[b]:
        graph[b].append(a)


def _apply_counselor_shred_room(state: GameState) -> None:
    """Añade SHRED_ROOM con Data Mine y un LOCK hacia THERAPY_GARDEN."""

    # 1) Sección y corredor
    _ensure_bidirectional_edge(getattr(state, "graph", {}), "SHRED_ROOM", "THERAPY_GARDEN")

    # 2) La habitación empieza con LOCK en ese corredor.
    try:
        if hasattr(state, "add_lock_corridor"):
            state.add_lock_corridor("SHRED_ROOM", "THERAPY_GARDEN")
        else:
            # Fallback por si se cambia la implementación.
            a, b = "SHRED_ROOM", "THERAPY_GARDEN"
            key = (a, b) if a <= b else (b, a)
            getattr(state, "locks", set()).add(key)
    except Exception:
        # Si el corredor no existe o hay un fallo de setup, preferimos no crashear el demo.
        pass

    # 3) Acción impresa
    ra = getattr(state, "room_actions", None)
    if ra is None:
        state.room_actions = {}
        ra = state.room_actions
    ra.setdefault("SHRED_ROOM", [])
    if not any("DATA" in str(x).upper() and "MINE" in str(x).upper() for x in ra["SHRED_ROOM"]):
        ra["SHRED_ROOM"].append("Data Mine")

    # 4) La sección es Dark por defecto ("Dark Section" del tablero)
    if not hasattr(state, "unlit_sections") or getattr(state, "unlit_sections") is None:
        state.unlit_sections = set()
    state.unlit_sections.add("SHRED_ROOM")

    if not hasattr(state, "default_unlit_sections") or getattr(state, "default_unlit_sections") is None:
        state.default_unlit_sections = set()
    state.default_unlit_sections.add("SHRED_ROOM")

    # 5) Items en la sección (por consistencia)
    getattr(state, "section_items", {}).setdefault("SHRED_ROOM", [])


def _apply_daredevil_rocket_wings(state: GameState) -> None:
    """Añade ROCKET WINGS y la Section Action ROCKET WINGS LAUNCH en Outer Space.

    Solo se aplica si Daredevil está en la partida.
    """

    # 1) Item ROCKET WINGS (1 copia) en PHYSICS_LAB (según lista del tutorial)
    if not hasattr(state, 'items') or getattr(state, 'items', None) is None:
        state.items = {}

    rw_iid = None
    for iid, it in getattr(state, 'items', {}).items():
        name_u = str(getattr(it, 'name', '')).strip().upper()
        kind_u = str(getattr(it, 'kind', '')).strip().upper()
        if ('ROCKET' in name_u and 'WINGS' in name_u) or kind_u == 'ROCKET_WINGS':
            rw_iid = str(iid).upper()
            break

    if rw_iid is None:
        try:
            rw_iid = state.mint_item_id() if hasattr(state, 'mint_item_id') else None
        except Exception:
            rw_iid = None
        if not rw_iid:
            rw_iid = 'I999'
        state.items[rw_iid] = Item(iid=rw_iid, name='Rocket Wings', kind='ROCKET_WINGS')

    if not hasattr(state, 'section_items') or getattr(state, 'section_items', None) is None:
        state.section_items = {}

    # Evita duplicados por setups antiguos que lo colocaban en PRINT_SHOP
    if 'PRINT_SHOP' in state.section_items:
        cleaned = [x for x in state.section_items.get('PRINT_SHOP', []) if str(x).upper() != rw_iid]
        if cleaned:
            state.section_items['PRINT_SHOP'] = cleaned
        else:
            state.section_items.pop('PRINT_SHOP', None)

    state.section_items.setdefault('PHYSICS_LAB', [])
    if rw_iid not in [str(x).upper() for x in state.section_items['PHYSICS_LAB']]:
        state.section_items['PHYSICS_LAB'].append(rw_iid)

    # 2) Action impresa en OUTER SPACE
    ra = getattr(state, 'room_actions', None)
    if ra is None:
        state.room_actions = {}
        ra = state.room_actions
    ra.setdefault(OUTER_SPACE_SECTION, [])
    if not any('ROCKET' in str(x).upper() and 'WINGS' in str(x).upper() for x in ra[OUTER_SPACE_SECTION]):
        ra[OUTER_SPACE_SECTION].append('Rocket Wings Launch')


def _apply_engineer_reactor_token(state: GameState) -> None:
    """Activa la modificación de mapa del Engineer: Reactor Token.

    Según el Character Dossier (Engineer — Board Modifications):
    - Reactor no puede ser dañada con Bludgeon.
    - Si Reactor es dañada por otros medios, se añade ASPHYX a Reactor y
      a las secciones conectadas por CORRIDOR (no por vents).

    Este módulo solo activa la regla; la lógica vive en:
    - actions.Sabotage.validate (bloqueo de Bludgeon)
    - GameState.damage_section (colocación de Hazards al dañarse Reactor)
    """

    # Flag consumido por acciones/reglas.
    setattr(state, 'engineer_reactor_token', True)

    # Para debug/UI: registrar que hay un token de mapa en Reactor.
    if not hasattr(state, 'map_tokens') or getattr(state, 'map_tokens', None) is None:
        state.map_tokens = set()
    try:
        state.map_tokens.add('REACTOR_TOKEN')
    except Exception:
        # No romper el setup si map_tokens no es set.
        pass


def _apply_station_chief_medevac_pod(state: GameState) -> None:
    """Añade el MEDEVAC_POD anclado a FORWARD_AIRLOCKS (solo si Station Chief está en juego).

    Reglas pedidas (dossier):
    - Pod con límite de ocupantes 3.
    - Tiene la Section Action Timed Launch (ya la añade add_pod).
    - Su launch requirement NO requiere Abandon Ship.
    - Su launch requirement exige que haya al menos un HUMAN DOWN dentro del Pod.

    La lógica del requisito especial se resuelve en GameState.pod_launch_requirement_met
    cuando el flag `station_chief_medevac_pod` está activo.
    """

    setattr(state, 'station_chief_medevac_pod', True)

    # Crear el pod y conectarlo al grafo (si no existía).
    try:
        if hasattr(state, 'add_pod'):
            state.add_pod('MEDEVAC_POD', 'FORWARD_AIRLOCKS', occupancy_limit=3)
    except Exception:
        # Si ya existe o falla el setup, no romper el demo.
        pass

    # Ajustar requisitos: NO requiere Abandon Ship.
    try:
        pod = getattr(state, 'pods', {}).get('MEDEVAC_POD')
        if pod is not None:
            setattr(pod, 'requires_abandon_ship', False)
    except Exception:
        pass

    # Debug/UI opcional: registrar token de mapa
    if not hasattr(state, 'map_tokens') or getattr(state, 'map_tokens', None) is None:
        state.map_tokens = set()
    try:
        state.map_tokens.add('MEDEVAC_POD')
    except Exception:
        pass


def _apply_troubleshooter_cargo_claw(state: GameState) -> None:
    """Añade CARGO_CLAW conectada a FORWARD_AIRLOCKS (solo si Troubleshooter está en juego).

    Según el Character Dossier (Troubleshooter — Board Modifications):
    - Conecta Cargo Claw a Forward Airlocks.
    - En Cargo Claw, cualquier Character puede usar la Section Action GRIP:
        * Pick Up un Item en Outer Space
        * Down a un Character en Outer Space

    En este prototipo, modelamos GRIP como dos Section Actions separadas:
    - Grip Pick Up
    - Grip Down
    """

    # 1) Sección y corredor
    _ensure_bidirectional_edge(getattr(state, 'graph', {}), 'CARGO_CLAW', 'FORWARD_AIRLOCKS')

    # 2) Acción impresa
    ra = getattr(state, 'room_actions', None)
    if ra is None:
        state.room_actions = {}
        ra = state.room_actions
    ra.setdefault('CARGO_CLAW', [])
    # Dos acciones (split del GRIP del dossier)
    if not any(('GRIP' in str(x).upper()) and ('PICK' in str(x).upper()) for x in ra['CARGO_CLAW']):
        ra['CARGO_CLAW'].append('Grip Pick Up')
    if not any(('GRIP' in str(x).upper()) and ('DOWN' in str(x).upper()) for x in ra['CARGO_CLAW']):
        ra['CARGO_CLAW'].append('Grip Down')

    # 3) Items en la sección (por consistencia)
    if not hasattr(state, 'section_items') or getattr(state, 'section_items', None) is None:
        state.section_items = {}
    state.section_items.setdefault('CARGO_CLAW', [])

    # 4) Gravedad: sin gravedad
    if not hasattr(state, 'zero_g_sections') or getattr(state, 'zero_g_sections', None) is None:
        state.zero_g_sections = set()
    try:
        state.zero_g_sections.add('CARGO_CLAW')
    except Exception:
        pass

    # 5) Debug/UI: token opcional
    if not hasattr(state, 'map_tokens') or getattr(state, 'map_tokens', None) is None:
        state.map_tokens = set()
    try:
        state.map_tokens.add('CARGO_CLAW')
    except Exception:
        pass


def _apply_tentacled_gut(state: GameState) -> None:
    """Añade la sección aislada TENTACULOUS_GUT.

    Reglas homebrew pedidas:
    - Solo existe si el Project X 'TENTACLED' está en la partida.
    - No está conectada a nada (sin corridors, sin vents).
    - El bloqueo de interacciones se implementa en models.GameState (require_active + colocated).
    """

    # Flag (por si el UI o reglas futuras quieren consultarlo)
    setattr(state, 'tentacled_gut_enabled', True)

    # 1) Asegurar que exista como nodo en el grafo
    if not hasattr(state, 'graph') or getattr(state, 'graph', None) is None:
        state.graph = {}
    state.graph.setdefault(TENTACULOUS_GUT_SECTION, [])

    # 2) Forzar aislamiento total: eliminar cualquier arista entrante/saliente
    try:
        state.graph[TENTACULOUS_GUT_SECTION] = []
        for sec, neigh in list(getattr(state, 'graph', {}).items()):
            if sec == TENTACULOUS_GUT_SECTION:
                continue
            if not isinstance(neigh, list):
                continue
            state.graph[sec] = [x for x in neigh if str(x).upper() != TENTACULOUS_GUT_SECTION]
    except Exception:
        pass

    # 3) También sin vents
    try:
        if not hasattr(state, 'vents') or getattr(state, 'vents', None) is None:
            state.vents = {}
        # Borrar vents desde/hacia la Tripa
        state.vents.pop(TENTACULOUS_GUT_SECTION, None)
        for sec, outs in list(getattr(state, 'vents', {}).items()):
            if not isinstance(outs, list):
                continue
            state.vents[sec] = [x for x in outs if str(x).upper() != TENTACULOUS_GUT_SECTION]
    except Exception:
        pass

    # 4) No tiene acciones impresas (pero para consistencia lo inicializamos)
    if not hasattr(state, 'room_actions') or getattr(state, 'room_actions', None) is None:
        state.room_actions = {}
    state.room_actions.setdefault(TENTACULOUS_GUT_SECTION, [])

    # 5) Items en la sección (por consistencia)
    if not hasattr(state, 'section_items') or getattr(state, 'section_items', None) is None:
        state.section_items = {}
    state.section_items.setdefault(TENTACULOUS_GUT_SECTION, [])

    # Debug/UI opcional: token
    if not hasattr(state, 'map_tokens') or getattr(state, 'map_tokens', None) is None:
        state.map_tokens = set()
    try:
        state.map_tokens.add('TENTACULOUS_GUT')
    except Exception:
        pass


ALL_MAP_MODULES: List[MapModule] = [
    MapModule(
        key="COUNSELOR_SHRED_ROOM",
        condition=lambda st: _has_character(st, "C14", "Counselor"),
        apply=_apply_counselor_shred_room,
    ),
    MapModule(
        key="DAREDEVIL_ROCKET_WINGS",
        condition=lambda st: _has_character(st, "C15", "Daredevil"),
        apply=_apply_daredevil_rocket_wings,
    ),
    MapModule(
        key="ENGINEER_REACTOR_TOKEN",
        condition=lambda st: _has_character(st, "C7", "Engineer"),
        apply=_apply_engineer_reactor_token,
    ),
    MapModule(
        key="STATION_CHIEF_MEDEVAC_POD",
        condition=lambda st: _has_character(st, "C21", "Station Chief"),
        apply=_apply_station_chief_medevac_pod,
    ),
    MapModule(
        key="TROUBLESHOOTER_CARGO_CLAW",
        condition=lambda st: _has_character(st, "C22", "Troubleshooter"),
        apply=_apply_troubleshooter_cargo_claw,
    ),
    MapModule(
        key="TENTACLED_GUT",
        condition=lambda st: bool(getattr(st, "project_x_released", False)) and any(str(getattr(m, "kind", "")).strip().upper() == "TENTACLED" for m in (getattr(st, "monsters", {}) or {}).values()),
        apply=_apply_tentacled_gut,
    ),
]


def apply_map_modules(state: GameState) -> List[str]:
    """Aplica módulos opcionales y devuelve qué módulos se activaron."""
    applied: List[str] = []
    for mod in ALL_MAP_MODULES:
        ok = False
        try:
            ok = bool(mod.condition(state))
        except Exception:
            ok = False
        if ok:
            try:
                mod.apply(state)
                applied.append(mod.key)
            except Exception:
                # No romper el setup si un módulo falla.
                pass
    return applied
